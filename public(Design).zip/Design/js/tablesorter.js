(function($) {
  'use strict';
  $(function() {
    if ($('#myTable').length) {
      $('#myTable').tablesort();
    }
  });
})(jQuery);