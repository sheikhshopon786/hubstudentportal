<?php

/*
|--------------------------------------------------------------------------
| Web Routes 
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//##########--Super Admin---##########
Route::get('/admin','AdminController@admin');
//Admin Index
Route::get('/adminIndex','AdminController@adminIndex');

//Register Page
Route::get('/userRegisterForm','AdminController@userRegisterForm');
Route::post('/SregisterFormEntry','AdminController@SregisterFormEntry');

//Admin Login
Route::get('/adminLoginForm','AdminController@adminLoginForm');
Route::post('/adminLogin','AdminController@adminLogin');
Route::get('/adminLogout','AdminController@adminLogout');


//Academic Office for Super Admin
Route::get('/SacademicOffice','AdminController@SacademicOffice');
Route::get('/SacademicIndex','AdminController@SacademicIndex');

//Student Information
Route::get('/SstudentInformation','AdminController@SstudentInformation');
Route::get('/SstudentInformationInsert','AdminController@SstudentInformationInsert');
 Route::post('/SstudentInformationInsert','AdminController@SstudentInformationInsert')->name('SstudentInformationInsert') ;
  Route::get('/SstudentInformationList','AdminController@SstudentInformationList');

//Class Routine
  Route::get('/SclassRoutineList', 'AdminController@SclassRoutineList') ;
  Route::get('/SclassRoutineFormPage', 'AdminController@SclassRoutineFormPage') ;


Route::get('/ScourseRegistrationRoutine','AdminController@ScourseRegistrationRoutine');

 //Course
 Route::get('/ScourseOffer','AdminController@ScourseOffer');
Route::post('/Sstore','AdminController@Sstore')->name('Sstore') ;
Route::get('/ScourseList','AdminController@ScourseList');
//Semester Drop
Route::get('/SsemesterDrop','AdminController@SsemesterDrop');
Route::post('/SsemesterDropApply','AdminController@SsemesterDropApply')->name('SsemesterDropApply') ;
	Route::get('/SsemesterDropList','AdminController@SsemesterDropList');
//teachersEvolutionTable
Route::get('/SteachersEvolutionTable','AdminController@SteachersEvolutionTable');
Route::post('/SteachersEvolution','AdminController@SteachersEvolution')->name('SteachersEvolution') ;
Route::get('/SteachersEvolutionList','AdminController@SteachersEvolutionList');

//End Academic Office for Super Admin



//*************Start Account Office for Super Admin******************

Route::get('/SaccountOffice','AdminController@SaccountOffice');
Route::get('/SstudentInformationAcc','AdminController@SstudentInformationAcc');

//Student Payment Ledger
Route::get('/SstudentPaymentLedgerForm','AdminController@SstudentPaymentLedgerForm');
Route::post('/SstudentPaymentLedgerStore','AdminController@SstudentPaymentLedgerStore')->name('SstudentPaymentLedgerStore');
Route::get('/SstudentPaymentLedger','AdminController@SstudentPaymentLedger');


//Waiver Page
//Waiver Form
Route::get('/SwaiverFormPage','AdminController@SwaiverFormPage');
Route::post('/SwaiverForm','AdminController@SwaiverForm')->name('SwaiverForm') ;

//End Account Office for Super Admin





//*************Start Exam Controller for Super Admin******************
Route::get('/AexamOffice','AdminController@AexamOffice');
Route::get('/SstudentInformationExam','AdminController@SstudentInformationExam');


Route::get('/ScertificateApplicationList','AdminController@ScertificateApplicationList');
//Admit Serial
Route::get('/SadmitSerial','AdminController@SadmitSerial');
//Approval For Academic Office
Route::get('/Sapproval/{ID}', 'AdminController@Sapproval');

//Approval For Account Office
Route::get('/Sapproval2/{ID}', 'AdminController@Sapproval2');

//Alumni Result Checking Form
Route::get('/SresultVerifyFormPage','AdminController@SresultVerifyFormPage');

Route::post('/SresultVerifyForm','AdminController@SresultVerifyForm')->name('SresultVerifyForm') ;
//Student Result/Grade Sheet In Table
Route::get('/SstudentResult','AdminController@SstudentResult');
Route::post('/SstudentResultSearch','AdminController@SstudentResultSearch')->name('SSRsearch');









//*************Start Student Profile for Super Admin******************
Route::get('/SstudentPart','AdminController@SstudentPart');
Route::get('/SstudentDashBoard','AdminController@SstudentDashBoard');
Route::post('/SstudentInfoSearch','AdminController@SstudentInfoSearch')->name('stdsearch');

//Student Information List
 Route::get('/SstudentInformationList','AdminController@SstudentInformationList');

 //Studnet Information List Search
Route::post('/SstdInformationSearch','AdminController@SstdInformationSearch')->name('SstdSearch');





















//Start Index/hompage material
//Index(master page)
Route::get('/','pagesController@index')->name('home');
//footer
Route::get('/footer','pagesController@footer');
Route::get('/cseForm','academicController@cseForm');
//End Index/hompage materials


//Register Page
Route::get('/registerForm','pagesController@registerForm');
Route::post('/registerFormEntry','pagesController@registerFormEntry');

//Login
Route::get('/login','pagesController@login');
Route::post('/studentLogin','pagesController@studentLogin');
Route::get('/logout','pagesController@logout');

//Forgot Password
Route::get('/forgotPassword','pagesController@forgotPassword');
Route::get('/resetCode','pagesController@resetCode');
Route::get('/newPassword','pagesController@newPassword');


//Notice
 Route::get('/notice','pagesController@notice');
 Route::get('/notice1','pagesController@notice1');
 
 Route::get('/noticeeditreq/{ID}', 'pagesController@noticeeditreq') ;
Route::get('/noticedelreq/{ID}', 'pagesController@noticedelreq');
Route::post('/noticeeditsv', 'pagesController@noticeeditsv') ;



Route::get('/noticeFormPage','pagesController@noticeFormPage');
Route::post('/NoticeForm','PagesController@NoticeForm')->name('NoticeForm') ;

//Notification
Route::get('/notification','pagesController@notification');

 //Celender
 Route::get('/celender','pagesController@celender');
Route::get('/celender1','pagesController@celender1');

//student Clearance
Route::get('/studentClearance','pagesController@studentClearance');


//picture
Route::get('/pictureStoreForm','pagesController@pictureStoreForm');
Route::post('/pictureStoreForm','pagesController@pictureStoreForm')->name('pictureStoreForm');

Route::get('/picture','pagesController@picture');






//##########--STUDENT---##########

//Student Main page
 Route::get('/studentpart','studentController@studentpart');
 
//Class Routine
Route::get('/classRoutine','studentController@classRoutine');
 

 
//Student SideBar
Route::get('/studentSidebar','studentController@studentSidebar');


//Student Profile
Route::get('/studentProfile','studentController@studentProfile');

Route::get('/proUpdateReq','studentController@proUpdateView');

Route::post('/proUpdateReq','studentController@proUpdate');

//Course Registration Start
Route::get('/courseapproval/{ID}', 'studentController@courseapproval');

Route::get('/courseRegistrationPage','studentController@courseRegistrationPage');
Route::get('/courseRegApproval/{ID}','studentController@courseRegApproval');
Route::get('/courseCencelReq/{student_id}', 'studentController@courseCencelReq');
//Payment Message
Route::get('/paymentMessage','studentController@paymentMessage');


 Route::post('/courseRegistration','studentController@courseRegistration');
Route::get('/courseRegistration','studentController@courseRegistration');

Route::post('/extraCourseList','studentController@extraCourseList')->name('extraCourseListSearch');

//Subject Wise Result
Route::get('/subjectResult','studentController@subjectResult');
Route::post('/subjectResultSearch','studentController@subjectResultSearch')->name('subjectRejultSearch') ;


//Course List After Registration Start
Route::get('/courseListAfterReg','studentController@courseListAfterReg');
//Course List After Registration End



//Course Registration Time Out
Route::get('/CourseRegTimeOut','studentController@CourseRegTimeOut');
//Course Registration End

//Student Complete Course List
Route::get('/completeCourse','studentController@completeCourse');






//Student Application
Route::get('/application','studentController@application');

Route::post('/application','studentController@application')->name('application') ;







//##########--ACADEMIC---##########

 //Academic Admin Page
Route::get('/academicOffice','academicController@academicOffice');
Route::get('/academicSidebar','academicController@academicSidebar');


//Register Page
Route::get('/academicRegisterForm','academicController@academicRegisterForm');
Route::post('/academicRegisterFormEntry','academicController@academicRegisterFormEntry');

//Admin Login
Route::get('/academicLoginForm','academicController@academicLoginForm');
Route::post('/academicLogin','academicController@academicLogin');
Route::get('/academicLogout','academicController@academicLogout');


//Start Form
	//CSE Form
	Route::get('/cseForm','academicController@cseForm');
//Student Information
	Route::get('/studentInformation','academicController@studentInformation');

//Student Information List Edit & Delete
Route::get('/editreq/{ID}', 'PagesController@editreq') ;
Route::get('/delreq/{ID}', 'PagesController@delreq');
Route::post('/editsv', 'PagesController@editsv') ;
 
//Approval For Academic Office
Route::get('/approval/{ID}', 'PagesController@approval');

//Approval For Account Office
Route::get('/approval2/{ID}', 'PagesController@approval2');




//Course Offer
	Route::get('/subjectForm','academicController@subjectForm');
	Route::post('/subjectInput','academicController@subjectInput')->name('subjectInput');
	Route::get('/courseOffer','academicController@courseOffer');

	Route::get('/ETeditreq/{ID}', 'academicController@ETeditreq') ;
	Route::post('/ETeditsv', 'academicController@ETeditsv') ;
	Route::get('/RegEndTime', 'academicController@RegEndTime') ;



//Course Approval
	Route::get('/courseApproved','academicController@courseApproved');	
	Route::get('/approvalForCourse/{ID}', 'academicController@approvalForCourse');
	Route::post('/CourseSearch','academicController@CourseSearch')->name('CourseSearch');

//Class Routine Update
	Route::get('/classRoutineList', 'academicController@classRoutineList') ;
	Route::get('/classRoutineFormPage', 'academicController@classRoutineFormPage') ;
	Route::post('/classRoutineFormPage', 'academicController@classRoutineFormPage')->name('Saturday') ;
	 


 Route::get('/routineeditreq/{ID}', 'academicController@routineeditreq') ;
Route::get('/routinedelreq/{ID}', 'academicController@routinedelreq');
Route::post('/routineeditsv', 'academicController@routineeditsv') ;


	//teachersEvolutionTable

	Route::get('/teachersEvolutionTable','academicController@teachersEvolutionTable');
	Route::post('/teachersEvolution','academicController@teachersEvolution')->name('teachersEvolution') ;
	Route::get('/teachersEvolutionList','academicController@teachersEvolutionList');


//Drop Semester
	Route::get('/semesterDrop','academicController@semesterDrop');
Route::post('/semesterDropApply','academicController@semesterDropApply')->name('semesterDropApply') ;
	Route::get('/semesterDropList','academicController@semesterDropList');






	
//Start Table
	//CSE Table
	Route::get('/cseTable','academicController@cseTable');
 

//Start Student Admissiion Input & Output
//Form
Route::get('/studentInformationInsert','academicController@studentInformationInsert');
 Route::post('/studentInformationInsert','academicController@studentInformationInsert')->name('studentInformationInsert') ;

//Table
 Route::get('/studentInformationList','academicController@studentInformationList');

 //Studnet Information List Search
Route::post('/stdInformationSearch','academicController@stdInformationSearch')->name('stdSearch');
//drop down 

Route::get('/courseRegistrationRoutine','academicController@courseRegistrationRoutine');
//End Student Admissiion Input & Output


 //Form Test but right

Route::post('/studentListstore','academicController@studentListstore')->name('studentListstore') ;

Route::get('/studentData','academicController@studentData');


//Start Course Registration Input and Output
Route::post('/store','academicController@store')->name('store') ;
Route::get('/courseList','academicController@courseList');
//End Course Registration Input and Output


 
//Student Course Registratio List Edit Start
 Route::get('/courseEditReq/{student_id}', 'studentController@courseEditReq') ;
Route::get('/courseDelReq/{student_id}', 'studentController@courseDelReq');
Route::post('/courseEditsv', 'studentController@courseEditsv') ;
Route::get('/studentCourseRegistrationList', 'studentController@studentCourseRegistrationList') ;
Route::post('/studentCourseRegistrationList', 'studentController@studentCourseRegistrationList') ;
//Student Course Registratio List Edit End


//Convocation
Route::get('/convocation','academicController@convocation');









//##########--ACCOUNTS---##########
//Acocunt Office Main Page
Route::get('/accountOffice','accountController@accountOffice');


//Register Page
Route::get('/accountRegisterForm','accountController@accountRegisterForm');
Route::post('/accountRegisterFormEntry','accountController@accountRegisterFormEntry');

//Admin Login
Route::get('/accountLoginForm','accountController@accountLoginForm');
Route::post('/accountLogin','accountController@accountLogin');
Route::get('/accountLogout','accountController@accountLogout');



//Student Information
Route::get('/studentInformationAcc','accountController@studentInformationAcc');


//Waiver Check Start
//Waiver Page
Route::get('/waiverFormPage','accountController@waiverFormPage');
//Waiver Form
Route::post('/waiverForm','accountController@waiverForm')->name('waiverForm') ;


//Table
Route::get('/waiverCheck','accountController@waiverCheck');
 
//Search
Route::post('/waiverSearch','accountController@waiverSearch')->name('wsearch');
//Waiver Check End

//Student Payment Ledger
Route::get('/studentPaymentLedgerForm','accountController@studentPaymentLedgerForm');
Route::post('/studentPaymentLedgerStore','accountController@studentPaymentLedgerStore')->name('studentPaymentLedgerStore');
Route::get('/studentPaymentLedger','accountController@studentPaymentLedger');


//Payment Scheme For Student
Route::get('/paymentScheme','accountController@paymentScheme');
//For Student
Route::get('/studentPaymentDetails','accountController@studentPaymentDetails');
Route::post('/studentPaymentDetailsSearch','accountController@studentPaymentDetailsSearch')->name('SPDSearch') ;


//Student Result
	Route::get('/studentResultAcc','accountController@studentResultAcc');
Route::post('/studentResultAccSearch','accountController@studentResultAccSearch')->name('StdRSearch');











//##########--EXAM CONTROLLER---##########
Route::get('/examOffice','examController@examOffice');

//Register Page
Route::get('/examRegisterForm','examController@examRegisterForm');
Route::post('/accountRegisterFormEntry','examController@examRegisterFormEntry');

//Admin Login
Route::get('/examLoginForm','examController@examLoginForm');
Route::post('/examLogin','examController@examLogin');
Route::get('/examLogout','examController@examLogout');



//Student Information
Route::get('/studentInformationExam','examController@studentInformationExam');


//For Running Student

//Result Scheme/GPA In Chart
Route::get('/resultScheme','examController@resultScheme');

//Student Result/Grade Sheet In Table
Route::get('/studentResult','examController@studentResult');
Route::post('/studentResultSearch','examController@studentResultSearch')->name('SRsearch');

Route::get('/SReditreq/{ID}', 'examController@SReditreq') ;
Route::post('/SReditsv', 'examController@SReditsv') ;


 

//Live Result
Route::get('/liveResult','examController@liveResult');
Route::post('/liveResultSearch','examController@liveResultSearch')->name('lRSearch');

Route::get('/liveResultInputPage','examController@liveResultInputPage');
Route::get('/liveResultInput','examController@liveResultInput');
Route::post('/StdLRSearch','examController@StdLRSearch')->name('stdLRSearch');

Route::get('/Lieditreq/{id}', 'examController@Lieditreq') ;
Route::post('/Lieditsv', 'examController@Lieditsv') ;
 


Route::get('/action', 'examController@action') ;

Route::get('/Leditreq/{ID}', 'examController@Leditreq') ;
Route::get('/Ldelreq/{ID}', 'examController@Ldelreq');
Route::post('/Leditsv', 'examController@Leditsv') ;


//Certificate And Transcript
Route::get('/certificate','examController@certificate');
Route::post('/certificate','examController@certificate')->name('certificate');
Route::get('/CertificateStdInfo','examController@CertificateStdInfo');
Route::get('/certificateApplicationList','examController@certificateApplicationList');





//For Alumni Student

//Start Result Verification
	//Form
Route::get('/resultVerifyFormPage','examController@resultVerifyFormPage');

Route::post('/resultVerifyForm','examController@resultVerifyForm')->name('resultVerifyForm') ;
	//Form End
Route::get('/resultVerifyList','examController@resultVerifyList');
Route::post('/resultVerifySearch','examController@resultVerifySearch')->name('search');
//End Result Verification



//Admit Card
Route::get('/admitCard','academicController@admitCard');
Route::get('/admitSerial','academicController@admitSerial');











//##########--HUB CONTROLLER---##########

Route::get('/about','hubController@about');
Route::get('/contact','hubController@contact');
Route::get('/rulesAndRegulation','hubController@rulesAndRegulation');


//// Forget password 

Route::post('/fgp','pagesController@fgp');
Route::get('/fgp','pagesController@fgp');

Route::post('/rc','pagesController@rc');
Route::get('/rc','pagesController@rc');
Route::post('/chp','pagesController@chp');
Route::get('/chp','pagesController@chp');
//




 
 

