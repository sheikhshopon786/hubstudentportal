<?php $__env->startSection('content'); ?>
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Upload Course List</b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
              <form action="<?php echo e(route('store')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>

                <div class="card-body">

                  <div class="form-group"> 
              <label for="session">Session</label>
              <input type="text" class="form-control" id="session" placeholder="Session" name="session">   
                  </div>

                  <div class="form-group">
              <label for="semester">Semester</label>
              <input type="text" class="form-control" id="semester" placeholder="Semester" name="semester">
                  </div>

                  <div class="form-group">
                    <label for="course_code">Course Code</label>
              <input type="text" class="form-control" id="course_code" placeholder=" Course code" name="course_code">
                  </div>

                  <div class="form-group">
                    <label for="course_title">Course Tittle</label>
              <input type="text" class="form-control" id="course_title" placeholder="Course Tittle" name="course_title">
              </div>



                  <div class="form-group">
                    <label for="section">Section</label>
              <input type="text" class="form-control" id="section" placeholder="Section" name="section">
                  </div>


                  <div class="form-group"> 
              <label for="credit_hour">Credit Hour </label>
              <input type="text" class="form-control" id="credit_hour" placeholder="Credit Hour" name="credit_hour">   
                  </div>

          
                  <div class="form-group">
              <label for="department">Department</label>
              <input type="text" class="form-control" id="department" placeholder="department" name="department">
                  </div>

                  <div class="form-group">
                    <label for="teacher_name">Teacher Name</label>
              <input type="text" class="form-control" id="teacher_name" placeholder=" Teacher Name" name="teacher_name">
                  </div>

                  <div class="form-group">
                    <label for="day">Day</label>
              <input type="text" class="form-control" id="day" placeholder="Day" name="day">
              </div>



                  <div class="form-group">
                    <label for="time">Time</label>
              <input type="time" class="form-control" id="time" placeholder="Time" name="time">
                  </div>


                  <div class="form-group"> 
              <label for="room_no">Room No</label>
              <input type="text" class="form-control" id="room_no" placeholder="Room No" name="room_no">   
                  </div>





               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\final\student_portal\resources\views/academic/courseOffer.blade.php ENDPATH**/ ?>