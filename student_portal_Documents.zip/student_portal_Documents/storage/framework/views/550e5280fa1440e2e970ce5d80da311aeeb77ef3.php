<?php $__env->startSection('content'); ?>




<div class="col-md-12">
	<h2><b><u>ABOUT US</u></b></h2>
	<h4>
		<p>
		<b>Being approved by the University Grants Commission of Bangladesh (UGC) and the Government on 14 March 2012, Hamdard University Bangladesh (HUB)</b> started its academic programs on 29 November 2012. It is a non-political and not-for-profit organization, established under the Private University Act 2010 (Law number 35). Abiding by this Law, the core values of the University are based on the philanthropic characteristics of its affiliated/ mother organization—Hamdard Laboratories (Waqf) Bangladesh and Hamdard Foundation—resonating love for humanity, belief in pluralistic society, equal opportunity for all, democratic decision making process, promotion of education, technology and culture and the like.<br><br>

Hamdard University Bangladesh is the culmination of the vision and brainchild of Dr. Hakim Mohammad Yousuf Harun Bhuiyan. It was his long cherished desire to set up a “City of Science, Education & Culture” and couch the University in it as the central focus. Dr. Hakim Mohammad Yousuf Harun Bhuiyan, the architect of Hamdard University Bangladesh, is also the pioneer of modern Hamdard Bangladesh. He is the Managing Director of Hamdard Laboratories (Waqf) Bangladesh and Secretary General of Hamdard Foundation Bangladesh, the sole funding agency of this University.<br><br>

Reflecting the ideals of its mother organization, the University welcomes and respects all whose lives are formed by different traditions and customs recognizing their respective contributions to our society. HUB maintains an academic environment congenial to open discussion essential for broadening higher faculties of mind. As a community of learners, the University encourages brotherhood, mutual learning, shared decision making, and intellectual/ academic freedom.</p>
	</h4>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/hub/about.blade.php ENDPATH**/ ?>