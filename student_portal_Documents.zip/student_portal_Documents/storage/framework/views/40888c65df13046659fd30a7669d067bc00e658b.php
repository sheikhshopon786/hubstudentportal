<?php $__env->startSection('content'); ?>

<h1><b>S EXAM CONTROLLER OFFICE</b></h1>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('exam.examOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/admin/exm/SexamIndex.blade.php ENDPATH**/ ?>