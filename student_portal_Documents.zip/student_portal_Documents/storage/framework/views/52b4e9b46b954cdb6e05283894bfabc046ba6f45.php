<?php $__env->startSection('content'); ?>


<style>
.ct {
  text-align: center;
  font-size: 20px;
  margin-top: 0px;
  width: 50%;

}
</style>




<div class="col-12">




            <div class="card">

              <div class="card-header">
                <h3 class="card-title">Course Registration</h3>  
              </div>
              <!-- /.card-header -->

<!-- Countdown Timer Start -->
            <div class="card-header">
              <h3 class="card-title">Registration Time is Over After:</h3>  
            </div>

<b><p class="ct" id="demo"></p></b>


<script>
// Set the date we're counting down to
var countDownDate = new Date("2020-01-25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "d: " + hours + "h: "
  + minutes + "m: " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
<!-- Countdown Timer End -->



   
              <div class="card-body table-responsive p-0" style="height: 500px;">

              <a href="<?php echo e(url('/studentCourseRegistrationList')); ?>" >
                  <div role="group" class="btn-group-lg btn-group btn-group-toggle" style="text-decoration: none; float: right;">
                <label class="btn btn-focus">
                 Please Check Your Select Course
                </label>
                </div>
              </a>

 
       <form action="<?php echo e(url('courseRegistration')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>



      <select name="semester" style="width: 50%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Semester
            </option>
            <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($semester->semester); ?>"><?php echo e($semester->semester); ?></option>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </select>
<br>


   
       <select name="courseCodeTitile" style="width: 50%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Course
            </option>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($data->course_code); ?> <?php echo e($data->course_title); ?>"><?php echo e($data->course_code); ?> <?php echo e($data->course_title); ?></option>
            
           
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </select>

        <button type="submit" class="btn btn-primary">Submit</button>
      </form>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>


       <a href="<?php echo e(url('/completeCourse')); ?>" style="text-decoration:none;" >
                  <div role="group" class="btn-group-lg btn-group btn-group-toggle" style="width:100%;">
                <label class="btn btn-focus">
                See your complete course list
                </label>
                </div>
              </a>

      

  </div>
              <!-- /.card-body -->
            
     
        <!-- /.row -->





 


  
   

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/student/courseRegistrationPage.blade.php ENDPATH**/ ?>