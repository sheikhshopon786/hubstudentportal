<?php $__env->startSection('content'); ?>
<h5><b>Payment Ledger For Current Semester</b></h5><br>

<?php $__currentLoopData = $paymentBox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentBox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  

								<div class="row">
								<div class="col-lg-12 col-xl-3">
                                    <div class="card mb-3 widget-content bg-premium-dark">
                                        <div class="widget-content-wrapper text-white">
                                            <div class="widget-content-left">
                                                <div class="widget-heading"><?php echo e($paymentBox->PaymentType); ?>

                                                </div>  
                                            </div>

                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-warning"><span>৳<?php echo e($paymentBox->PaymentAmount); ?></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                 
                            <!--
                                <div class="col-lg-12 col-xl-3">
                                    <div class="card mb-3 widget-content bg-premium-dark">
                                        <div class="widget-content-wrapper text-white">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">Total Others</div>
                                                 
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-warning"><span>৳0.00</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
 							</div>
                        -->



<!-- Styles -->
<style>
#chartdiv {
  width: 100%;
  height: 360px;
}

</style>

<!-- Resources -->
<script src="https://www.amcharts.com/lib/4/core.js"></script>
<script src="https://www.amcharts.com/lib/4/charts.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>

<!-- Chart code -->
<script>
am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

// Create chart instance
var chart = am4core.create("chartdiv", am4charts.XYChart);

// Add data
chart.data = [
<?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
{

  "country": "<?php echo e($payment->FeeType); ?>",
  "visits": "<?php echo e($payment->Amount); ?>"
},
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

 



];

// Create axes

var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "country";
categoryAxis.renderer.grid.template.location = 0;
categoryAxis.renderer.minGridDistance = 30;

categoryAxis.renderer.labels.template.adapter.add("dy", function(dy, target) {
  if (target.dataItem && target.dataItem.index & 2 == 2) {
    return dy + 25;
  }
  return dy;
});

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

// Create series
var series = chart.series.push(new am4charts.ColumnSeries());
series.dataFields.valueY = "visits";
series.dataFields.categoryX = "country";
series.name = "Visits";
series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
series.columns.template.fillOpacity = .8;

var columnTemplate = series.columns.template;
columnTemplate.strokeWidth = 2;
columnTemplate.strokeOpacity = 1;

}); // end am4core.ready()
</script>

<!-- HTML -->

    <div class="col-md-12">
        <div id="chartdiv"></div>
        <b>Fee Name</b>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/account/paymentScheme.blade.php ENDPATH**/ ?>