<?php $__env->startSection('content'); ?>
<!-- form start-2 -->
 
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Course Offer & Class Schedule</b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
 <form action="<?php echo e(route('store')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>

      <div class="card-body">



          <select value="semester" name="semester" id="semester"      style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Semester
              </option>
              <option value="Spring, 2019">
                Spring, 2019
              </option>
              <option value="Fall, 2019">
                Fall, 2019
              </option>
              <option value="Spring, 2020">
                Spring, 2020
              </option>
           </select>


          

           <select value="courseCodeTitile" name="courseCodeTitile" id="courseCodeTitile" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Course Code & Titile
              </option>


              <option value="ENG 111  English Basics">
               ENG 111  English Basics
              </option>

              <option value="ENG 127  Communicative English">
               ENG 127  Communicative English
              </option>
              <option value="BAN 211  Bangladesh Studies">
               BAN 211  Bangladesh Studies
              </option>
              <option value="ENS  221 Environmental Science">
               ENS  221 Environmental Science
              </option>
              <option value="ACT  215 Financial and Managerial Accounting">
               ACT  215 Financial and Managerial Accounting
              </option>
              <option value="MGT 418  Industrial and Operational Management">
               MGT 418  Industrial and Operational Management
              </option>
              <option value="PHY 111  Physics I (Waves & Oscillation, Optical and Thermal Physics)">
               PHY 111  Physics I (Waves & Oscillation, Optical and Thermal Physics)
              </option>
              <option value="MAT 115  Mathematics-I (Differential & Integral Calculus)">
               MAT 115  Mathematics-I (Differential & Integral Calculus)
              </option>
              <option value="MAT 125  Mathematics-II (Linear Algebra and Complex Variables)">
               MAT 125  Mathematics-II (Linear Algebra and Complex Variables)
              </option>
              <option value="PHY  121 Physics II (Mechanics, Electricity, Magnetism & Modern Physics)">
               PHY  121 Physics II (Mechanics, Electricity, Magnetism & Modern Physics)
              </option>
              <option value="PHY  122 Physics II  Lab">
               PHY  122 Physics II  Lab
              </option>
              <option value="MAT 216  Mathematics-III (Ordinary & Partial Differential Equation)">
               MAT 216  Mathematics-III (Ordinary & Partial Differential Equation)
              </option>
              <option value="MAT 213  Statistics & Probability">
               MAT 213  Statistics & Probability
              </option>
              <option value="MAT 317  Engineering Mathematics (Mathematical Methods)">
               MAT 317  Engineering Mathematics (Mathematical Methods)
              </option>
              <option value="MAT 323  Numerical Analysis">
               MAT 323  Numerical Analysis
              </option>
              <option value="CSE  111 Computer Fundamentals">
               CSE  111 Computer Fundamentals
              </option>
              <option value="EEE  116 Electrical Engineering">
               EEE  116 Electrical Engineering
              </option>
              <option value="EEE  117 Electronic Devices & Circuits">
               EEE  117 Electronic Devices & Circuits
              </option>
              <option value="EEE  118 Electrical and Electronic Circuits Lab">
               EEE  118 Electrical and Electronic Circuits Lab
              </option>
              <option value="CSE  121 Structured Programming Language">
               CSE  121 Structured Programming Language
              </option>
              <option value="CSE  122 Structured Programming Language Lab">
               CSE  122 Structured Programming Language Lab
              </option>
              <option value="CSE  123 Discrete Mathematics">
               CSE  123 Discrete Mathematics
              </option>
              <option value="CSE  211 Data Structure">
               CSE  211 Data Structure
              </option>
              <option value="CSE  212 Data Structure Lab.">
               CSE  212 Data Structure Lab.
              </option>
              <option value="CSE  213 Digital Electronics and Pulse Techniques">
               CSE  213 Digital Electronics and Pulse Techniques
              </option>
              <option value="CSE  214 Digital Electronics and Pulse Techniques Lab">
               CSE  214 Digital Electronics and Pulse Techniques Lab
              </option>
              <option value="CSE  221 Computer Algorithms">
               CSE  221 Computer Algorithms
              </option>
              <option value="CSE  222 Computer Algorithms Lab">
               CSE  222 Computer Algorithms Lab
              </option>
              <option value="CSE  223 Object Oriented Programming in Java">
               CSE  223 Object Oriented Programming in Java
              </option>
              <option value="CSE  224 Object Oriented Programming in Java Lab">
               CSE  224 Object Oriented Programming in Java Lab
              </option>
              <option value="CSE  225 Digital Logic Design">
               CSE  225 Digital Logic Design
              </option>
              <option value="CSE  226 Digital Logic Design Laboratory">
               CSE  226 Digital Logic Design Laboratory
              </option>
              <option value="CSE  227 Data Communication">
               CSE  227 Data Communication
              </option>
              <option value="CSE  311 Computer Architecture">
               CSE  311 Computer Architecture
              </option>
              <option value="CSE  312 Database Management System (DBMS)">
               CSE  312 Database Management System (DBMS)
              </option>
              <option value="CSE  313 Database Management System (DBMS) Lab">
               CSE  313 Database Management System (DBMS) Lab
              </option>
              <option value="CSE  314 Microprocessors & Microcontrollers">
               CSE  314 Microprocessors & Microcontrollers
              </option>
              <option value="CSE  315 Microprocessors & Microcontrollers Lab">
               CSE  315 Microprocessors & Microcontrollers Lab
              </option>
              <option value="CSE  316 Computer Networks">
               CSE  316 Computer Networks
              </option>
              <option value="CSE  317 Computer Networks Lab">
               CSE  317 Computer Networks Lab
              </option>
              <option value="CSE  321 Theory of Computing">
               CSE  321 Theory of Computing
              </option>
              <option value="CSE  322 Operating System">
               CSE  322 Operating System
              </option>
              <option value="CSE  323 Operating System Lab">
               CSE  323 Operating System Lab
              </option>
              <option value="CSE  324 System Analysis & Design">
               CSE  324 System Analysis & Design
              </option>
              <option value="CSE  325 Computer Peripherals & Interfacing">
               CSE  325 Computer Peripherals & Interfacing
              </option>
              <option value="CSE  326 Computer Peripherals & Interfacing Lab">
               CSE  326 Computer Peripherals & Interfacing Lab
              </option>
              <option value="CSE  411 Artificial Intelligence">
               CSE  411 Artificial Intelligence
              </option>
              <option value="CSE  412 Artificial Intelligence Lab">
               CSE  412 Artificial Intelligence Lab
              </option>
              <option value="CSE  413 Computer Graphics">
               CSE  413 Computer Graphics
              </option>
                <option value="CSE  414 Computer Graphics Lab">
               CSE  414 Computer Graphics Lab
              </option>
                <option value="CSE  415 Compiler  Design">
               CSE  415 Compiler  Design
              </option>
                <option value="CSE  416 Compiler Design  Lab">
               CSE  416 Compiler Design  Lab
              </option>
                <option value="CSE  417 Communication Engineering">
               CSE  417 Communication Engineering
              </option>
                <option value="CSE  421 Simulation and Modeling">
               CSE  421 Simulation and Modeling
              </option>
                <option value="CSE  422 Software Engineering">
               CSE  422 Software Engineering
              </option>
                <option value="CSE  431 Multimedia System Design">
               CSE  431 Multimedia System Design
              </option>
                <option value="CSE  432 Telecommunication Engineering">
               CSE  432 Telecommunication Engineering
              </option>
                <option value="CSE  433 Web Engineering">
               CSE  433 Web Engineering
              </option>
                <option value="CSE  434 Optical Fiber Communication">
               CSE  434 Optical Fiber Communication
              </option>
                <option value="CSE  435 Distributed System">
               CSE  435 Distributed System
              </option>
                <option value="CSE  436 Network Programming">
               CSE  436 Network Programming
              </option>
                <option value="CSE  437 Pattern Recognition">
               CSE  437 Pattern Recognition
              </option>
                <option value="CSE  438 VLSI Design">
               CSE  438 VLSI Design
              </option>
                <option value="CSE  439 Cellular & Mobile Communication">
               CSE  439 Cellular & Mobile Communication
              </option>
                <option value="CSE  441 Digital Communications">
               CSE  441 Digital Communications
              </option>
                <option value="CSE  442 Wireless, Mobile & Satellite Communication">
               CSE  442 Wireless, Mobile & Satellite Communication
              </option>
                <option value="CSE  443 Telecommunication Transmission and Switching">
               CSE  443 Telecommunication Transmission and Switching
              </option>
                <option value="CSE  444 Broadcast Technologies">
               CSE  444 Broadcast Technologies
              </option>
                <option value="CSE  445 Mobile Network Management and Security">
               CSE  445 Mobile Network Management and Security
              </option>
                <option value="CSE  446 Digital signal processing">
               CSE  446 Digital signal processing
              </option>
                <option value="CSE  447 Embedded Network Systems">
               CSE  447 Embedded Network Systems
              </option>
                <option value="CSE  448 Client Server Computing">
               CSE  448 Client Server Computing
              </option>
                <option value="CSE  449 Decision support system">
               CSE  449 Decision support system
              </option>
                <option value="CSE  451 Wireless Network">
               CSE  451 Wireless Network
              </option>
                <option value="CSE  452 Image Processing">
               CSE  452 Image Processing
              </option>
                <option value="CSE  453 Computer and Network Security">
               CSE  453 Computer and Network Security
              </option>
               <option value="CSE  454  Parallel Processing">
               CSE  454 Parallel Processing
              </option>
              <option value="CSE  455 Robotics Technology">
               CSE  455 Robotics Technology
              </option>
              <option value="CSE  456 E-commerce & E-business">
               CSE  456 E-commerce & E-business
              </option>
              <option value="CSE  457 Cloud Computing">
               CSE  457 Cloud Computing
              </option>
              <option value="CSE  458 Advanced Database Management System">
               CSE  458 Advanced Database Management System
              </option>
           </select>



           <select value="section" name="section" id="section" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Course Section
              </option>
              <option value="1">
                1
              </option>
              <option value="2">
                2
              </option>
              <option value="3">
                3
              </option>
              <option value="4">
                4
              </option>
           </select>

           <select value="credit_hour" name="credit_hour" id="credit_hour" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Credit Hour
              </option>
              <option value="1.0">
                1.0
              </option>
              <option value="1.5">
                1.5
              </option>
              <option value="3.0">
                3.0
              </option>
           </select>

           <select value="department" name="department" id="department" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Department
              </option>
              <option value="B.Sc in Computer Science & Engineering">
                 B.Sc in Computer Science & Engineering
              </option>
              <option value="B.Sc in Electrical & Electronics Engineering">
                B.Sc in Electrical & Electronics Engineering
              </option>
              
           </select>

           <select value="teacher_name" name="teacher_name" id="teacher_name" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Teacher
              </option>
              <option value="HM">
                HM
              </option>
              <option value=" MAR">
                MAR
              </option>
              <option value="AR">
                AR
              </option>

               <option value="RA">
                RA
              </option>
              
           </select>


           <select value="day" name="day" id="day" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Day
              </option>
              <option value="Saturday">
                Saturday
              </option>
              <option value="Sunday">
                Sunday
              </option>
              <option value="Monday">
                Monday
              </option>
              <option value="Tuesday">
                Tuesday
              </option>
              <option value="Wednesday">
                Wednesday
              </option>
              <option value="Thursday">
                Thursday
              </option>
              <option value="Friday">
                Friday
              </option>
           </select>


                  <div class="form-group">
                    <label for="starting_time">Starting Time</label>
              <input type="time" class="form-control" id="starting_time" placeholder="Starting Time" name="starting_time" required="">
                  </div>

                  <div class="form-group">
                    <label for="ending_time">Ending Time</label>
              <input type="time" class="form-control" id="ending_time" placeholder="Ending Time" name="ending_time" required="">
                  </div>

            <select value="room_no" name="room_no" id="room_no" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Room No
              </option>
              <option value="142">
                142
              </option>
              <option value="249">
                249
              </option>
              <option value="CL Lab-1">
                CL Lab-1
              </option>
           </select>

           <div class="form-group">
                    <label for="ending_time">Course Registration End Date</label>
              <input type="text" class="form-control" id="reg_end_time" placeholder="Insert Date&Month" name="reg_end_time">
                  </div>

          





               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->
 
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.aca.SacademicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/admin/aca/ScourseOffer.blade.php ENDPATH**/ ?>