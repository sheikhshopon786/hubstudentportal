<?php $__env->startSection('content'); ?>

<div>
	<h1>Opps!!! Registration Time is Over</h1>
	<h4> Please Contact With Academic Office.</h4>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/student/CourseRegTimeOut.blade.php ENDPATH**/ ?>