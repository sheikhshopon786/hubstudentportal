 
 <?php $__env->startSection('content'); ?>
 




    <div class="row">
      <div class="col-2">
<?php $__currentLoopData = $studentInformationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentInformationList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1 class="display-4"><span class="badge badge-secondary"><?php echo e($studentInformationList->Date); ?></span></h1>
       
      </div>
    </div>



    <div class="row">
      <div class="col-md-12">
        <a href="<?php echo e(url('/noticeeditreq',$studentInformationList->ID)); ?>" class="" style="text-decoration: none; color:#615f5b ">
          <h3 class=""><strong><?php echo e($studentInformationList->Title); ?></strong></h3>
        </a>
        <a href="<?php echo e(url('/noticeeditreq',$studentInformationList->ID)); ?>" class="" style="text-decoration: none; color: #615f5b;"><b>Read More</b><i class="fa fa-arrow-circle-right"> </i></a>

        
      </div>
    </div>




    <div class="row">
       <div class="col-7">
        <ul class="list-inline">
          <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo e($studentInformationList->Day); ?></li>

          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e($studentInformationList->StartingTime); ?> - <?php echo e($studentInformationList->EndingTime); ?></li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> <?php echo e($studentInformationList->Location); ?></li>

          <li class="list-inline-item"><i class="pe-7s-news-paper" aria-hidden="true"></i>Category- <?php echo e($studentInformationList->Category); ?></li>
        </ul> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
      </div>
    </div>



 
      

   

   
 


   
 
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/partial/notice1.blade.php ENDPATH**/ ?>