<?php $__env->startSection('content'); ?>
 

 


<div class="card-body"><h4 class="" style="text-align: center;"><b>Semester Result</b></h4>


<form action="<?php echo e(route('subjectRejultSearch')); ?>" method="post" 
    enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>




<select value="semester" name="semester" id="semester"  style="width: 50%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Semester
            </option>
            <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($semester->semester); ?>"><?php echo e($semester->semester); ?></option>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </select>




    <button type="submit" class="btn btn-primary">Submit</button> 
</form>



    <br><br><br><br>
<caption style="text-align: center;"><h6><b>Semester Result</b></h6></caption>
  <table class="mb-0 table table-dark">

    <thead>
      <tr>
        <!--<th>Semester</th>-->
        <th style="text-align: left;">Course Code and Title</th>
        <th style="text-align: center;">Credit</th>
        <th style="text-align: center;">Letter Grade</th>
        <th style="text-align: center;">Grade Value</th>
               
      </tr>
    </thead>

    <tbody>
<?php $__currentLoopData = $subjectResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($subjectResult->courseCodeTitile); ?></td>
        <td style="text-align: center;"><?php echo e($subjectResult->credit_hour); ?></td>
        <td style="text-align: center;"><?php echo e($subjectResult->Grade); ?></td>
        <td style="text-align: center;"><?php echo e($subjectResult->GradePoint); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <tr>    
        <?php $__currentLoopData = $SGPA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SGPA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td style="text-align: center;"><b>Total SGPA:</b> <?php echo e($SGPA->GPA); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
      </tr> 
    </tbody>

  </table>
 
  
</div>








































































 



<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/student/subjectResult.blade.php ENDPATH**/ ?>