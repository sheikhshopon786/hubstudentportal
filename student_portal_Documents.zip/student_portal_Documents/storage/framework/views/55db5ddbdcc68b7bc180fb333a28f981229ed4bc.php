<?php $__env->startSection('content'); ?>
 
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Course List</h3>  

             
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table class="table table-hover">
         <thead>
            <tr>
              <th scope="col">Semester</th>
              <th scope="col">Course Code</th>
              <th scope="col">Course Title</th>
              <th scope="col">Section</th>
              <th scope="col">Credit Hour</th>      
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($data->semester); ?></td>
              <td><?php echo e($data->course_code); ?></td>
              <td><?php echo e($data->course_title); ?></td>
              <td><?php echo e($data->section); ?></td>
              <td><?php echo e($data->credit_hour); ?></td>
            </tr>                  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
     
        <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\final\student_portal\resources\views/academic/courseList.blade.php ENDPATH**/ ?>