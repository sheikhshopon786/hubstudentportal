<link rel="stylesheet" href="<?php echo e(URL::asset('main.css')); ?>">

 
 
 
<!--Start Celender-->

  <link rel="stylesheet" href="plugins/fullcalendar/main.min.css">
  <link rel="stylesheet" href="plugins/fullcalendar-interaction/main.min.css">
  <link rel="stylesheet" href="plugins/fullcalendar-daygrid/main.min.css">
  <link rel="stylesheet" href="plugins/fullcalendar-timegrid/main.min.css">
  <link rel="stylesheet" href="plugins/fullcalendar-bootstrap/main.min.css">

<!--End Celender-->


<?php /**PATH C:\Users\User\Desktop\15.12.19\student_portal\resources\views/links/css.blade.php ENDPATH**/ ?>