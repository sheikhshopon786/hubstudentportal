<?php $__env->startSection('content'); ?>

<div class="col-md-12">
	<img src="images/accountIndexPic.jpg">
</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('account.accountOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/account/accountIndex.blade.php ENDPATH**/ ?>