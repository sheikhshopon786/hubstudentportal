<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<table>
     <tr>
     	
    	<td><img src="<?php echo e(url('/')); ?>/image/<?php echo e($data->image); ?>"></td>
    </tr>
    </table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/partial/picturePage.blade.php ENDPATH**/ ?>