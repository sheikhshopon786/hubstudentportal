<?php $__env->startSection('content'); ?>
     <div class="col-md-9" >
          <div class="widget" style="margin-left: 10px;">
          	
             
          	<div >
              <div class="row">

                    
      <form action="/ETeditsv" method="post" enctype="multipart/form-data" >
      	<?php echo e(csrf_field()); ?>


  

 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
 <div class="form-group">
    <label for="ID">ID</label>
    <input type="text" class="form-control" id="ID" placeholder="Tittle" name="ID" readonly value="<?php echo e($data->ID); ?>">
  </div>

  
  <div class="form-group">
    <label for="endTime">Please Enter The Date and Month</label>
    <input type="text" class="form-control" id="endTime" placeholder="Please Enter The Date and Month" name="endTime" value="<?php echo e($data->endTime); ?>">
  </div>

   

    
 

  <button type="submit" class="btn btn-primary">Save</button>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>


		</div>
		</div>

		</div>
		</div>
		
<?php $__env->stopSection(); ?>		

<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/academic/RegEndTimeEdit.blade.php ENDPATH**/ ?>