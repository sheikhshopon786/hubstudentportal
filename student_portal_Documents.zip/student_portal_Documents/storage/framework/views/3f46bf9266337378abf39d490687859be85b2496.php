<?php $__env->startSection('content'); ?>

 
<div class="col-lg-12">
        
          <h3 class="card-title">All Students</h3>
            <div class="card-tools">
              <form action="<?php echo e(route('stdLRSearch')); ?>" method="post" 
                  enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="stdLRSearch" placeholder="Enter Student ID" name="stdLRSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 
                 

  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">All Students</h5>
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>Semester</th>
              <th>Course Code & Titile</th>
              <th>Quiz1</th>
              <th>Quiz2</th>
              <th>Result Update</th>
               
              
            </tr>
          </thead>
          <tbody>
             
           <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
    
                        
          <td><?php echo e($data->student_id); ?></td>
          <td><?php echo e($data->semester); ?></td>
          <td><?php echo e($data->courseCodeTitile); ?></td>
          <td><?php echo e($data->Quiz1); ?></td>
          <td><?php echo e($data->Quiz2); ?></td>
           
           
           
          <td> 
            <a href="<?php echo e(url('/Lieditreq',$data->ID)); ?>" class="btn btn-primary">Update</a>
          </td> 
           
          
        </tr>                  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('exam.examOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/exam/liveResultInputPage.blade.php ENDPATH**/ ?>