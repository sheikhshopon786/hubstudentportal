<?php $__env->startSection('content'); ?>






<div class="card-body"><h4 class="" style="text-align: center;"><b>Live Result</b></h4>


<form action="<?php echo e(route('lRSearch')); ?>" method="post" 
    enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>




<select value="Semester" name="Semester" id="Semester"  style="width: 50%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Semester
            </option>
            <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($semester->semester); ?>"><?php echo e($semester->semester); ?></option>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </select>




    <button type="submit" class="btn btn-primary">Submit</button> 
</form>
    <br><br><br><br>
<caption style="text-align: center;"><h6><b>Registered Course List</b></h6></caption>
	<table class="mb-0 table table-dark">

		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th style="text-align: center;">Action</th>
				<th style="text-align: center;">Course Code</th>
				<th style="text-align: center;">Course Title</th>
				<th style="text-align: center;">Credit</th>
				<th style="text-align: center;">Section</th>
				<th style="text-align: center;">Teacher</th>
			</tr>
		</thead>
<?php $__currentLoopData = $liveResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liveResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				<td>

					<a href="<?php echo e(url('#',)); ?>" style="text-decoration: none;">
						<div role="group" class="btn-group-lg btn-group btn-group-toggle" >
						<button type="button" class="btn btn-alternate"> View Live Result
						</button>	
						</div>
					</a>
				</td>

			<td style="text-align: center;"><?php echo e($liveResult->courseCodeTitile); ?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $semester2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<td style="text-align: center;"><?php echo e($semester2->course_code); ?></td>
				<td style="text-align: center;"><?php echo e($semester2->section); ?></td>
				<td style="text-align: center;"><?php echo e($semester2->teacher_name); ?></td>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tr>
		</tbody>

	</table>
	
</div>



<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h6><b>Live Result :[Subject Name]</b></h6></caption>
	<table class="mb-0 table table-dark">

		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th style="text-align: center;">Quiz 1:</th>
				<th style="text-align: center;">Quiz 2:</th>
				<th style="text-align: center;">Quiz Average</th>
				<th style="text-align: center;">Midterm</th>
				<th style="text-align: center;">Midterm Improvement:</th>
			</tr>
		</thead>

		<tbody>
			<tr>

				<td style="text-align: center;">10</td>
				<td style="text-align: center;">4</td>
				<td style="text-align: center;">7</td>
				<td style="text-align: center;">20</td>
				<td style="text-align: center;">0</td>
			</tr>
		</tbody>
	</table>
</div>
					






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/exam/liveResult.blade.php ENDPATH**/ ?>