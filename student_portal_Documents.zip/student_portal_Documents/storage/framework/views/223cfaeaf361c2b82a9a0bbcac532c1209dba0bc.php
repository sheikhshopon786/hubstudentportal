<?php $__env->startSection('content'); ?>
 
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">All Students</h3>  

                <div class="card-tools">
                  <form action="<?php echo e(route('stdSearch')); ?>" method="post" 
      enctype="multipart/form-data">
       <?php echo e(csrf_field()); ?>

              <label for="" class="sr-only">ID</label>
               <input type="text" class="form-control" id="stdSearch" placeholder="Enter Student ID" name="stdSearch" required="">

              <button type="submit" class="btn btn-primary">Submit</button>             
        </form>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table border="1px" class="table table-hover">
         <thead>
            <tr> 

              <th scope="col">Student ID</th>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Present Address</th>
              <th scope="col">Parmanant Address</th>
              <th scope="col">Father's Name</th>
              <th scope="col">Mother's Name</th>
              <th scope="col">Phone</th>
              <th scope="col">Email</th>
              <th scope="col">Department</th>
              <th scope="col">Batch</th>
            <th scope="col">Date of Birth</th>
              <th scope="col">Blood Group</th>
              <th scope="col">Religion</th>
              <th scope="col">Nationality</th>
               
              <th scope="col">Update</th> 
              <th scope="col">Delete</th>       
            </tr>
   </thead>
    <tbody>
     <?php $__currentLoopData = $studentInformationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentInformationList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
    
                        
          <td><?php echo e($studentInformationList->student_id); ?></td>
          <td><?php echo e($studentInformationList->FirstName); ?></td>
          <td><?php echo e($studentInformationList->LastName); ?></td>
          <td><?php echo e($studentInformationList->PresentAddress); ?></td>
          <td><?php echo e($studentInformationList->ParmanentAddress); ?></td>
          <td><?php echo e($studentInformationList->MotherName); ?></td>
          <td><?php echo e($studentInformationList->FatherName); ?></td>
          <td><?php echo e($studentInformationList->Phone); ?></td>
          <td><?php echo e($studentInformationList->Email); ?></td>
          <td><?php echo e($studentInformationList->Department); ?></td>
          <td><?php echo e($studentInformationList->Batch); ?></td>
          <td><?php echo e($studentInformationList->DOB); ?></td>
          <td><?php echo e($studentInformationList->BG); ?></td>
          <td><?php echo e($studentInformationList->Religion); ?></td>
          <td><?php echo e($studentInformationList->Nationality); ?></td>
           
          <td><a href="<?php echo e(url('/editreq',$studentInformationList->student_id)); ?>" class="btn btn-primary">Edit</a></td> 
          <td><a href="<?php echo e(url('/delreq',$studentInformationList->student_id)); ?>" class="btn btn-danger">Delete</a></td>
        </tr>                  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
   </table>
 </div> <!-- /.card-body -->
</div><!-- /.card -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\final\student_portal\resources\views/academic/studentInformationList.blade.php ENDPATH**/ ?>