<?php $__env->startSection('content'); ?>
 


 


<div class="card-body"><h4 class="" style="text-align: center;"><b>Payment Scheme</b></h4>


<form action="<?php echo e(route('SPDSearch')); ?>" method="post" 
    enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>




<select value="semester" name="semester" id="semester"  style="width: 50%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Semester
            </option>
            <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($semester->semester); ?>"><?php echo e($semester->semester); ?></option>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </select>




    <button type="submit" class="btn btn-primary">Submit</button> 
</form>



    <br><br><br><br>
<caption style="text-align: center;"><h6><b>Payment Scheme</b></h6></caption>
	<table class="mb-0 table table-dark">

		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th style="text-align: center;">Total Payable</th>
				<th style="text-align: center;">Total Waiver</th>
				<th style="text-align: center;">Total Paid</th>
				
				 
			</tr>
		</thead>

		<tbody>
			<tr>
				<?php $__currentLoopData = $liveResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liveResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 	
				<td style="text-align: center;"><?php echo e($liveResult->TotalPayable); ?></td>
				<td style="text-align: center;"><?php echo e($liveResult->Waiver); ?></td>
				<td style="text-align: center;"><?php echo e($liveResult->PaidAmount); ?></td>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</tr>

	
			<tr>
				<td style="text-align: center;">
					<b>Total Due:-</b>
				</td>
				
				<td style="text-align: left;">
					<?php $__currentLoopData = $paymentLedger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentLedger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($paymentLedger->Due); ?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
				
			</tr>
		
		</tbody>

	</table>
	
</div>



 


 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/account/studentPaymentDetails.blade.php ENDPATH**/ ?>