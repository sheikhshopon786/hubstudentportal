<?php $__env->startSection('content'); ?>
 
<!--Student Information form start -->

<!--Student Information form End --> 

<form action="<?php echo e(url('/proUpdateReq')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 <?php echo e(csrf_field()); ?>


 <?php $__currentLoopData = $studentProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                          
 <div class="card-body">
     <h4 class="card-title">Update profile</h4>


     <div class="form-group row">
        <label for="student_id" class="col-sm-3 text-right control-label col-form-label">Student ID</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="student_id" placeholder="Last Name" name="student_id" readonly value="<?php echo e($data->student_id); ?>">
        </div>
    </div>


    <div class="form-group row">
      <label for="FirstName" class="col-sm-3 text-right control-label col-form-label">First Name</label>
      <div class="col-sm-9">
          <input type="text" class="form-control" id="FirstName" placeholder="First Name" name="FirstName" readonly value="<?php echo e($data->FirstName); ?>">
      </div>
  </div>



  <div class="form-group row">
    <label for="LastName" class="col-sm-3 text-right control-label col-form-label">Last Name</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="LastName" placeholder="Last Name" name="LastName" readonly value="<?php echo e($data->LastName); ?>">
    </div>
</div>

<div class="form-group row">
    <label for="PresentAddress" class="col-sm-3 text-right control-label col-form-label">Present Address</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="PresentAddress" placeholder=" Present Address" name="PresentAddress" value="<?php echo e($data->PresentAddress); ?>">
 </div>
</div>

<div class="form-group row">
    <label for="ParmanentAddress" class="col-sm-3 text-right control-label col-form-label">Parmanent Address</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="ParmanentAddress" placeholder=" Parmanent Address" name="ParmanentAddress" readonly="" value="<?php echo e($data->ParmanentAddress); ?>">
 </div>
</div>

<div class="form-group row">
    <label for="FatherName" class="col-sm-3 text-right control-label col-form-label">Father's Name</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="FatherName" placeholder=" Father's Name" name="FatherName" readonly value="<?php echo e($data->FatherName); ?>">
    </div>
</div>

<div class="form-group row">
    <label for="MotherName" class="col-sm-3 text-right control-label col-form-label">Mother's Name</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="MotherName" placeholder=" Mother's Name" name="MotherName" readonly value="<?php echo e($data->MotherName); ?>">
 </div>
</div>


<div class="form-group row">
    <label for="Phone" class="col-sm-3 text-right control-label col-form-label">Phone</label>
    <div class="col-sm-9" >
        <input type="text" class="form-control" id="Phone" placeholder=" Phone" name="Phone" value="<?php echo e($data->Phone); ?>">
    </div>
</div>

<div class="form-group row">
    <label for="Email" class="col-sm-3 text-right control-label col-form-label">Email</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="Email" placeholder=" Email" name="Email" value="<?php echo e($data->Email); ?>">
  </div>
</div>


<div class="form-group row">
    <label for="Batch" class="col-sm-3 text-right control-label col-form-label">Batch</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Batch" placeholder=" Batch" name="Batch" readonly value="<?php echo e($data->Batch); ?>">
    </div>
</div>

<div class="form-group row">
    <label for="DOB" class="col-sm-3 text-right control-label col-form-label">Date of Birth</label>
    <div class="col-sm-9">
       <input type="text" class="form-control" id="DOB" placeholder=" Date of Birth" readonly name="DOB" value="<?php echo e($data->DOB); ?>">
   </div>
</div>

<div class="form-group row">
    <label for="BG" class="col-sm-3 text-right control-label col-form-label">Blood Group</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="BG" placeholder=" Blood Group" name="BG" value="<?php echo e($data->BG); ?>">
    </div>
</div>

<div class="form-group row">
    <label for="Religion" class="col-sm-3 text-right control-label col-form-label">Religion</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Religion" placeholder=" Religion" name="Religion" value="<?php echo e($data->Religion); ?>">
    </div>
</div>

<div class="form-group row">
    <label for="Nationality" class="col-sm-3 text-right control-label col-form-label">Nationality</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Nationality" placeholder=" Nationality" name="Nationality" readonly="" value="<?php echo e($data->Nationality); ?>">
    </div>
</div>

 <div class="form-group">
    <label for="image">Image</label>
    <input type="file" class="form-control" id="image" placeholder="Image" name="image" value="<?php echo e($data->image); ?>">
  </div>
  

<div class="form-group row">
    <label for="Password" class="col-sm-3 text-right control-label col-form-label">Password</label>
    <div class="col-sm-9">
        <input type="password" class="form-control" id="password" placeholder=" password" name="password" value="<?php echo e($data->password); ?>">
    </div>
</div>

<div class="border-top">
    <div class="card-body">
        <button type="submit" class="btn btn-primary">Update</button>
    </div>
</div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/student/profileUpdate.blade.php ENDPATH**/ ?>