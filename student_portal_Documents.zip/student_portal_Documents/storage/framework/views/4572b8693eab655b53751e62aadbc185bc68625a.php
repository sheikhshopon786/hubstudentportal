<?php $__env->startSection('content'); ?>



<a href="<?php echo e(url('/SacademicOffice')); ?>" style="text-decoration: none;" >
    <div class="row">
        <div class="col-lg-12 col-xl-3">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading">
                        </div>  
                    </div>

                    <div class="widget-content-left">
                        <div class="widget-numbers text-warning"><span>Academic Office</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</a>


 <a href="<?php echo e(url('/SaccountOffice')); ?>" style="text-decoration: none;" >
    <div class="row">
        <div class="col-lg-12 col-xl-3">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading">
                        </div>  
                    </div>

                    <div class="widget-content-left">
                        <div class="widget-numbers text-warning"><span>Account Office</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</a>


<a href="<?php echo e(url('/AexamOffice')); ?>" style="text-decoration: none;" >
    <div class="row">
        <div class="col-lg-12 col-xl-3">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading">
                        </div>  
                    </div>

                    <div class="widget-content-left">
                        <div class="widget-numbers text-warning"><span>Exam Controller</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</a>


<a href="<?php echo e(url('SstudentPart')); ?>" style="text-decoration: none;" >
    <div class="row">
        <div class="col-lg-12 col-xl-3">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading">
                        </div>  
                    </div>

                    <div class="widget-content-left">
                        <div class="widget-numbers text-warning"><span>Student Profile</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</a>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/admin/adminIndex.blade.php ENDPATH**/ ?>