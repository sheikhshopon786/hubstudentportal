<!--NavBar and Sidebar Start-->
<link rel="stylesheet" href="<?php echo e(URL:: asset('main.css')); ?>">
<!--NavBar and Sidebar End-->
 
 
  

<!--Footer Start-->
<link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
<!--Font Awesome-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  
<!--Footer End--> 
 
<?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/links/css.blade.php ENDPATH**/ ?>