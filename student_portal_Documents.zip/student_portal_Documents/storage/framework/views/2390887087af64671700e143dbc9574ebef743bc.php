 
<?php $__env->startSection('content'); ?>


<div class="col-lg-9">
         
              
                 
                 
  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">Please Confirm Teacher's Evolution</h5>
      <div class="table-responsive">
        <form action="<?php echo e(route('teachersEvolution')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 <?php echo e(csrf_field()); ?>


        	<table class="mb-0 table">
          <thead>
            <tr>               
            <th> <select name="CourseName" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Course
            </option>
            
			
            <option value="Algorithm">Algorithm </option>
            <option value="Data Structure"> Data Structure</option>
            <option value="Math">Math</option>
         
        </select>
  			  </th>

  			  <th> <select name="TeachersName" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
             Select Teacher
            </option>
            

            <option value="Azharul">Azharul </option>
            <option value="Islam">Islam</option>
            <option value="Shopon">Shopon</option>
         
        </select>
  			  </th>

            </tr>
 

          </thead>
          <tbody>
          
        <tr>
    
             <th>Question</th>
             <th colspan="3">Marks</th>
        
        </tr> 



	


    <tr>
      <td>well</td>
      <td>
       <form>
           <input type="radio" name="well" value="10"> 10 
           <input type="radio" name="well" value="5"> 5 
           <input type="radio" name="well" value="0"> 0 
       </form>
      </td>
    </tr>

    <tr>
      <td>well</td>
      <td>
       <form>
           <input type="radio" name="good" value="10"> 10 
           <input type="radio" name="good" value="5"> 5 
           <input type="radio" name="good" value="0"> 0 
       </form>
      </td>
    </tr>




  		

  		 
      
          </tbody>
        </table>
 		<textarea rows="4" cols="115" id="Comment" name="Comment">
 			
		</textarea>
        <br>
        <button type="submit" value="submit" name="submit" class="btn btn-primary">Submit</button>
    </form>

      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/academic/teachersEvolutionTable.blade.php ENDPATH**/ ?>