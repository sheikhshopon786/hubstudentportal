<?php $__env->startSection('content'); ?>


<!--Slider Start-->
   <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100" src="images/slider2.jpg" alt="First slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="images/slider2.jpg" alt="Second slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="images/slider2.jpg"alt="Third slide">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
<!--Slider End-->



<!--Marquee Start-->
      <marquee style="background: #16191f; color: white;">
          Notice:- This is notified for the information of all concerned that the Midterny Examination of Fall Semester 2019,will commence from 23 November 2019. All students of Undergraduate Programs are requested to clear their 2nd installment/Midterm installment (50% of remaining fees) of the said semester along with all dues (Hostel dues & others) if any, by 19 November 2019, Those who would pay the dues after 19 November 2019 can collect admit card by paying 100 Taka late fees for each day on special consideration. Students not paying the dues will not be allowed to sit for the said Examination.  
      </marquee>
<!--Marquee End-->






<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\final\student_portal\resources\views/partial/indexContent.blade.php ENDPATH**/ ?>