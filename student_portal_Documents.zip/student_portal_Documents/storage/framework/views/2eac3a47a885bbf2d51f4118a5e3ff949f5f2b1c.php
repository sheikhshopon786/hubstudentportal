<?php $__env->startSection('content'); ?>

 
        
         
<!-- 
<div class="card-body"><h5 class="card-title">Class Routine</h5>


  <div class="mb-12 text-center">
    <div role="group" class="btn-group-sm nav btn-group">
      <a data-toggle="tab" href="#Saturday" class="btn-shadow  btn btn-primary"><b>Saturday</b></a>
      <a data-toggle="tab" href="#Sunday" class="btn-shadow  btn btn-primary"><b>Sunday</b></a>
      <a data-toggle="tab" href="#Monday" class="btn-shadow  btn btn-primary"><b>Monday</b></a>
      <a data-toggle="tab" href="#Tuesday" class="btn-shadow  btn btn-primary"><b>Tuesday</b></a>
      <a data-toggle="tab" href="#Wednesday" class="btn-shadow  btn btn-primary"><b>Wednesday</b></a>
      <a data-toggle="tab" href="#Thursday" class="btn-shadow  btn btn-primary"><b>Thursday</b></a>
      <a data-toggle="tab" href="#Friday" class="btn-shadow  btn btn-primary"><b>Friday</b></a>
    </div>
  </div>
-->


  <div class="card-header"  style="width: 100%;"><i class="header-icon lnr-license icon-gradient bg-plum-plate"> Class Routine </i> 
    <div class="btn-actions-pane-right">
      <div class="nav"  style="width: 100%;">
        
      <a data-toggle="tab" href="#Saturday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Saturday</b></a>

      <a data-toggle="tab" href="#Sunday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Sunday</b></a>

      <a data-toggle="tab" href="#Monday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Monday</b></a>

      <a data-toggle="tab" href="#Tuesday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Tuesday</b></a>

      <a data-toggle="tab" href="#Wednesday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Wednesday</b></a>

      <a data-toggle="tab" href="#Thursday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Thursday</b></a>

      <a data-toggle="tab" href="#Friday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Friday</b></a>
      </div>
    </div>
  </div>






<div class="tab-content">
  <div class="tab-pane" id="Saturday" role="tabpanel">
      <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 20%; text-align: center;">Teacher's Name</th>
          <th style="width: 20%; text-align: center;">Time</th>
          <th style="width: 20%; text-align: center;">Room No</th>
        </tr>
        <?php $__currentLoopData = $one; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="width: 20%;"><?php echo e($one->oneBatch); ?></td>
            <td style="width: 20%;"><?php echo e($one->Saturday); ?></td>
            <td style="width: 20%; text-align: center;"><?php echo e($one->oneTeacher); ?></td>
            <td style="width: 20%; text-align: center;"><?php echo e($one->oneStartTime); ?>-<?php echo e($one->oneEndTime); ?></td>
            <td style="width: 20%; text-align: center;"><?php echo e($one->oneRoom); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
  </div>


  <div class="tab-pane" id="Sunday" role="tabpanel">
    <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
       <?php $__currentLoopData = $two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $two): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="width: 20%;"><?php echo e($two->twoBatch); ?></td>
            <td style="width: 25%;"><?php echo e($two->Sunday); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($two->twoTeacher); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($two->twoStartTime); ?>-<?php echo e($two->twoEndTime); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($two->twoRoom); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
  </div>

  <div class="tab-pane" id="Monday" role="tabpanel">
    <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
       <?php $__currentLoopData = $three; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $three): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="width: 20%;"><?php echo e($three->threeBatch); ?></td>
            <td style="width: 25%;"><?php echo e($three->Monday); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($three->threeTeacher); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($three->threeStartTime); ?>-<?php echo e($three->threeEndTime); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($three->threeRoom); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table> 
  </div>

  <div class="tab-pane" id="Tuesday" role="tabpanel">
    <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
     <?php $__currentLoopData = $four; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $four): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="width: 20%;"><?php echo e($four->fourBatch); ?></td>
            <td style="width: 25%;"><?php echo e($four->Tuesday); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($four->fourTeacher); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($four->fourStartTime); ?>-<?php echo e($four->fourEndTime); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($four->fourRoom); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
  </div>

  <div class="tab-pane" id="Wednesday" role="tabpanel">
      <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
    <?php $__currentLoopData = $five; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $five): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="width: 20%;"><?php echo e($five->fiveBatch); ?></td>
            <td style="width: 25%;"><?php echo e($five->Wednesday); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($five->fiveTeacher); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($five->fiveStartTime); ?>-<?php echo e($five->fiveEndTime); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($five->fiveRoom); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
  </div>

  <div class="tab-pane" id="Thursday" role="tabpanel">
    <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
    <?php $__currentLoopData = $six; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $six): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="width: 20%;"><?php echo e($six->sixBatch); ?></td>
            <td style="width: 25%;"><?php echo e($six->Thursday); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($six->sixTeacher); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($six->sixStartTime); ?>-<?php echo e($six->sixEndTime); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($six->sixRoom); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
  </div>

  <div class="tab-pane" id="Friday" role="tabpanel">
     <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
   <?php $__currentLoopData = $seven; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seven): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="width: 20%;"><?php echo e($seven->sevenBatch); ?></td>
            <td style="width: 25%;"><?php echo e($seven->Friday); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($seven->sevenTeacher); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($seven->sevenStartTime); ?>-<?php echo e($seven->sevenEndTime); ?></td>
            <td style="width: 25%; text-align: center;"><?php echo e($seven->sevenRoom); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
  </div>





<div style="float: right;">
  <caption style="text-align: center;"><b>Teacher's Name List</b></caption>
<table border="1px">
  <tr>
    <th>Short Name</th>
    <th>Full Name</th>
  </tr>
<?php $__currentLoopData = $teachersname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teachersname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($teachersname->ShortName); ?></td>
    <td><?php echo e($teachersname->FullName); ?></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>




</div>
 









<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/student/classRoutine.blade.php ENDPATH**/ ?>