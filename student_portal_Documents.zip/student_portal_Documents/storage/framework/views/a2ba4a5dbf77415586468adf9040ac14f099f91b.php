<?php $__env->startSection('content'); ?>
 

	
	<div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Your Registered Course List</h3>   

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table border="1px" class="table table-hover">
          
    <tbody>

     <?php $__currentLoopData = $courseListAfterReg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseListAfterReg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="width: 100%; text-align: center;"> 

          
           <h3>
           <?php echo e($courseListAfterReg->courseCodeTitile); ?> 
          </h3>
           
                 
      </div>                 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
   </table>
 </div> <!-- /.card-body -->
</div><!-- /.card -->
</div>
<!-- /.row -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/student/courseListAfterReg.blade.php ENDPATH**/ ?>