<?php $__env->startSection('content'); ?>






<div class="card-body"><h5 class="card-title">Academic Results:</h5>
	<table class="mb-0 table table-dark">
		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th>Course Code</th>
				<th>Course Title</th>
				<th>Credit</th>
				<th>Grade</th>
				<th>Grade Point</th>
			</tr>
		</thead>
<?php $__currentLoopData = $studentResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				
				<td><?php echo e($studentResult->CourseCode); ?></td>
				<td><?php echo e($studentResult->CourseTitle); ?></td>
				<td><?php echo e($studentResult->Credit); ?></td>
				<td><?php echo e($studentResult->Grade); ?></td>
				<td><?php echo e($studentResult->GradePoint); ?></td>
			</tr>
		</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/exam/studentResult.blade.php ENDPATH**/ ?>