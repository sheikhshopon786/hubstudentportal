 
<?php $__env->startSection('content'); ?>

	 
	<div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Reset Code</h5><br>
            <form action="<?php echo e(url('/rc')); ?>" method="post" 
      			enctype="multipart/form-data" role="form">
       				<?php echo e(csrf_field()); ?>

              <div class="form-label-group">
                <input type="text" id="rc" name="rc" class="form-control" placeholder="Enter your code" required autofocus><br>
              </div>      

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Submit</button>  
            </form>

            
               <a href="" style="text-decoration:none;"><label for="EmailCode">Send Code Again?</label></a>
                
          </div>
        </div>
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

 


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/partial/resetCode.blade.php ENDPATH**/ ?>