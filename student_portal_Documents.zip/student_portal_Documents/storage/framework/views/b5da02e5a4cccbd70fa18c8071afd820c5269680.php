<?php $__env->startSection('content'); ?>


<!--Slider Start-->
   


<div class="col-md-12">
<div class="main-card mb-3 card">
<div class="card-body">
<div id="carouselExampleControls2" class="carousel slide carousel-fade" data-ride="carousel">
<div class="carousel-inner">
<div class="carousel-item active">
<img class="d-block w-100" src="images/slider1.jpg" alt="First slide">
<div class="carousel-caption d-none d-md-block" style="color:#000;"><!--
<h2><b>Present View</b></h2>
<h4><b>Hamdard University Bangladesh Present View</b></h4>-->
</div>
</div>
<div class="carousel-item">
<img class="d-block w-100" src="images/slider5.jpg" alt="Second slide">
<div class="carousel-caption d-none d-md-block" style="color: #000;"><!--
<h2><b>Future Plan</b></h2>
<h4><b>Hamdard University Bangladesh Future Plan</b></h4>-->
</div>
</div>
<!--
<div class="carousel-item">
<img class="d-block w-100" src="images/slider6.jpg" alt="Third slide">
<div class="carousel-caption d-none d-md-block" style="color: #000;">

<h2><b>Fresher’s Reception Fall 2019</b></h2>

<h4><b>On 16 November 2019 Hamdard University Bangladesh organized Freshers’ Reception.</b></h4>

</div>
</div>-->

</div>
<a class="carousel-control-prev" href="#carouselExampleControls2" role="button" data-slide="prev">
<span class="carousel-control-prev-icon" aria-hidden="true"></span>
<span class="sr-only">Previous</span>
</a>
<a class="carousel-control-next" href="#carouselExampleControls2" role="button" data-slide="next">
<span class="carousel-control-next-icon" aria-hidden="true"></span>
<span class="sr-only">Next</span>
</a>
</div>
</div>
</div>
</div>

<!--Slider End-->

<!--Marquee Start-->
 
	
  
<div class="col-md-12">

      <marquee style="background: #16191f; color: white;">
           <?php $__currentLoopData = $Notice1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Notice1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <b>Latest Notice-</b> <?php echo e($Notice1->Title); ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </marquee>
      
</div>
<!--Marquee End-->






<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/partial/indexContent.blade.php ENDPATH**/ ?>