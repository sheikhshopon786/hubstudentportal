<?php $__env->startSection('content'); ?>



<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h6><b>Admit Card Serial No</b></h6></caption>
	<table class="mb-0 table table-dark">

		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th style="text-align: center;">Student ID</th>
				<th style="text-align: center;">Admit Card Serial</th>
			</tr>
		</thead>
<?php $__currentLoopData = $admitSerialForExam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admitSerialForExam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				<td style="text-align: center;"><?php echo e($admitSerialForExam->student_id); ?>

				</td>
				<td style="text-align: center;"><?php echo e($admitSerialForExam->Serial); ?>

				</td>
			</tr>
		</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>
					







<?php $__env->stopSection(); ?>
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/exam/admitSerial.blade.php ENDPATH**/ ?>