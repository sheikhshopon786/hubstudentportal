<?php $__env->startSection('content'); ?>
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Course Offer & Class Schedule</b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
              <form action=" " method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>

                <div class="card-body">

                  <div class="form-group"> 
              <label for="Date">Date</label>
              <input type="text" class="form-control" id="Date" placeholder="Date" name="Date"  required="">   
                  </div>

                  <div class="form-group">
              <label for="Month">Month</label>
              <input type="month" class="form-control" id="Month" placeholder="Month" name="Month" required="">
                  </div>

                  <div class="form-group">
                    <label for="Title">Title</label>           
              <input type="text" class="form-control" id="Title" placeholder=" Title" name="Title" required="">
                  </div>

                  <div class="form-group">
                    <label for="Day">Day</label>
              <input type="weekday" class="form-control" id="Day" placeholder="Day" name="Day" required="">
              </div>



                  <div class="form-group">
                    <label for="SartingTime">SartingTime</label>
              <input type="time" class="form-control" id="SartingTime" placeholder="SartingTime" name="SartingTime" required="">
                  </div>


                  <div class="form-group"> 
              <label for="EndingTime">Ending Time</label>
              <input type="time" class="form-control" id="EndingTime" placeholder="EndingTime" name="EndingTime" required="">   
                  </div>

          
                  <div class="form-group">
              <label for="Location">Location</label>
              <input type="text" class="form-control" id="Location" placeholder="Location" name="Location" required="">
                  </div>

                  <div class="form-group">
                    <label for="Category">Category</label>
              <input type="text" class="form-control" id="Category" placeholder=" Category" name="Category" required="">
                  </div>

               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/partial/NoticeFormPage.blade.php ENDPATH**/ ?>