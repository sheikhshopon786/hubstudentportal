<?php $__env->startSection('content'); ?>
 
 
          <div class="col-12">
            <div class="card">
               
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 800px;">
            
         
  
      <?php $__currentLoopData = $studentProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentProfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="row" style="width: 100%; text-align: center;">
          <div class="col-md-12">
          
          <button class="btn btn-alternate" style="width: 100%;"><h4><b>Profile of <?php echo e($studentProfile->FirstName); ?>  <?php echo e($studentProfile->LastName); ?></b></h4>
          </button>
        </div>
        </div><br>


        <div class="row" style="width: 100%; text-align: center;"> 

        <div class="col-md-3">
         <img src="<?php echo e(url('/')); ?>/image/<?php echo e($studentProfile->image); ?>" style="width: 220px; height:260px; border-radius:10px;">  

         <a href="<?php echo e(url('/proUpdateReq')); ?>" class="mm-active">
         <button class="mb-2 mr-2 btn btn-alternate btn-sm btn-block"><i class="metismenu-icon pe-7s-note"></i><b>EDIT PROFILE</b>
         </button></a>
       </div>


       <div class="col-md-9">
          



          <table class="table table-hover">
          <tbody>
           
            <tr>
              <td style="text-align: left;"><b>ID:</b></td>
              <td style="text-align: left;"><?php echo e($studentProfile->student_id); ?></td>
            </tr>
            <tr>
               <td style="text-align: left;"><b>First Name:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->FirstName); ?></td>
            </tr>
            <tr>
                 <td style="text-align: left;"><b>Last Name:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->LastName); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Batch:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->Batch); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Gender:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->Gender); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Religion:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->Religion); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Blood Group:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->BG); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Phone Number:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->Phone); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Date of Birth:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->DOB); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Email Address:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->Email); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Department:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->Department); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Faculty:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->Faculty); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Father's Name:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->FatherName); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Mother's Name:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->MotherName); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Present Address:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->PresentAddress); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Permanent Address:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->ParmanentAddress); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Nationality:</b></td>
                <td style="text-align: left;"><?php echo e($studentProfile->Nationality); ?></td>
              </tr>                 
       
          </tbody>
        </table>







        </div>   


        
      </div>                 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
   
 </div> <!-- /.card-body -->
</div><!-- /.card -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/student/studentProfile.blade.php ENDPATH**/ ?>