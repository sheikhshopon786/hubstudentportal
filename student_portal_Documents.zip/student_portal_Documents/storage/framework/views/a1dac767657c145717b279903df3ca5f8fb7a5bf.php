<?php $__env->startSection('content'); ?>






<div class="card-body"><h5 class="card-title">Student Results:</h5>




  <form action="<?php echo e(route('StdRSearch')); ?>" method="post" 
    enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

<!--
    <label for="" class="sr-only">Select Program</label>
    <input type="text" class="form-control" id="Program" placeholder="Select Program" name="Program">
    <br>
    <label for="" class="sr-only">Waiver</label>
    <input type="text" class="form-control" id="Waiver" placeholder="Waiver" name="Waiver">
  -->


     <div class="form-group">
            <label for="student_id">Student ID</label>
            <input type="text" class="form-control" id="student_id" placeholder="Please Insert Student ID" name="student_id" required="">
        </div>


    <button type="submit" class="btn btn-primary">Submit</button>             
  </form>








 



<b>Semester Wise GPA Status: <?php $__currentLoopData = $studentResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </b>
<table class="mb-0 table table-dark">
    <tr>
      <th style="text-align: center;">
        Semester: 01
      </th>
       <th style="text-align: center;">
        Semester: 02
      </th>     
       <th style="text-align: center;">
        Semester: 03
      </th>  
       <th style="text-align: center;">
        Semester: 04
      </th>  
       <th style="text-align: center;">
        Semester: 05
      </th>  
       <th style="text-align: center;">
        Semester: 06
      </th>  
       <th style="text-align: center;">
        Semester: 07
      </th>  
       <th style="text-align: center;">
        Semester: 08
      </th>  
    </tr>
   

    <tr>   
      <?php $__currentLoopData = $semesterNo1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo1->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php $__currentLoopData = $semesterNo2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo2->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

       <?php $__currentLoopData = $semesterNo3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo3->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo4->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo5->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo6->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo7->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo8->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

    </tr>


</table>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('account.accountOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/account/studentResult.blade.php ENDPATH**/ ?>