<?php $__env->startSection('content'); ?>

 
<div class="col-md-6 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Bar graph</h2>
                  
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <canvas id="mybarChart"></canvas>
                  </div>
                </div>
              </div>
            </div>

      <!--Chart Start-->

 <!-- jQuery -->
<script type="text/javascript" src="<?php echo e(URL::asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script type="text/javascript" src="<?php echo e(URL::asset('vendors/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- FastClick -->
<script type="text/javascript" src="<?php echo e(URL::asset('vendors/fastclick/lib/fastclick.js')); ?>"></script>
<!-- NProgress -->
<script type="text/javascript" src="<?php echo e(URL::asset('vendors/nprogress/nprogress.js')); ?>"></script>
<!-- Chart.js -->
<script type="text/javascript" src="<?php echo e(URL::asset('vendors/Chart.js/dist/Chart.min.js')); ?>"></script>
<!-- Custom Theme Scripts -->
<script type="text/javascript" src="<?php echo e(URL::asset('build/js/custom.min.js')); ?>"></script>
<!--Chart End-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\12.12.2019\student_portal\resources\views/account/paymentScheme.blade.php ENDPATH**/ ?>