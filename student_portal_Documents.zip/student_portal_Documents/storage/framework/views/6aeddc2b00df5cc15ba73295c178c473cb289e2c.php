<!--NavBar and Sidebar Start-->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/scripts/main.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js.js')); ?>"></script>

<!--NavBar and Sidebar End-->
 

  

 <?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/links/script.blade.php ENDPATH**/ ?>