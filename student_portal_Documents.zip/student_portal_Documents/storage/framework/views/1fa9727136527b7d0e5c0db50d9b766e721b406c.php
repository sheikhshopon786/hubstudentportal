<?php $__env->startSection('content'); ?>
 
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Class Routine</h3>  

                 
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table class="table table-hover">
         <thead>
            <tr>
              <th scope="col">Semester</th>
              <th scope="col">course Code and Titile</th>
                           
              <th scope="col">Department</th>
              <th scope="col">Teacher's Name</th>
              <th scope="col">Day</th>
              <th scope="col">Time</th>
              <th scope="col">Room No</th>
              <th scope="col">Update Routine</th>
              <th scope="col">Delete</th>     
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $studentInformationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentInformationList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($studentInformationList->semester); ?></td>
              <td><?php echo e($studentInformationList->courseCodeTitile); ?></td>
              
              <td><?php echo e($studentInformationList->department); ?></td>
              <td><?php echo e($studentInformationList->teacher_name); ?></td>
              <td><?php echo e($studentInformationList->day); ?></td>
              <td><?php echo e($studentInformationList->starting_time); ?> - <?php echo e($studentInformationList->ending_time); ?></td>
              <td><?php echo e($studentInformationList->room_no); ?></td>

              <td> 
                <a href="<?php echo e(url('/routineeditreq',$studentInformationList->ID)); ?>" class="btn btn-primary">Edit</a>
              </td> 
              <td>
               <a href="<?php echo e(url('/routinedelreq',$studentInformationList->ID)); ?>" class="btn btn-danger">Delete</a>
              </td>
            </tr> 

            
                            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
     
        <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/academic/classRoutineList.blade.php ENDPATH**/ ?>