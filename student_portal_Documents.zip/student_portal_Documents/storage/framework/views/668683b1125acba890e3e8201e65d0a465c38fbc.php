<script type="text/javascript" src="<?php echo e(URL::asset('assets/scripts/main.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(URL::asset('assets/js.js')); ?>"></script>


<!--Sidebar, navBar, Content Field Start-->
 

 <!--Sidebar, navBar, Content Field End-->


 <!-- fullCalendar 2.2.5 -->
    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/moment/moment.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar-daygrid/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar-timegrid/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar-interaction/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar-bootstrap/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- End fullCalendar 2.2.5 -->




<?php /**PATH C:\Users\User\Desktop\15.12.19\student_portal\resources\views/links/script.blade.php ENDPATH**/ ?>