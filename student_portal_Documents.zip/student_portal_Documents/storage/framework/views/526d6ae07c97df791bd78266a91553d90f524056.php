<?php $__env->startSection('content'); ?>
<!--Student Information form start -->

<!--Student Information form End --> 
<body>
<form action="<?php echo e(route('resultVerifyForm')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 <?php echo e(csrf_field()); ?>


 <div class="card-body">
    <h4 class="card-title">Result Verification Form</h4>
    <div class="form-group row">
        <label for="student_id" class="col-sm-3 text-right control-label col-form-label">Student ID</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="student_id" placeholder=" Student ID" name="student_id" required="">
        </div>
    </div>
    <div class="form-group row">
        <label for="Name" class="col-sm-3 text-right control-label col-form-label">Full Name</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="Name" placeholder="Full Name" name="Name" required="">
        </div>
    </div>

    <div class="form-group row">
        <label for="DepartmentName" class="col-sm-3 text-right control-label col-form-label">Department Name</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="DepartmentName" placeholder="Department Name" name="DepartmentName" required="">
        </div>
    </div>

    <div class="form-group row">
        <label for="CGPA" class="col-sm-3 text-right control-label col-form-label">CGPA</label>
        <div class="col-sm-9">
         <input type="text" class="form-control" id="CGPA" placeholder=" CGPA" name="CGPA" required="">
     </div>
 </div>

 <div class="form-group row">
    <label for="PassingYear" class="col-sm-3 text-right control-label col-form-label">Passing Year</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="PassingYear" placeholder=" Passing Year" name="PassingYear" required="">
 </div>
</div>

 

<div class="border-top">
    <div class="card-body" class="alert alert-success">
        <button type="submit" class="btn btn-primary">Submit</button>
        
         
    </div>

</div>
</form>
</body>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/exam/resultVerifyFormPage.blade.php ENDPATH**/ ?>