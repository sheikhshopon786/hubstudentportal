 
 <?php $__env->startSection('content'); ?>
 



 








<div class="col-md-4" style="text-align: center; 
    background:#302f2f; color:white ; opacity: .8;">
     <div class="widget">

      <table class="table table-striped">
                  <thead>
                    <tr>
                      <th scope="col" style="color: #fff">Result(SSC+HSC Without 4th Subject)</th>
                      <th scope="col" style="color: #fff">Waiver</th>
                                             
                    </tr>
                  </thead>
                  <tbody>

                    <tr>
                      <td scope="row" style="color: #fff">10.00</td>
                      <td style="color: #fff">100%</td>
                       
                      
                    </tr>

                   <tr>
                      <td scope="row" style="color: #fff">9.00-9.99</td>
                      <td style="color: #fff">40%</td>
                       
                      
                    </tr>

                    <tr>
                      <td scope="row" style="color: #fff">8.00-8.99</td>
                      <td style="color: #fff">20%</td>
  
                    </tr>

                    <tr>
                      <td scope="row" style="color: #fff">7.00-7.99</td>
                      <td style="color: #fff">10%</td>
                               
                    </tr>
                  </tbody>
                </table>


    </div>
</div>



 
</div>
</div>








 
</body>
</html>






 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/account/waiverList.blade.php ENDPATH**/ ?>