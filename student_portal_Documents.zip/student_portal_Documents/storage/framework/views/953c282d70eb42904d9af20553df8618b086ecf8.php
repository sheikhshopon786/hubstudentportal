<?php $__env->startSection('content'); ?>


<!--Slider Start-->
   


<div class="col-md-12">
<div class="main-card mb-3 card">
<div class="card-body">
<div id="carouselExampleControls2" class="carousel slide carousel-fade" data-ride="carousel">
<div class="carousel-inner">
<div class="carousel-item active">
<img class="d-block w-100" src="images/slider2.jpg" alt="First slide">
<div class="carousel-caption d-none d-md-block" style="color:#000;"><!--
<h2><b>Present View</b></h2>
<h4><b>Hamdard University Bangladesh Present View</b></h4>-->
</div>
</div>
<div class="carousel-item">
<img class="d-block w-100" src="images/slider1.jpg" alt="Second slide">
<div class="carousel-caption d-none d-md-block" style="color: #000;"><!--
<h2><b>Future Plan</b></h2>
<h4><b>Hamdard University Bangladesh Future Plan</b></h4>-->
</div>
</div>
<div class="carousel-item">
<img class="d-block w-100" src="images/slider5.png" alt="Third slide">
<div class="carousel-caption d-none d-md-block" style="color: #000;">
<!--
<h2><b>Fresher’s Reception Fall 2019</b></h2>

<h4><b>On 16 November 2019 Hamdard University Bangladesh organized Freshers’ Reception.</b></h4>
-->
</div>
</div>
</div>
<a class="carousel-control-prev" href="#carouselExampleControls2" role="button" data-slide="prev">
<span class="carousel-control-prev-icon" aria-hidden="true"></span>
<span class="sr-only">Previous</span>
</a>
<a class="carousel-control-next" href="#carouselExampleControls2" role="button" data-slide="next">
<span class="carousel-control-next-icon" aria-hidden="true"></span>
<span class="sr-only">Next</span>
</a>
</div>
</div>
</div>
</div>

<!--Slider End-->

<!--Marquee Start-->
 
	
  
<div class="col-md-12">

      <marquee style="background: #16191f; color: white;">
          Notice:- This is notified for the information of all concerned that the Midterny Examination of Fall Semester 2019,will commence from 23 November 2019. All students of Undergraduate Programs are requested to clear their 2nd installment/Midterm installment (50% of remaining fees) of the said semester along with all dues (Hostel dues & others) if any, by 19 November 2019, Those who would pay the dues after 19 November 2019 can collect admit card by paying 100 Taka late fees for each day on special consideration. Students not paying the dues will not be allowed to sit for the said Examination.  
      </marquee>
      
      </div>
<!--Marquee End-->






<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020\student_portal\resources\views/partial/indexContent.blade.php ENDPATH**/ ?>