<!DOCTYPE html>
<html>
<head>
  <title>Student Part</title>
    <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php echo $__env->make('links.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
  



    <?php echo $__env->make('partial.navBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 

   
	  
    
   
 
 




 
 


  <?php echo $__env->make('links.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\User\Desktop\14.01.2020\student_portal\resources\views/student/studentPart.blade.php ENDPATH**/ ?>