<?php $__env->startSection('content'); ?>






<div class="card-body"><h5 class="card-title">Complete Course:</h5>
	<table class="mb-0 table table-dark">
		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th>Course Code and Title</th>
				<th>Credit Hour</th>
			</tr>
		</thead>
<?php $__currentLoopData = $courseListAfterReg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseListAfterReg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				
				<td><?php echo e($courseListAfterReg->courseCodeTitile); ?> </td>
			</tr>
		</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/student/completeCoursePage.blade.php ENDPATH**/ ?>