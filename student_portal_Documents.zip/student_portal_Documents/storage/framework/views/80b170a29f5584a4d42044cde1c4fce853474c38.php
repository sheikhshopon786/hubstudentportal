<?php $__env->startSection('content'); ?>


Notification

<form action="<?php echo e(route('pictureStoreForm')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 <?php echo e(csrf_field()); ?>


<a href="<?php echo e(url('#')); ?>" style="text-decoration: none;">
	<div role="group" class="btn-group-lg btn-group btn-group-toggle" >
		<button type="button" class="btn btn-alternate">Academic Office
		</button>	
	</div>
</a>
<br><br>


<div class="form-group row">
        <label for="image" class="col-sm-1 text-right control-label col-form-label"><b>Insert File</b></label>
        <div class="col-sm-9">
            <input type="file" class="form-control" id="image" placeholder="Academic Office" name="image" >
        </div>
</div>
<br><br>
 

 

<button type="submit" class="btn btn-primary">Submit</button>
</form>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/partial/pictureStoreForm.blade.php ENDPATH**/ ?>