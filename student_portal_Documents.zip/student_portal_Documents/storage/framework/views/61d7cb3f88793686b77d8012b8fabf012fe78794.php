<?php $__env->startSection('content'); ?>
<!--Student Information form start -->

<!--Student Information form End -->  
<body>
<form action="<?php echo e(route('studentInformationInsert')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 <?php echo e(csrf_field()); ?>

<b><?php echo e(session('msg')); ?></b>
  

 <div class="card-body">
    <h4 class="card-title">Student Information Form</h4>
    <div class="form-group row">
        <label for="student_id" class="col-sm-3 text-right control-label col-form-label">Student ID</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="student_id" placeholder=" Student ID" name="student_id" required="">
        </div>
    </div>
    <div class="form-group row">
        <label for="FirstName" class="col-sm-3 text-right control-label col-form-label">First Name</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="FirstName" placeholder="First Name" name="FirstName" required="">
        </div>
    </div>

    <div class="form-group row">
        <label for="LastName" class="col-sm-3 text-right control-label col-form-label">Last Name</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="LastName" placeholder="Last Name" name="LastName" required="">
        </div>
    </div>

     <div class="form-group row">
        <label for="LastName" class="col-sm-3 text-right control-label col-form-label">Gender</label>
        <div class="col-sm-9">
           <label class="form-check-label" for="Gender">
        <input type="radio" class="form-check-input" id="Gender" name="Gender" value="Male">Male
      </label><br>
      <label class="form-check-label" for="Gender">
        <input type="radio" class="form-check-input" id="Gender" name="Gender" value="Female">Female
      </label>
        </div>
    </div>

    <div class="form-group row">
        <label for="PresentAddress" class="col-sm-3 text-right control-label col-form-label">Present Address</label>
        <div class="col-sm-9">
         <input type="text" class="form-control" id="PresentAddress" placeholder=" Present Address" name="PresentAddress" required="">
     </div>
 </div>

 <div class="form-group row">
    <label for="ParmanentAddress" class="col-sm-3 text-right control-label col-form-label">Parmanent Address</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="ParmanentAddress" placeholder=" Parmanent Address" name="ParmanentAddress" required="">
 </div>
</div>

<div class="form-group row">
    <label for="FatherName" class="col-sm-3 text-right control-label col-form-label">Father's Name</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="FatherName" placeholder=" Father's Name" name="FatherName" required="">
    </div>
</div>

<div class="form-group row">
    <label for="MotherName" class="col-sm-3 text-right control-label col-form-label">Mother's Name</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="MotherName" placeholder=" Mother's Name" name="MotherName" required="">
 </div>
</div>


<div class="form-group row">
    <label for="Phone" class="col-sm-3 text-right control-label col-form-label">Phone</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Phone" placeholder=" Phone" name="Phone" required="">
    </div>
</div>

<div class="form-group row">
    <label for="Email" class="col-sm-3 text-right control-label col-form-label">Email</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="Email" placeholder=" Email" name="Email" required="">
  </div>
</div>


<select value="Department" name="Department" id="Department"      style="width: 100%; float: right; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Program
              </option>
              <option value="B.Sc in Computer Science & Engineering">
                B.Sc in Computer Science & Engineering
              </option>
              <option value=" B.Sc in Electrical & Electronics Engineering">
                B.Sc in Electrical & Electronics Engineering
              </option>

           </select>



            <select value="Faculty" name="Faculty" id="Faculty"      style="width: 100%; float: right; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Faculty
              </option>
              <option value="Faculty of Science & Engineering Technology">
                Faculty of Science & Engineering Technology
              </option>
           </select>


<div class="form-group row">
    <label for="Batch" class="col-sm-3 text-right control-label col-form-label">Batch</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Batch" placeholder=" Batch" name="Batch" required="">
    </div>
</div>

<div class="form-group row">
    <label for="DOB" class="col-sm-3 text-right control-label col-form-label">Date of Birth</label>
    <div class="col-sm-9">
       <input type="text" class="form-control" id="DOB" placeholder=" Date of Birth" name="DOB" required="">
   </div>
</div>

<div class="form-group row">
    <label for="BG" class="col-sm-3 text-right control-label col-form-label">Blood Group</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="BG" placeholder=" Blood Group" name="BG" required="">
    </div>
</div>

<div class="form-group row">
    <label for="Religion" class="col-sm-3 text-right control-label col-form-label">Religion</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Religion" placeholder=" Religion" name="Religion" required="">
    </div>
</div>

<div class="form-group row">
    <label for="Nationality" class="col-sm-3 text-right control-label col-form-label">Nationality</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Nationality" placeholder=" Nationality" name="Nationality" required="">
    </div>
</div>


<div class="form-group row">
    <label for="image" class="col-sm-3 text-right control-label col-form-label">Picture</label>
    <div class="col-sm-9">
        <input type="file" class="form-control" id="image" placeholder="Academic Office" name="image" >
    </div>
</div>



<div class="form-group row">
    <label for="Password" class="col-sm-3 text-right control-label col-form-label">Password</label>
    <div class="col-sm-9">
        <input type="password" class="form-control" id="password" placeholder=" password" name="password" required="">
    </div>
</div>

<div class="border-top">
    <div class="card-body" class="alert alert-success">
        <button type="submit" id="btn" name="btn" value="btn" class="btn btn-primary">Submit</button>
        
         
    </div>

</div>
    
</form>
</body>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/academic/studentInformation.blade.php ENDPATH**/ ?>