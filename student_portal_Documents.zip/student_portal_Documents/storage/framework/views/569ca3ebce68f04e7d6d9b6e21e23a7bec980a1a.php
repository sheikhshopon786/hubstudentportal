<?php $__env->startSection('content'); ?>
 
<!-- form start-2 -->
<div class="col-md-12">
  <!-- general form elements -->
  <div class="card card-primary">
    <div class="card-header"  >
      <h5 style="text-align: center;"><b>Document Apply </b></h5>
    </div>





    <!-- /.card-header -->
    <!-- form start-1 -->
    <div class="main-card mb-3 card">
      <div class="card-body"><h5 class="card-title"> </h5>
        <div class="form-row">
        <div class="col-md-6">
          <?php $__currentLoopData = $stdInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stdInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h6><b>ID:</b> <?php echo e($stdInfo->student_id); ?><br> 
          <b>Name:</b> <?php echo e($stdInfo->FirstName); ?> <?php echo e($stdInfo->LastName); ?> <br>
          <b>Faculty:</b> <?php echo e($stdInfo->Faculty); ?><br> 
          <b>Program:</b> <?php echo e($stdInfo->Department); ?> </h6>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!--  <div class="col-md-3">
              <p>
                <ul type="circle">
                  <a href="#" style="color: #000;"><b><li> Document Apply</li></b></a>
                  <a href="#" style="color: #000;"><b><li>Applied Document</li></b></a>
                </ul>
              </p>
            </div>
              <div class="col-md-3">
              <p>
                <ul type="square">
                  <a href="#" style="color: #000;"><b><li>Convocation Notice</li></b></a>
                  <a href="#" style="color: #000;"><b><li>Convocation Apply Instruction</li></b></a>
                  <a href="#" style="color: #000;"><b><li>Apply Instruction for bKash</li></b></a>
                  <a href="#" style="color: #000;"><b><li>Alumni Card & Facilities</li></b></a>
                </ul>
              </p>
          </div>
        </div>
        <br><br>-->
    

        <form action="<?php echo e(url('certificate')); ?>" method="post" 
            enctype="multipart/form-data" role="form">
              <?php echo e(csrf_field()); ?>

          <div class="form-row">

            <div class="col-md-6">
              <div class="position-relative form-group"><label for="ApplyDate" class="">Apply Date*</label><input name="ApplyDate" id="ApplyDate" placeholder="Apply Date" type="date" class="form-control" required=""></div>
            </div>

            <div class="col-md-6">
              <div class="position-relative form-group"><label for="DaliveryDate" class="">Dalivery Date* </label><input name="DaliveryDate" id="DaliveryDate" placeholder="DaliveryDate" type="date" class="form-control" required=""></div>
            </div>

            <div class="col-md-6">
              <div class="position-relative form-group"><label for="AlternateEmail" class="">Alternate Email</label><input name="AlternateEmail" id="AlternateEmail" placeholder="Alternate Email" type="text"
               class="form-control"></div>
             </div>

             <div class="col-md-6">
              <div class="position-relative form-group"><label for="MobileNumber" class="">Mobile Number*</label><input name="MobileNumber" id="MobileNumber" placeholder="Mobile Number" type="text"
               class="form-control" required=""></div>
             </div>

             <div class="col-md-6">
              <div class="position-relative form-group"><label for="PaidAmount" class="">Paid Amount*</label><input name="PaidAmount" id="PaidAmount" placeholder="Paid Amount" type="text" class="form-control" required=""></div>
            </div>


              <div class="col-md-6">
              <div class="position-relative form-group"><label for="PaidDate" class="">Paid Date*</label><input name="PaidDate" id="PaidDate" placeholder="Paid Date" type="date" class="form-control" required=""></div>
            </div>

            <div class="col-md-6">
              <select value="PaymentMedia" name="PaymentMedia" id="PaymentMedia"       class="mb-2 form-control-lg form-control" required="">
              <option selected="" disabled="">
                Select Payment Media*
              </option>
              <option value="CASH">
                CASH
              </option>
              <option value="SIBL">
                SIBL
              </option>
           </select>
             </div>



              <div class="col-md-6">
              <div class="position-relative form-group"> <input name="MoneyReceipt" id="MoneyReceipt" placeholder="Money Receipt/Transction ID/Reference No*" type="text" class="form-control" required=""></div>
            </div>

               

             <div class="col-md-6">
              <select value="Document" name="Document" id="Document"       class="mb-2 form-control-lg form-control" required="">
              <option selected="" disabled="">
                Select Document*
              </option>
              <option value="Certificate">
                Certificate
              </option>
              <option value="Transcript">
                Transcript
              </option>
           </select>
             </div>

             <div class="col-md-6">
              <select value="DocumentType" name="DocumentType" id="DocumentType"       class="mb-2 form-control-lg form-control" required="">
              <option selected="" disabled="">
                Select Document Type*
              </option>
              <option value="Original">
                Original
              </option>
              <option value="Duplicate">
                Duplicate
              </option>
           </select>
             </div>

              <div class="col-md-6">
              <div class="position-relative form-group"><input name="NumberOfCopy" id="NumberOfCopy" placeholder="Number Of Copy*" type="number"
               class="form-control" required=""></div>
             </div>


             <div class="col-md-6">
              <select value="UrgencyType" name="UrgencyType" id="UrgencyType"       class="mb-2 form-control-lg form-control" required="">
              <option selected="" disabled="">
                Select Urgency Type*
              </option>
              <option value="Urgent">
                Urgent
              </option>
              <option value="Regular">
                Regular
              </option>
           </select>
             </div>

        </div>
          <button class="mt-2 btn btn-primary">Submit</button>
        </form>
      </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/exam/certificate.blade.php ENDPATH**/ ?>