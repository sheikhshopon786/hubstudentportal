<?php $__env->startSection('content'); ?>




<div class="card-body"><h5 class="card-title">Student Results:</h5>




 <form action="<?php echo e(route('SSRsearch')); ?>" method="post" 
      enctype="multipart/form-data">
       <?php echo e(csrf_field()); ?>

              <label for="" class="sr-only">ID</label>
               <input type="text" class="form-control" id="SSRsearch" placeholder="Enter Student ID" name="SSRsearch">

              <button type="submit" class="btn btn-primary">Submit</button>             
        </form>








<table class="mb-0 table table-dark">
   
  <thead>
    <tr>
        <th scope="col">Student ID</th>
      <th scope="col">Course Code And Ttile</th>
      <th scope="col"style="text-align: center;">Credit</th>
      <th scope="col"style="text-align: center;">Grade</th>
      <th scope="col"style="text-align: center;">GradePoint</th>
    
    </tr>
  </thead>
  <tbody>
   <?php $__currentLoopData = $studentResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($studentResult->student_id); ?></td>
      <td><?php echo e($studentResult->CourseCodeTitle); ?></td>
      <td style="text-align: center;"><?php echo e($studentResult->Credit); ?></td>
      <td style="text-align: center;"><?php echo e($studentResult->Grade); ?></td>
      <td style="text-align: center;"><?php echo e($studentResult->GradePoint); ?></td>
      
      
     
    </tr>
           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    
  </tbody>
</table>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.exm.AexamOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/admin/exm/SstudentResult.blade.php ENDPATH**/ ?>