<?php $__env->startSection('content'); ?>
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Semester Drop </b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
 <form  method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>

      <div class="card-body">

          <select value="semester" name="semester" id="semester"      style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Semester
              </option>
              <option value="Spring, 2019">
                Spring, 2019
              </option>
              <option value="Fall, 2019">
                Fall, 2019
              </option>
              <option value="Spring, 2020">
                Spring, 2020
              </option>
           </select>


           <select value="course_code" name="course_code" id="course_code" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Couse of Semester Drop
              </option>
              <option value="Temporary Drop">
                Temporary Drop
              </option>
              <option value="Program Transfer">
                Program Transfer
              </option>
              <option value="Permanant Drop">
                Permanant Drop
              </option>
               <option value="Intership Running">
                Intership Running
              </option>
           </select>

           <!--Material textarea-->

<!--Textarea with icon prefix-->
          <div class="md-form">
            <i class="fas fa-pencil-alt prefix"></i>
            <textarea id="form10" class="md-textarea form-control" rows="3" placeholder="Why you want to drop this semester? write your cause:" required=""></textarea>
          </div>
               
      </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/academic/semesterDrop.blade.php ENDPATH**/ ?>