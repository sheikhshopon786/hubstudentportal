<?php $__env->startSection('content'); ?>
 

<div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Course Registration</h3>  

             
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
       <form action="<?php echo e(url('courseRegistration')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>

       <select name="Fname" style="width: 20%; height: 10%;">
        <option selected="" disabled="">
              Select Course
            </option>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
           <option>
            <?php echo e($data->course_code); ?>

            <?php echo e($data->course_title); ?>

             
               </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            <a href="<?php echo e(url('/studentCourseRegistrationList')); ?>" button type="button" class="btn btn-danger btn-lg btn-block">See your course List</button></a>
          </div>
     
        <!-- /.row -->

  
   

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\final\student_portal\resources\views/student/courseRegistrationPage.blade.php ENDPATH**/ ?>