<?php $__env->startSection('content'); ?>
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Course Offer & Class Schedule</b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
 <form action="<?php echo e(route('store')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>

      <div class="card-body">



          <select value="semester" name="semester" id="semester"      style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Semester
              </option>
              <option value="Spring, 2019">
                Spring, 2019
              </option>
              <option value="Fall, 2019">
                Fall, 2019
              </option>
              <option value="Spring, 2020">
                Spring, 2020
              </option>
           </select>


           <select value="course_code" name="course_code" id="course_code" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Course Code
              </option>
              <option value="CSE101">
                CSE101
              </option>
              <option value="CSE202">
                CSE202
              </option>
              <option value="CSE303">
                CSE303
              </option>
           </select>

           <select value="course_title" name="course_title" id="course_title" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Course Title
              </option>
              <option value="Communication Engineering">
               Communication Engineering
              </option>
              <option value="Algorithm">
                Algorithm
              </option>
              <option value="Software Engineering">
                Software Engineering
              </option>
           </select>

           <select value="section" name="section" id="section" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Course Section
              </option>
              <option value="1">
                1
              </option>
              <option value="2">
                2
              </option>
              <option value="3">
                3
              </option>
           </select>

           <select value="credit_hour" name="credit_hour" id="credit_hour" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Credit Hour
              </option>
              <option value="1">
                1
              </option>
              <option value="3">
                3
              </option>
           </select>

           <select value="department" name="department" id="department" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Department
              </option>
              <option value="CSE">
                CSE
              </option>
              <option value="EEE">
                EEE
              </option>
              <option value="MATH">
                MATH
              </option>
           </select>

           <select value="teacher_name" name="teacher_name" id="teacher_name" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Teacher
              </option>
              <option value=" Hasan Mahmud">
                Hasan Mahmud
              </option>
              <option value="Md. Asifur Rahman">
                Md. Asifur Rahman
              </option>
              <option value="Palash Saha">
                Palash Saha
              </option>
           </select>


           <select value="day" name="day" id="day" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Day
              </option>
              <option value="Saturday">
                Saturday
              </option>
              <option value="Sunday">
                Sunday
              </option>
              <option value="Monday">
                Monday
              </option>
              <option value="Tuesday">
                Tuesday
              </option>
              <option value="Wednesday">
                Wednesday
              </option>
              <option value="Thursday">
                Thursday
              </option>
              <option value="Friday">
                Friday
              </option>
           </select>


                  <div class="form-group">
                    <label for="starting_time">Starting Time</label>
              <input type="time" class="form-control" id="starting_time" placeholder="Starting Time" name="starting_time" required="">
                  </div>

                  <div class="form-group">
                    <label for="ending_time">Ending Time</label>
              <input type="time" class="form-control" id="ending_time" placeholder="Ending Time" name="ending_time" required="">
                  </div>

            <select value="room_no" name="room_no" id="room_no" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Room No
              </option>
              <option value="142">
                142
              </option>
              <option value="137">
                137
              </option>
              <option value="CL Lab-1">
                CL Lab-1
              </option>
           </select>


          <div class="form-group row">
              <label for="reg_end_time" class="col-sm-3 text-right control-label col-form-label">Course Registration End Date</label>
              <div class="col-sm-12">
                  <input type="text" class="form-control" id="reg_end_time" placeholder="Insert Date&Month" name="reg_end_time" required="">
              </div>
          </div>





               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/academic/courseOffer.blade.php ENDPATH**/ ?>