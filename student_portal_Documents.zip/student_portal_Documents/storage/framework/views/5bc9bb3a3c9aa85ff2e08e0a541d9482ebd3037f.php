<?php $__env->startSection('content'); ?>
 




<div class="card-body"><h5 class="card-title">Complete Course:</h5>
	<table class="mb-0 table table-dark">
		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th>Course Code and Title</th>
				<th style="text-align: center;">Credit Hour</th>
				<th style="text-align: center;">Letter Grade</th>
				<th style="text-align: center;">Grade Value</th>
				<!--<th>Credit Hour</th>-->
			</tr>
		</thead>
<?php $__currentLoopData = $courseListAfterReg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseListAfterReg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				
				<td><?php echo e($courseListAfterReg->courseCodeTitile); ?> </td>

			<td style="text-align: center;"><?php echo e($courseListAfterReg->credit_hour); ?></td>

				<td style="text-align: center;"><?php echo e($courseListAfterReg->Grade); ?></td>




        

				<td style="text-align: center;"><?php echo e($courseListAfterReg->GradePoint); ?></td>


			</tr>
		</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<br>

<!--

     <b>Semester Wise GPA:</b>
<table class="mb-0 table table-dark">
    <tr>
      <th style="text-align: center;">
        Semester: 01
      </th>
       <th style="text-align: center;">
        Semester: 02
      </th>     
       <th style="text-align: center;">
        Semester: 03
      </th>  
       <th style="text-align: center;">
        Semester: 04
      </th>  
       <th style="text-align: center;">
        Semester: 05
      </th>  
       <th style="text-align: center;">
        Semester: 06
      </th>  
       <th style="text-align: center;">
        Semester: 07
      </th>  
       <th style="text-align: center;">
        Semester: 08
      </th>  
    </tr>
   

    <tr>    
      <?php $__currentLoopData = $semesterNo1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo1->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php $__currentLoopData = $semesterNo2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo2->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

       <?php $__currentLoopData = $semesterNo3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo3->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo4->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo5->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo6->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo7->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

       <?php $__currentLoopData = $semesterNo8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;">Total GPA: <?php echo e($semesterNo8->GPA); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

    </tr>
</table>
<br><br>
-->



	<b>Credit Status:</b>
	<table class="mb-0 table table-dark">
    <tr>
      <td style="text-align: center;">
        Total Credit
      </td>
      <td style="text-align: center;">
        Attend Credit
      </td>
    </tr>
   
    <tr>    
      <?php $__currentLoopData = $totalCredit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $totalCredit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;"><?php echo e($totalCredit->TotalCredit); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $creditComplete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creditComplete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td style="text-align: center;"><?php echo e($creditComplete->CreditComplete); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
</table>
</div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/student/completeCoursePage.blade.php ENDPATH**/ ?>