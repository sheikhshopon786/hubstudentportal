<?php $__env->startSection('content'); ?>
 
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Profile</h3>   

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table border="1px" class="table table-hover">
          
    <tbody>
     <?php $__currentLoopData = $studentProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentProfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="width: 100%; text-align: center;"> 

          <img src="images/profilePic.jpg" alt="John" style="width:25%"> 
          <br>
          <b><h3><?php echo e($studentProfile->student_id); ?><br>
          <?php echo e($studentProfile->FirstName); ?> 
          <?php echo e($studentProfile->LastName); ?></h3>
          Present Address: <?php echo e($studentProfile->PresentAddress); ?><br>
          Parmanent Address: <?php echo e($studentProfile->ParmanentAddress); ?><br>
          Mother Name: <?php echo e($studentProfile->MotherName); ?><br>
          Father Name: <?php echo e($studentProfile->FatherName); ?><br>
          Phone: <?php echo e($studentProfile->Phone); ?><br>
          Email: <?php echo e($studentProfile->Email); ?><br>
          Department: <?php echo e($studentProfile->Department); ?><br>
          Batch: <?php echo e($studentProfile->Batch); ?><br>
          Date of Birth: <?php echo e($studentProfile->DOB); ?><br>
          Blood Group: <?php echo e($studentProfile->BG); ?><br>
          Religion: <?php echo e($studentProfile->Religion); ?><br>
          Nationality: <?php echo e($studentProfile->Nationality); ?><br>
                 
      </div>                 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
   </table>
 </div> <!-- /.card-body -->
</div><!-- /.card -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('student.studentPart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\final\student_portal\resources\views/student/studentProfile.blade.php ENDPATH**/ ?>