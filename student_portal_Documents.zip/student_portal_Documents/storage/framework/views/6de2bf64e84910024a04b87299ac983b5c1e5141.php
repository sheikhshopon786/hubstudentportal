 
 <?php $__env->startSection('content'); ?>




 

 <div class="col-md-12">
  <div class="row">
  <div class="col-md-8" style="text-align:center; 
    background: #474747; color: white; padding: 20px;">

      <a href="login" style="text-decoration: none"> <button type="button" class="btn btn-primary btn-lg btn-block">View Result For Running Students</button></a> <br> <br>

              <button type="button" class="btn btn-secondary btn-lg btn-block">Check CGPA For Graduated Students</button>


        <form action="<?php echo e(route('search')); ?>" method="post" 
      enctype="multipart/form-data">
       <?php echo e(csrf_field()); ?>

              <label for="" class="sr-only">ID</label>
               <input type="text" class="form-control" id="search" placeholder="Enter your ID" name="search">

              <button type="submit" class="btn btn-primary">Submit</button>             
        </form>








<table class="table" style="color:#fff">
   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
  <thead>
    <tr>
        <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Department</th>
      <th scope="col">CGPA</th> 
      <th scope="col">Issuance Date</th>
       <th scope="col">Serial No</th>
    
    </tr>
  </thead>
  <tbody>
   
      <tr>
      <td><?php echo e($data->student_id); ?></td>
      <td><?php echo e($data->Name); ?></td>
      <td><?php echo e($data->DepartmentName); ?></td>
      <td><?php echo e($data->CGPA); ?></td>
      <td><?php echo e($data->PassingYear); ?></td>
      <td><?php echo e($data->SerialNumber); ?></td>
      
     
    </tr>
           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    
  </tbody>
</table>







  </div>





<div class="col-md-4" style="text-align: center; 
    background:#302f2f; color:white ; opacity: .8;">
     <div class="widget">

      <table class="table table-striped">
                  <thead>
                    <tr>
                      <th scope="col" style="color: #fff">Marks</th>
                      <th scope="col" style="color: #fff">Grade</th>
                      <th scope="col" style="color: #fff">Grade Point</th>
                      <th scope="col" style="color: #fff">Remarks</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row" style="color: #fff">80-100%</th>
                      <td style="color: #fff">A+</td>
                      <td style="color: #fff">4.00</td>
                      <td style="color: #fff">Outstanding</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">75-79%</th>
                      <td style="color: #fff">A</td>
                      <td style="color: #fff">3.75</td>
                      <td style="color: #fff">Excellent</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">70-74%</th>
                      <td style="color: #fff">A-</td>
                      <td style="color: #fff">3.50</td>
                      <td style="color: #fff">Very Good</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">65-69%</th>
                      <td style="color: #fff">B+</td>
                      <td style="color: #fff">3.25</td>
                      <td style="color: #fff">Good</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">60-64%</th>
                      <td style="color: #fff">B</td>
                      <td style="color: #fff">3.00</td>
                      <td style="color: #fff">Satisfactory</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">55-59%</th>
                      <td style="color: #fff">B-</td>
                      <td style="color: #fff">2.75</td>
                      <td style="color: #fff">Above Average</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">50-54%</th>
                      <td style="color: #fff">C+</td>
                      <td style="color: #fff">2.50</td>
                      <td style="color: #fff">Average</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">45-49%</th>
                      <td style="color: #fff">C</td>
                      <td style="color: #fff">2.25</td>
                      <td style="color: #fff">Bellow Average</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">40-44%</th>
                      <td style="color: #fff">D</td>
                      <td style="color: #fff">2.00</td>
                      <td style="color: #fff">Pass</td>
                    </tr>
                    <tr>
                      <th scope="row" style="color: #fff">00-39%</th>
                      <td style="color: #fff">F</td>
                      <td style="color: #fff">0.00</td>
                      <td style="color: #fff">Fail</td>
                    </tr>
                  </tbody>
                </table>


    </div>
</div>



 
</div>
</div>








 
</body>
</html>






 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/exam/resultVerify.blade.php ENDPATH**/ ?>