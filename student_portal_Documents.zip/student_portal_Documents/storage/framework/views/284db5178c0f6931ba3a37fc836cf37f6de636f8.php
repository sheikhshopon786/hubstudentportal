<?php $__env->startSection('content'); ?>

 
<div class="col-lg-12">
        
          <h3 class="card-title">All Students</h3>
            <div class="card-tools">
              <form action="<?php echo e(route('CourseSearch')); ?>" method="post" 
                  enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="CourseSearch" placeholder="Enter Student ID" name="CourseSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 
                 
  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">All Students</h5>
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>Semester No</th>
              <th>Semester</th>
              <th>Course Code Titile</th>
              <th>Approval</th>         
            </tr>
          </thead>
          <tbody>
             
           <?php $__currentLoopData = $studentInformationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentInformationList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
    
                        
          <td><?php echo e($studentInformationList->student_id); ?></td>
          <td><?php echo e($studentInformationList->semesterNo); ?></td>
          <td><?php echo e($studentInformationList->semester); ?></td>
          <td><?php echo e($studentInformationList->courseCodeTitile); ?></td>
          
           
          
           
           
          <td>

            <?php
            {{
              $chk=DB::select('select IFNULL(CourseApproval,0)CourseApproval  from courseregistration c, admission a where a.student_id=c.student_id and c.student_id=? order by a.student_id',[$studentInformationList->student_id]);
            }}
            ?>

            <?php $__currentLoopData = $chk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($chk->CourseApproval!=1): ?>
            <a href="<?php echo e(url('/approvalForCourse',$studentInformationList->student_id)); ?>"  class="btn btn-danger">Approve</a>
            <?php else: ?>
            <a href="<?php echo e(url('/approvalForCourse',$studentInformationList->student_id)); ?>"  class="btn btn-success">Approved</a>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </td>
        </tr>                  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/academic/courseApproved.blade.php ENDPATH**/ ?>