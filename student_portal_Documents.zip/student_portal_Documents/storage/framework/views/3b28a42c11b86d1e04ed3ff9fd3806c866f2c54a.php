<?php $__env->startSection('content'); ?>

<h1><b>Convocation Work is processing</b></h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/academic/convocation.blade.php ENDPATH**/ ?>