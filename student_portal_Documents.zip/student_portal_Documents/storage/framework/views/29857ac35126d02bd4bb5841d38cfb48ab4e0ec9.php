<?php $__env->startSection('content'); ?>
 

<!-- Waiver Input Form Start --> 

<form action="<?php echo e(route('waiverForm')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 <?php echo e(csrf_field()); ?>


 <div class="card-body">
    <h4 class="card-title">Waiver Form</h4>

    <div class="form-group row">
        <label for="Program" class="col-sm-3 text-right control-label col-form-label">Program</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="Program" placeholder="Program" name="Program" required="">
        </div>
    </div>
    <div class="form-group row">
        <label for="Waiver" class="col-sm-3 text-right control-label col-form-label">Waiver</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="Waiver" placeholder="Waiver" name="Waiver" required="">
        </div>
    </div>

    <div class="form-group row">
        <label for="Amount" class="col-sm-3 text-right control-label col-form-label">Amount</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="Amount" placeholder="Amount" name="Amount" required="">
        </div>
    </div>

    <div class="form-group row">
        <label for="Required Result" class="col-sm-3 text-right control-label col-form-label">Required Result</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="RequiredResult" placeholder="Required Result" name="RequiredResult" required="">
        </div>
    </div>


<div class="border-top">
    <div class="card-body" class="alert alert-success">
        <button type="submit" class="btn btn-primary">Submit</button>
        
         
    </div>

</div>
</form>
 


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.acc.SaccountOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/admin/acc/SwaiverFormPage.blade.php ENDPATH**/ ?>