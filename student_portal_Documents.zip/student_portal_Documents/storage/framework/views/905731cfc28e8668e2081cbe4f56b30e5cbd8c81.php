 
 <?php $__env->startSection('content'); ?>
 

 <div class="col-md-12">
  <div class="row">
    <div class="col-md-8" style="text-align:center; 
    background: #474747; color: white; padding: 20px;">

     

  


    <form action="<?php echo e(route('wsearch')); ?>" method="post" 
    enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

<!--
    <label for="" class="sr-only">Select Program</label>
    <input type="text" class="form-control" id="Program" placeholder="Select Program" name="Program">
    <br>
    <label for="" class="sr-only">Waiver</label>
    <input type="text" class="form-control" id="Waiver" placeholder="Waiver" name="Waiver">
  -->


    <select value="Program" name="Program" id="Program"  style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">

      <option selected="" disabled="">
        Select Program
      </option>
 

      <option value="CSE">CSE </option>
    </select>


    <select value="Waiver" name="Waiver" id="Waiver" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">

      <option selected="" disabled="">
        Select Waiver
      </option>


      <option value="20%">20% </option>
    </select>
 


    <button type="submit" class="btn btn-primary">Submit</button>             
  </form>








  <table class="table" style="color:#fff">
   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <thead>
    <tr>
      <th scope="col">Total Fee</th>

    </tr>
  </thead>
  <tbody>

    <tr>
      <td><?php echo e($data->Amount); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
</div>





<div class="col-md-4" style="text-align: center; 
background:#302f2f; color:white ; opacity: .8;">
<div class="widget">

  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col" style="color: #fff">Results (SSC+HSC Without 4th Subject)</th>
        <th scope="col" style="color: #fff">Waiver</th>

      </tr>
    </thead>
    <tbody>

      <tr>
        <td scope="row" style="color: #fff">10.00</td>
        <td style="color: #fff">100%</td>


      </tr>

      <tr>
        <td scope="row" style="color: #fff">9.00 - 9.99</td>
        <td style="color: #fff">40%</td>


      </tr>

      <tr>
        <td scope="row" style="color: #fff">8.00 - 8.99</td>
        <td style="color: #fff">20%</td>

      </tr>

      <tr>
        <td scope="row" style="color: #fff">7.00 - 7.99</td>
        <td style="color: #fff">10%</td>

      </tr>
    </tbody>
  </table>


</div>
</div>




</div>
</div>








 






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/account/waiverCheck.blade.php ENDPATH**/ ?>