 
 <?php $__env->startSection('content'); ?>
 
 
<div class="row">

<div class="col-md-9" style="text-align: center;">

  <div class="card-body table-responsive p-0" style="height: 550px;">

    <form action="/routineeditsv" method="post" enctype="multipart/form-data" >
        <?php echo e(csrf_field()); ?>

      <?php $__currentLoopData = $studentInformationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentInformationList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
	 <div class="" style="" >
 			<div class="uppercase" style="background-color:; color: #000">
				<h2><b class=""><?php echo e($studentInformationList->Title); ?></b></h2>
        <br>
        <img src="<?php echo e(url('/')); ?>/image/<?php echo e($studentInformationList->image); ?>" style="width: 80%;">
			</div>
 

      <div>
          <p><b><?php echo e($studentInformationList->Description); ?></b></p>
      </div>

		<ul class="list-inline">
          <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo e($studentInformationList->Day); ?></li>

          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e($studentInformationList->StartingTime); ?> - <?php echo e($studentInformationList->EndingTime); ?></li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> <?php echo e($studentInformationList->Location); ?></li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i>Category- <?php echo e($studentInformationList->Category); ?></li>
        </ul> 
	   </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </form>
</div>


</div>



  











 <div class="col-md-3">
               
              <div role="group" class="btn-group-lg btn-group btn-group-toggle" data-toggle="buttons" style="width: 100%;">
      <button type="button" class="btn btn-alternate"><b>Recent Notice</b>
      </button>
    </div>


    <!-- /.card-header -->
   <div class="card-body table-responsive p-0" style="height: 550px;">
      <table class="mb-0 table table-dark">
         
      <?php $__currentLoopData = $recentNotice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentNotice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tbody>
              <tr>
                  
       <a href="<?php echo e(url('/noticeeditreq',$recentNotice->ID)); ?>" style="text-decoration: none; float: right;" >
        <div role="group" class="btn-group-lg btn-group btn-group-toggle">
             <label class="btn btn-focus">
                 <h6><?php echo e($recentNotice->Title); ?></h6>
            </label>
        </div>
      </a>
       
              </tr>                      
          </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>

    
 </div>  
 
</div>






















</div>
  
  


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/partial/noticeEditReq.blade.php ENDPATH**/ ?>