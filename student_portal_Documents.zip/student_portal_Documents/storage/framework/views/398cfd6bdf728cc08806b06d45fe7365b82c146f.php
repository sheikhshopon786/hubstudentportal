<?php $__env->startSection('content'); ?>


<div class="col-lg-12">
        
          <h3 class="card-title">Students Payment Ledger</h3>
          <!--
            <div class="card-tools">
              <form action="<?php echo e(route('stdSearch')); ?>" method="post" 
                  enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="stdSearch" placeholder="Enter Student ID" name="stdSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 -->
                 
  <div class="main-card mb-3 card">
    <div class="card-body"> 
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>Fee Type</th>
              <th>Paid</th>
              <th>Payment Type</th>
              <th>Paid</th>
               
            </tr>
          </thead>
          <tbody>
             
           <?php $__currentLoopData = $studentPaymentLedger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentPaymentLedger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
    
                        
          <td><?php echo e($studentPaymentLedger->student_id); ?></td>
          <td><?php echo e($studentPaymentLedger->FeeType); ?></td>
          <td><?php echo e($studentPaymentLedger->Amount); ?></td>
          <td><?php echo e($studentPaymentLedger->PaymentType); ?></td>
          <td><?php echo e($studentPaymentLedger->PaymentAmount); ?></td>
       
           
           
          
         
        </tr>                  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?> studentPaymentLedger
<?php echo $__env->make('account.accountOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/account/studentPaymentLedger.blade.php ENDPATH**/ ?>