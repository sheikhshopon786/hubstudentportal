 
 <?php $__env->startSection('content'); ?>
 




    <div class="row">
      <div class="col-2">
<?php $__currentLoopData = $Notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1 class="display-4"><span class="badge badge-secondary"><?php echo e($Notice->Date); ?></span></h1>
       
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">

    <h3 class="text-uppercase"><strong><?php echo e($Notice->Title); ?></strong></h3>


    <div class="collapse" id="<?php echo e($Notice->ID); ?>">
          <p><?php echo e($Notice->Description); ?></p> 
    </div>


      <button type="button" data-toggle="collapse" data-target="#<?php echo e($Notice->ID); ?>" class="btn btn-primary">Read More</button>


      </div>
    </div>




    <div class="row">
       <div class="col-6">
        <ul class="list-inline">
          <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo e($Notice->Day); ?></li>

          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e($Notice->StartingTime); ?> - <?php echo e($Notice->EndingTime); ?></li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> <?php echo e($Notice->Location); ?></li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i>Category- <?php echo e($Notice->Category); ?></li>
        </ul> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
      </div>
    </div>



 
      

   

   
 


   
 
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/partial/notice.blade.php ENDPATH**/ ?>