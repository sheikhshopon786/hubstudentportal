<?php $__env->startSection('content'); ?>
 
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Course </b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->

<form action="<?php echo e(route('subjectInput')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
       <?php echo e(csrf_field()); ?>

      <div class="card-body">

          <div class="form-group">
              <label for="courseCodeTitile">Course Code & Titile</label>
              <input type="text" class="form-control" id="courseCodeTitile" placeholder="Course Code & Titile" name="courseCodeTitile" required="">
          </div>
 
               
      </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('academic.academicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/academic/subjectForm.blade.php ENDPATH**/ ?>