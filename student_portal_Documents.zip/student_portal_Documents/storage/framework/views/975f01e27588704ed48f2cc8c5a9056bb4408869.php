<?php $__env->startSection('content'); ?>
<!-- form start-2 -->
<div class="col-md-12">
  <!-- general form elements -->
  <div class="card card-primary">
    <div class="card-header"  >
      <h5 style="text-align: center;"><b>Document Apply </b></h5>
    </div>





    <!-- /.card-header -->
    <!-- form start-1 -->
    <div class="main-card mb-3 card">
      <div class="card-body"><h5 class="card-title">Document Apply</h5>
        <div class="form-row">
        <div class="col-md-6">
          <h6><b>ID:</b>315161012<br> 
          <b>Name:</b> Azharul Islam Shopon <br>
          <b>Program:</b>B.Sc in Computer Science & Engineering </h6>
        </div>

          <div class="col-md-3">
              <p>
                <ul type="circle">
                  <a href="#" style="text-decoration: none;"><li> Document Apply</li></a>
                  <a href="#" style="text-decoration: none;"><li>Applied Document</li></a>
                </ul>
              </p>
            </div>
              <div class="col-md-3">
              <p>
                <ul type="square">
                  <a href="#" style="text-decoration: none;"><li>Convocation Notice</li></a>
                  <a href="#" style="text-decoration: none;"><li>Convocation Apply Instruction</li></a>
                  <a href="#" style="text-decoration: none;"><li>Apply Instruction for bKash</li></a>
                  <a href="#" style="text-decoration: none;"><li>Alumni Card & Facilities</li></a>
                </ul>
              </p>
          </div>
        </div>
        <br><br>


        <form class="">
          <div class="form-row">

            <div class="col-md-6">
              <div class="position-relative form-group"><label for="ApplyDate" class="">Apply Date</label><input name="ApplyDate" id="ApplyDate" placeholder="Apply Date" type="date" class="form-control"></div>
            </div>

            <div class="col-md-6">
              <div class="position-relative form-group"><label for="DaliveryDate" class="">Dalivery Date </label><input name="DaliveryDate" id="DaliveryDate" placeholder="DaliveryDate" type="date" class="form-control"></div>
            </div>

            <div class="col-md-6">
              <div class="position-relative form-group"><label for="AlternateEmail" class="">Alternate Email</label><input name="password" id="AlternateEmail" placeholder="Alternate Email" type="AlternateEmail"
               class="form-control"></div>
             </div>

             <div class="col-md-6">
              <div class="position-relative form-group"><label for="MobileNumber" class="">Mobile Number</label><input name="password" id="MobileNumber" placeholder="Mobile Number" type="MobileNumber"
               class="form-control"></div>
             </div>

             <div class="col-md-6">
              <select value="Document" name="Document" id="Document"       class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Document
              </option>
              <option value="Spring, 2019">
                Certificate
              </option>
              <option value="Fall, 2019">
                Transcript
              </option>
           </select>
             </div>

             <div class="col-md-6">
              <select value="DocumentType" name="DocumentType" id="DocumentType"       class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Document Type
              </option>
              <option value="Spring, 2019">
                Original
              </option>
              <option value="Fall, 2019">
                Duplicate
              </option>
           </select>
             </div>

             <div class="col-md-6">
              <div class="position-relative form-group"><input name="password" id="CopyNo" placeholder="Number of Copy" type="Number"
               class="form-control"></div>
             </div>


             <div class="col-md-6">
              <select value="DocumentType" name="DocumentType" id="DocumentType"       class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Urgency Type
              </option>
              <option value="Spring, 2019">
                Urgent
              </option>
              <option value="Fall, 2019">
                Regular
              </option>
           </select>
             </div>

        </div>
          <button class="mt-2 btn btn-primary">Submit</button>
        </form>
      </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/exam/certificate.blade.php ENDPATH**/ ?>