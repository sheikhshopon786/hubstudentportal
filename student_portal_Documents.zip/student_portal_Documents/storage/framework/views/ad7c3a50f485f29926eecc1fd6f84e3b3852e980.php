<?php $__env->startSection('content'); ?>
      <div class="col-md-9" >
          <div class="widget" srt>
          	
            <h3>Product List</h3>
          	<div >
              <div class="row">

                    

                    <table class="table table-hover">
    <thead>
      <tr>
        <th>Edit</th>
        <th>ID</th>
        <th>Tittle</th>
        <th>Description</th>
        <th>Delete</th>

      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><a href="<?php echo e(url('/editreq',$data->Id)); ?>" class="btn btn-primary">Edit</a></td>
         
        <td><?php echo e($data->Id); ?></td>
        <td><?php echo e($data->Tittle); ?></td>
        <td><?php echo e($data->Description); ?></td>
         <td><a href="<?php echo e(url('/delreq',$data->Id)); ?>" class="btn btn-danger">Delete</a></td>
        
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
    </tbody>
  </table>

                    
                 
                    




              </div>
              </div>
            </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\final\student_portal\resources\views/partial/list.blade.php ENDPATH**/ ?>