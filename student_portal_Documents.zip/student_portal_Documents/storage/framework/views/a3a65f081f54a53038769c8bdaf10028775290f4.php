<?php $__env->startSection('content'); ?>


	
	<div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Sign In</h5><br>
            <form action="<?php echo e(url('academicLogin')); ?>" method="post" 
      			enctype="multipart/form-data" role="form">
       				<?php echo e(csrf_field()); ?>

              


              <div class="form-label-group">
                <input type="text" id="userID" name="userID" class="form-control" placeholder="User ID" required autofocus>
                <label for="userID">User ID</label>
              </div>

              <div class="form-label-group">
                <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                <label for="Password">Password</label>
              </div>

               

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Sign in</button>
            
              
   

     <?php if(Session('academicchklogin')!='0'): ?>
      <p>
          <?php echo e(Session::get('academicchklogin')); ?>

          </p>
    
    <?php endif; ?>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

 


<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/academic/academicLoginForm.blade.php ENDPATH**/ ?>