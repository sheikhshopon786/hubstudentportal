<?php $__env->startSection('content'); ?>
 
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">CSE Course List</h3>  

                 
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table class="table table-hover">
         <thead>
            <tr>
             
              <th scope="col">Semester</th>
               
              <th scope="col">Course Code & Title</th>
              <th scope="col">Section</th>
              <th scope="col">Credit Hour</th> 
              <th scope="col">Department</th>
              <th scope="col">Teacher's Name</th>
              <th scope="col">Day</th>
              <th scope="col">Time</th>
              <th scope="col">Room No</th>     
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($data->semester); ?></td>
              <td><?php echo e($data->courseCodeTitile); ?></td>
              
              <td><?php echo e($data->section); ?></td>
              <td><?php echo e($data->credit_hour); ?></td>
              <td><?php echo e($data->department); ?></td>
              <td><?php echo e($data->teacher_name); ?></td>
              <td><?php echo e($data->day); ?></td>
              <td><?php echo e($data->starting_time); ?> - <?php echo e($data->ending_time); ?></td>
              <td><?php echo e($data->room_no); ?></td>
            </tr>                  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
     
        <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.aca.SacademicOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/admin/aca/ScourseRegistrationRoutine.blade.php ENDPATH**/ ?>