 
  

  <!-- Site footer -->
  <footer class="site-footer">
  	<div class="container">
  		<div class="row">
  			<div class="col-sm-12 col-md-4"style="text-align: center;">
  				<h6>Important Links</h6>
  				<p class="">
            
          
               <a href="https://www.hamdarduniversity.edu.bd" target="blank">Main Website</a><br>

               <a href="https://192.168.1.249:90" target="blank">Student Database</a>
          </p>
  			</div>

  			<div class="col-xs-12 col-md-4" style="text-align: center;">
  				<img src="images/hub_logo.png" width="60px">

  				<p>
  					Founded in 2012<br> 
            Hamdard University Bangladesh<br>
            Hamdard Nagar, Gazaria, Munshiganj<br>
            info@hub.edu
  				</p>
  			</div>

  			<div class="col-xs-12 col-md-4" style="text-align: center;">
  				<h6>Quick Links</h6>
  				<ul class="footer-links">
  					<li><a href="<?php echo e(url('/about')); ?>">About Us</a></li>

  					<li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
  					 
  					<li><a href="<?php echo e(url('/rulesAndRegulation')); ?>">Rules & Regulations</a></li>
  					 
  				</ul>
  			</div>
  		</div>
  		<hr>
  	</div>
  	<div class="container">
  		<div class="row">
  			<div class="col-md-8 col-sm-6 col-xs-12">
  				<p class="copyright-text">Copyright &copy; 2019 All Rights Reserved by 
  					<a href="http://www.hamdarduniversity.edu.bd/" target="blank">HUB</a>.
  				</p>
  			</div>

  			<div class="col-md-4 col-sm-6 col-xs-12">
  				<ul class="social-icons">
  					<li><a class="facebook" href="https://www.facebook.com/hubadmission/" target="blank"><i class="fa fa-facebook"></i></a></li>
  					<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>

  					<li><a class="yotube" href="https://www.youtube.com/channel/UCD2K9QxzOdW2GJxfiMbAP2A" target="blank"><i class="fa fa-youtube"></i></a></li>
  					<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>   
  				</ul>
  			</div>
  		</div>
  	</div>
  </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/academic/footer.blade.php ENDPATH**/ ?>