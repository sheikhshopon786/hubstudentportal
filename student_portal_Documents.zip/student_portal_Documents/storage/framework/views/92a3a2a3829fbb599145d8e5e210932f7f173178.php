<?php $__env->startSection('content'); ?>
     <div class="col-md-9" >
          <div class="widget" style="margin-left: 10px;">
            
            <h3>Product Entry</h3>
            <div >
              <div class="row">

                    
      <form action="/SReditsv" method="post" enctype="multipart/form-data" >
        <?php echo e(csrf_field()); ?>


  

 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="form-group">
    <label for="ID">ID</label>
    <input type="text" class="form-control" id="ID" placeholder="Tittle" name="ID" readonly value="<?php echo e($data->ID); ?>">
  </div>

  <div class="form-group">
    <label for="student_id">Student ID</label>
    <input type="text" class="form-control" id="student_id" placeholder="Student ID" name="student_id" value="<?php echo e($data->student_id); ?>" readonly="">
  </div>

  <div class="form-group">
    <label for="semester">Semester</label>
    <input type="text" class="form-control" id="semester" placeholder="Semester" name="semester" value="<?php echo e($data->semester); ?>" readonly="">
  </div>


 <div class="form-group">
    <label for="courseCodeTitile">Course Code & Titile</label>
    <input type="text" class="form-control" id="courseCodeTitile" placeholder="Course Code & Titile" name="courseCodeTitile" value="<?php echo e($data->courseCodeTitile); ?>" readonly="">
  </div>

   <div class="form-group">
    <label for="credit_hour">Credit Hour</label>
    <input type="text" class="form-control" id="credit_hour" placeholder="Credit Hour" name="credit_hour" value="<?php echo e($data->credit_hour); ?>" readonly="">
  </div>

  <div class="form-group">
    <label for="Grade">Grade</label>
    <input type="text" class="form-control" id="Grade" placeholder="Grade" name="Grade" value="<?php echo e($data->Grade); ?>">
  </div>

  <div class="form-group">
    <label for="GradePoint">Grade Point</label>
    <input type="text" class="form-control" id="GradePoint" placeholder="Grade Point" name="GradePoint" value="<?php echo e($data->GradePoint); ?>">
  </div>


    
 

  <button type="submit" class="btn btn-primary">Save</button>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>


    </div>
    </div>

    </div>
    </div>
    
<?php $__env->stopSection(); ?>   

<?php echo $__env->make('exam.examOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/exam/stdResultInput.blade.php ENDPATH**/ ?>