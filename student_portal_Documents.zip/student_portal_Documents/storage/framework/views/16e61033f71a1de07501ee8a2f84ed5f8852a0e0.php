<?php $__env->startSection('content'); ?>


<div class="col-lg-9">
        
          <h3 class="card-title">All Students</h3>
            <div class="card-tools">
              <form action="<?php echo e(route('stdSearch')); ?>" method="post" 
                  enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="stdSearch" placeholder="Enter Student ID" name="stdSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 
                 
  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">Table responsive</h5>
      <div class="table-responsive">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Present Address</th>
              <th>Parmanant Address</th>
              <th>Father's Name</th>
              <th>Mother's Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Department</th>
              <th>Batch</th>
              <th>Date of Birth</th>
              <th>Blood Group</th>
              <th>Religion</th>
              <th>Nationality</th>
              <th>Admit Clearance</th>
              
            </tr>
          </thead>
          <tbody>
             
           <?php $__currentLoopData = $studentInformationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentInformationList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
    
                        
          <td><?php echo e($studentInformationList->student_id); ?></td>
          <td><?php echo e($studentInformationList->FirstName); ?></td>
          <td><?php echo e($studentInformationList->LastName); ?></td>
          <td><?php echo e($studentInformationList->PresentAddress); ?></td>
          <td><?php echo e($studentInformationList->ParmanentAddress); ?></td>
          <td><?php echo e($studentInformationList->MotherName); ?></td>
          <td><?php echo e($studentInformationList->FatherName); ?></td>
          <td><?php echo e($studentInformationList->Phone); ?></td>
          <td><?php echo e($studentInformationList->Email); ?></td>
          <td><?php echo e($studentInformationList->Department); ?></td>
          <td><?php echo e($studentInformationList->Batch); ?></td>
          <td><?php echo e($studentInformationList->DOB); ?></td>
          <td><?php echo e($studentInformationList->BG); ?></td>
          <td><?php echo e($studentInformationList->Religion); ?></td>
          <td><?php echo e($studentInformationList->Nationality); ?></td>
         
         <!--  
          <td>
            <a href="<?php echo e(url('/editreq',$studentInformationList->student_id)); ?>" class="btn btn-primary">Edit</a>
          </td> 
          <td>
            <a href="<?php echo e(url('/delreq',$studentInformationList->student_id)); ?>" class="btn btn-danger">Delete</a>
          </td>-->

         <td>
            <?php
            {{
              $chk=DB::select('select IFNULL(adminapproval,0)adminapproval  from courseregistration c, admission a where a.student_id=c.student_id and c.student_id=? order by a.student_id',[$studentInformationList->student_id]);
            }}
            ?>

            <?php $__currentLoopData = $chk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($chk->adminapproval!=1): ?>
            <a href="<?php echo e(url('/approval2',$studentInformationList->student_id)); ?>"  class="btn btn-danger">Admit Card</a>
            <?php else: ?>
              
            <a href="<?php echo e(url('/approval2',$studentInformationList->student_id)); ?>"  class="btn btn-success">Admit Card</a>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </td>               
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('exam.examOffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/exam/studentInformationExam.blade.php ENDPATH**/ ?>