<?php $__env->startSection('content'); ?>
 

<style>
.ct {
  text-align: center;
  font-size: 20px;
  margin-top: 0px;
  width: 50%;
 
}
</style>


<div class="row">

<div class="col-md-6">
            <div class="card">

              <div class="card-header">
                <h3 class="card-title">Course Registration</h3> 
                
              </div>
              <!-- /.card-header -->

<!-- Countdown Timer Start -->
<!--
            <div class="card-header">
              <h3 class="card-title">Registration Time is Over After:</h3>  
            </div>

<b><p class="ct" id="demo"></p></b>


<script>
// Set the date we're counting down to
var countDownDate = new Date("2020-01-30").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "d: " + hours + "h: "
  + minutes + "m: " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
-->
<!-- Countdown Timer End -->



   
              <div class="card-body table-responsive p-0" style="height: 800px; width: 100%">

              
 
       <form action="<?php echo e(url('courseRegistration')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>

    
      <select name="semesterNo" style="width: 100%;" class="mb-2 form-control-lg form-control" required="">
  
        <option selected="" disabled="">
              Select Semester
            </option>
            <?php $__currentLoopData = $semesterNo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semesterNo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($semesterNo->semesterNo); ?>"><?php echo e($semesterNo->semesterNo); ?></option>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </select>
        <button type="submit" class="btn btn-primary" style="width: 100%;"><b>Submit</b></button>
      </form>

<br><br><br>





<form action="<?php echo e(url('studentCourseRegistrationList')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
  <?php echo e(csrf_field()); ?>

          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Please Check Your Choose List And Confirm Course Registration</h3>  
              </div>



    <!-- /.card-header -->
     <div class="card-body table-responsive p-0" style="height: 500px;">
        <table class="mb-0 table table-dark">
         <thead>

              <th scope="col">Season</th>
              <th scope="col">Course Code and Titile</th>
              <th scope="col">Credit</th>
              <!--<th scope="col">Update</th> -->
              <th scope="col">Delete</th>
               <!--<th scope="col">Cencel</th>-->

            </tr>
   </thead>
    <tbody>

     

       
     <?php $__currentLoopData = $studentCourseRegistrationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentCourseRegistrationList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
    
                        
          <td><?php echo e($studentCourseRegistrationList->semester); ?></td>
          <td><?php echo e($studentCourseRegistrationList->courseCodeTitile); ?></td>
          <td><?php echo e($studentCourseRegistrationList->credit_hour); ?></td>
          <!--
           <td><a href="<?php echo e(url('/courseEditReq',$studentCourseRegistrationList->Id)); ?>" class="btn btn-primary">Edit</a></td> -->

          <td><a href="<?php echo e(url('/courseDelReq',$studentCourseRegistrationList->Id)); ?>" class="btn btn-danger"><b>Drop</b></a></td>

       <!-- <td>
            <a href="<?php echo e(url('/courseCencelReq',$studentCourseRegistrationList->Id)); ?>" class="btn btn-danger" style="width: 100%;"><b>Cencel</b></a> 
        </td>-->
      </tr>                      
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     


    

    
<tr>
  <td colspan="5">
    <button type="submit" value="submit" name="submit" class="btn btn-primary" style="width: 100%;"><b>Submit</b></button>
  </td>
</tr>

  

</tbody>
   </table>
   
    </form>

   <!-- <a href="<?php echo e(url('/Cencel',$extraCourseList)); ?>" class="btn btn-danger" style="width: 100%;"><b>Cencel</b></a>-->

    <br><br><br>


       






<form action="<?php echo e(route('extraCourseListSearch')); ?>" method="post" 
    enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

  <table class="mb-0 table table-dark">
      <tr>
        <td> <b>Add Extra Course</b>
            <i class="metismenu-icon pe-7s-right-arrow"></i>
        </td>  
        <td style="text-align: right;">    
            <button type="submit" value="B.Sc in Computer Science & Engineering" name="department" id="department" class="btn btn-alternate"><b>Add Course</b></button>
        </td>     
      </tr>
   </table>
 </form>


 </div>  
</div>
</div>


<br>

 



    




</div>
</div>     
</div>
<!-- /.card-body -->
        

<!--Right Side-->

  <div class="col-md-6">
            <div class="card">

              <div class="">

               <a href="<?php echo e(url('/completeCourse')); ?>" >
                  <div role="group" class="btn-group-lg btn-group btn-group-toggle" style="text-decoration: none; float: right;">
                <label class="btn btn-focus">
                  <b>See your complete course list</b>
                  <i class="metismenu-icon pe-7s-right-arrow"></i>
                </label>
                </div>
              </a> 
                 
              </div>
              <!-- /.card-header -->


              <div class="card-body table-responsive p-0" style="height: 800px; width: 100%">





          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Select Your Extra Course</h3>  
              </div>


<form action="<?php echo e(url('courseRegistration')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
  <?php echo e(csrf_field()); ?>

    <!-- /.card-header -->
   <div class="card-body table-responsive p-0" style="height: 420px;">
      <table class="mb-0 table table-dark">
         <thead>
            <tr> 
              <th scope="col">Course Code and Titile</th>
              <th scope="col">Select</th>       
            </tr>
          </thead>
      <?php $__currentLoopData = $extraCourseList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extraCourseList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tbody>
              <tr>
                 <td><?php echo e($extraCourseList->courseCodeTitile); ?></td>

                <td style="text-align: center;"><input type="radio" name="courseCodeTitile" id="courseCodeTitile" value="<?php echo e($extraCourseList->courseCodeTitile); ?>" required=""></td>

              </tr>                      
          </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>

    
 </div>  
 <button type="submit" value="submit" name="submit" class="btn btn-primary" style="width: 100%;"><b>Submit</b></button>
</div>
</div>

</form>


</div>
</div>     
</div>













</div>    
     
      
  <!-- /.row -->





 


  
   

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/student/courseRegistrationPage.blade.php ENDPATH**/ ?>