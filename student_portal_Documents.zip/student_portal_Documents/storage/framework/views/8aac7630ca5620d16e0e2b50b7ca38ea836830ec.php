<?php $__env->startSection('content'); ?>




 

  
  <div class="col-md-12" style="text-align:center; 
    background: ; color: white; padding: 20px;">
 
              <button type="button" class="btn btn-secondary btn-lg btn-block"><b>Type To Search To Get Student Information</b> </button>


        <form action="<?php echo e(route('stdsearch')); ?>" method="post" 
      enctype="multipart/form-data">
       <?php echo e(csrf_field()); ?>

              <label for="" class="sr-only">ID</label>
               <input type="text" class="form-control" id="stdsearch" placeholder="Enter Student ID" name="stdsearch">

              <button type="submit" class="btn btn-primary" style="width: 100%"><b>Submit</b></button> 
        </form>










<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Student Details</b></h4></caption>

 

     

    
  <?php $__currentLoopData = $studentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
  <div class="row">

    <div class="col-md-3"> 
       <img src="<?php echo e(url('/')); ?>/image/<?php echo e($studentInfo->image); ?>" style="width: 90%; height:40%; border-radius:10px;">  
    </div>

    <div class="col-md-9">
    <table class="table table-hover table-dark">
          <tbody>
           
            <tr>
              <td style="text-align: left;"><b>ID:</b></td>
              <td style="text-align: left;"><?php echo e($studentInfo->student_id); ?></td>
            </tr>
            <tr>
               <td style="text-align: left;"><b>First Name:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->FirstName); ?></td>
            </tr>
            <tr>
                 <td style="text-align: left;"><b>Last Name:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->LastName); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Batch:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->Batch); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Gender:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->Gender); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Religion:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->Religion); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Blood Group:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->BG); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Phone Number:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->Phone); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Date of Birth:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->DOB); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Email Address:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->Email); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Department:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->Department); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Faculty:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->Faculty); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Father's Name:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->FatherName); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Mother's Name:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->MotherName); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Present Address:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->PresentAddress); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Permanent Address:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->ParmanentAddress); ?></td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Nationality:</b></td>
                <td style="text-align: left;"><?php echo e($studentInfo->Nationality); ?></td>
              </tr>                 
       
          </tbody>
        </table>
      </div>

</div>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</div>
<br><br><br>









<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Payment Scheme</b></h4></caption>

 <table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">Fee Type</th>
      <th scope="col">Amount</th>
      <th scope="col">Payment Type</th>
      <th scope="col">Payment Amount</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $paymentscheme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentscheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr>
      <td><?php echo e($paymentscheme->FeeType); ?></td>
      <td><?php echo e($paymentscheme->Amount); ?></td>
      <td><?php echo e($paymentscheme->PaymentType); ?></td>
      <td><?php echo e($paymentscheme->PaymentAmount); ?></td>
          
    </tr>       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
  </tbody>
</table>
<br><br><br>




<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Semestr Wise GPA</b></h4></caption>
 <table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">Semester</th>
      <th scope="col">SGPA</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $resultscheme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultscheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr>
      <td><?php echo e($resultscheme->Semester); ?></td>
      <td><?php echo e($resultscheme->SGPA); ?></td>    
    </tr>       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
  </tbody>
</table>
</div>
</div>
<br><br><br>





<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Subject Wise Grade</b></h4></caption>
 <table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">Course Code And Title</th>
      <th scope="col">Credit</th>
      <th scope="col">Grade</th>
      <th scope="col">Grade Point</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $studentresult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentresult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr>
      <td><?php echo e($studentresult->CourseCodeTitle); ?></td>
      <td><?php echo e($studentresult->Credit); ?></td>
      <td><?php echo e($studentresult->Grade); ?></td>    
      <td><?php echo e($studentresult->GradePoint); ?></td>
    </tr>       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
  </tbody>
</table>
</div>
<br><br><br>



<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Complete Course</b></h4></caption>
 <table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">Course Code And Title</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $completecourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $completecourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr>
      <td style="text-align: center;"><?php echo e($completecourse->courseCodeTitile); ?></td>
       
    </tr>       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
  </tbody>
</table>
</div>
<br><br><br>






















</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.std.SstudentPart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/admin/std/SstudentDashBoard.blade.php ENDPATH**/ ?>