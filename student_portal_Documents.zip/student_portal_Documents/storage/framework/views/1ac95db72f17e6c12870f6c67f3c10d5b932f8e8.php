<!--Sidebar, navBar, Content Field Start-->
	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
	 <!-- Bootstrap tether Core JavaScript -->
	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/popper.js/dist/umd/popper.min.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/extra-libs/sparkline/sparkline.js')); ?>"></script>
	 <!--Wave Effects -->
	 <script type="text/javascript" src="<?php echo e(URL::asset('dist/js/waves.js')); ?>"></script>
	 <!--Menu sidebar -->
	 <script type="text/javascript" src="<?php echo e(URL::asset('dist/js/sidebarmenu.js')); ?>"></script>
	 <!--Custom JavaScript -->
	 <script type="text/javascript" src="<?php echo e(URL::asset('dist/js/custom.min.js')); ?>"></script>
	    <!-- Charts js Files -->
	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/flot/excanvas.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/flot/jquery.flot.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/flot/jquery.flot.pie.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/flot/jquery.flot.time.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/flot/jquery.flot.stack.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/flot/jquery.flot.crosshair.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js')); ?>"></script>

	 <script type="text/javascript" src="<?php echo e(URL::asset('dist/js/pages/chart/chart-page-init.js')); ?>"></script>

 <!--Sidebar, navBar, Content Field End-->


 <!-- fullCalendar 2.2.5 -->
    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/moment/moment.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar-daygrid/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar-timegrid/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar-interaction/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/fullcalendar-bootstrap/main.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(URL::asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<!-- End fullCalendar 2.2.5 -->





<?php /**PATH C:\Users\User\Desktop\final\student_portal\resources\views/links/script.blade.php ENDPATH**/ ?>