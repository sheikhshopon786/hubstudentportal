<?php $__env->startSection('content'); ?>






<div class="card-body"><h4 class="" style="text-align: center;"><b>Live Result</b></h4>
	
</div>



<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h6><b>Live Result :[Subject Name]</b></h6></caption>
	<table class="mb-0 table table-dark">

		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th style="text-align: center;">Quiz 1:</th>
				<th style="text-align: center;">Quiz 2:</th>
				<th style="text-align: center;">Quiz Average</th>
				<th style="text-align: center;">Midterm</th>
				<th style="text-align: center;">Midterm Improvement:</th>
			</tr>
		</thead>

		<tbody>
			<tr>

				<td style="text-align: center;">10</td>
				<td style="text-align: center;">4</td>
				<td style="text-align: center;">7</td>
				<td style="text-align: center;">20</td>
				<td style="text-align: center;">0</td>
			</tr>
		</tbody>
	</table>
</div>
					






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/exam/liveResult2.blade.php ENDPATH**/ ?>