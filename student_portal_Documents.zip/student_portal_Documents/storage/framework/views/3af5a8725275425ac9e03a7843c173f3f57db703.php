<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>




<table style="width: 100%">
    <tr>
        <td colspan="3">
        	<img src="images/hub_logo.png" style="width:100px"><br>
        	<b>Hamdard University Bangladesh</b>
        </td>
         

         

        <td colspan="0" style="text-align: right;"><font size="5"><b>    Admit Card</b></font><br>
        	Midterm Examination<br>
        	Fall-2019<br>
            <?php $__currentLoopData = $admitserial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admitserial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            SI No- <?php echo e($admitserial->Serial); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
    </tr>

    <tr>
	    <td colspan="6">
	    	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	    </td>
    </tr>
<?php $__currentLoopData = $stdInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stdInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="3">
        	Student ID: <?php echo e($stdInfo->student_id); ?><br>
        	Student Name: [Select Text]<br>
        	Faculty: [Select Text]<br>
        	Program: [Select Text]<br>
        </td>

        <td colspan="2" style="text-align: right;">
        	<img src="images/profilePic.jpg" style="width:100px"><br>
        		RCH - [Select Text]
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <tr>
	    <td colspan="6">
	    	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	    </td>
    </tr>



    <tr>
    	<th>Course Code and Title</th>
        <th>Section</th>
        <th>Chr</th>
    </tr>

<?php $__currentLoopData = $courseForAdmit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseForAdmit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
    	<td><?php echo e($courseForAdmit->courseCodeTitile); ?></td>
    	<td>[Select Text]</td>
    	<td>[Select Text]</td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr>
    	<td>[CSE142]</td>
    	<td>Software Engineering</td>
    	<td>1</td>
    </tr>

    <tr>
    	<td>[Select Text]</td>
    	<td>[Select Text]</td>
    	<td>[Select Text]</td>
    </tr>

    <tr>
    	<td>[Select Text]</td>
    	<td>[Select Text]</td>
    	<td>[Select Text]</td>
    </tr>


    <tr>
    	<td colspan="4">
    		<br><br><br><br><br><br><br><br><br><br>
    	</td>
	</tr>


    <tr>
    	<td colspan="4">
    		
    		<b><u>Instructions for Examinees</u></b><br>
    	<ul type="bullet">
    		<li>Examinees should enter the examination hall 10 minuties before the examination starts.<br></li>
    		
    		<li>No examinee shakk be alllowed to sit dor the examination without the Admit Card.<br></li>

    		<li>Cellular phone,Electronic Dairy or such kind of device will not be allowed in the examonation hall.<br></li>

    		<li>No examinees shall be allowed to carry any paper's except the Admit Card.<br></li>
    		<b>
    		<li>If an examinee lost, destroyed or forgot to bring the Admit Card, he/she will have to collect new Admit Card with payment of TK. 100 (one hundres).</b> <br></li>

    		<li>No examinee can go out within 30 minuties of Midterm Exam and 01 Hour of Final Exam.<br><br><br><br><br></li></ol>

    	</td>
    </tr>

    <tr>
    	<td colspan="4">
    		--------------------------<br>
    		<b>Controller of Examination</b>
    	</td>
    </tr>

     <tr>
    	<td colspan="4" style="text-align: center;">
    		Please Preserve this Admit Card for future references
    	</td>
    </tr>

</table>


<button type="submit" class="btn btn-primary">Download</button>


















</body>
</html><?php /**PATH C:\Users\User\Desktop\14.01.2020\student_portal\resources\views/exam/admitCard.blade.php ENDPATH**/ ?>