<?php $__env->startSection('content'); ?>
 
<div class="col-md-12">
	
<img src="images/studentIndex3.jpg">

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.studentpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/student/studentIndex.blade.php ENDPATH**/ ?>