<form action="<?php echo e(url('registerFormEntry')); ?>" method="post" 
      enctype="multipart/form-data" role="form">
       <?php echo e(csrf_field()); ?>


<div class="form-row">
    <div class="form-group col-md-6">
      <label for="type">Type</label>
      <input type="type" class="form-control" id="type" name="type" placeholder="Type">
    </div>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="email">Email</label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Email">
    </div>

    <div class="form-group col-md-6">
      <label for="password">Password</label>
      <input type="password" class="form-control" id="password" name="password" placeholder="password">
    </div>password

     <div class="form-group col-md-6">
      <label for="userID">User ID</label>
      <input type="text" class="form-control" id="userID" name="userID" placeholder="User ID">
    </div>


  </div>
  
  
 
 
  <button type="submit" class="btn btn-primary">Sign in</button>
</form><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\New folder\student_portal\resources\views/partial/registerForm.blade.php ENDPATH**/ ?>