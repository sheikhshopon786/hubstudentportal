 
<?php $__env->startSection('content'); ?>


	<div role="group" class="btn-group-lg btn-group btn-group-toggle">
             <label class="btn btn-focus">
                 Academic Clearance is Successful
            </label>
    </div> <br> <br>

    <div role="group" class="btn-group-lg btn-group btn-group-toggle">
             <label class="btn btn-focus">
                Accounts office clearance is not execute<br>
                Please payout your due<br>
                Thank you
            </label>
        </div>







<!--
<table>
 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               
            <td><?php echo e($data->AcademicOffice); ?></td> 

            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
-->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\17.12.19-sir\student_portal\resources\views/partial/studentClearance.blade.php ENDPATH**/ ?>