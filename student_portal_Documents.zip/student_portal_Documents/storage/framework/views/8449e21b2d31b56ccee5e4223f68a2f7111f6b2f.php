<?php $__env->startSection('content'); ?>
      


	<div class="col-md-12" >
          <div class="widget" style="margin-left: 10px;">
            
            <h3>Student Profile Update</h3>
            <div >
              <div class="row">

                    
      <form action="/editsv" method="post" enctype="multipart/form-data" >
        <?php echo e(csrf_field()); ?>


  

 <?php $__currentLoopData = $studentInformationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentInformationList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="form-group">
    <label for="student_id">Student ID</label>
    <input type="text" class="form-control" id="student_id" placeholder="student_id" name="student_id" readonly value="<?php echo e($studentInformationList->student_id); ?>">
  </div>
  <div class="form-group">
    <label for="FirstName">First Name</label>
    <input type="text" class="form-control" id="FirstName" placeholder="First Name" name="FirstName" value="<?php echo e($studentInformationList->FirstName); ?>">
  </div>

  <div class="form-group">
    <label for="LastName">Last Name</label>
    <input type="text" class="form-control" id="LastName" placeholder="Last Name" name="LastName" value="<?php echo e($studentInformationList->LastName); ?>">
  </div>

  <div class="form-group">
    <label for="PresentAddress">Present Address</label>
    <input type="text" class="form-control" id="PresentAddress" placeholder="Present Address" name="PresentAddress" value="<?php echo e($studentInformationList->PresentAddress); ?>">
  </div>

  <div class="form-group">
    <label for="ParmanentAddress"> Parmanent Address</label>
    <input type="text" class="form-control" id="ParmanentAddress" placeholder=" Parmanent Address" name="ParmanentAddress" value="<?php echo e($studentInformationList->ParmanentAddress); ?>">
  </div>

  <div class="form-group">
    <label for="FatherName">Father Name </label>
    <input type="text" class="form-control" id="FatherName" placeholder=" Father Name" name="FatherName" value="<?php echo e($studentInformationList->FatherName); ?>">
  </div>

  <div class="form-group">
    <label for="MotherName"> Mother Name</label>
    <input type="text" class="form-control" id="MotherName" placeholder=" Mother Name" name="MotherName" value="<?php echo e($studentInformationList->MotherName); ?>">
  </div>

  <div class="form-group">
    <label for="Phone"> Phone</label>
    <input type="text" class="form-control" id="Phone" placeholder=" Phone" name="Phone" value="<?php echo e($studentInformationList->Phone); ?>">
  </div>

  <div class="form-group">
    <label for="Email">Email </label>
    <input type="text" class="form-control" id="Email" placeholder=" Email" name="Email" value="<?php echo e($studentInformationList->Email); ?>">
  </div>

<div class="form-group">
    <label for="Department">Department </label>
    <input type="text" class="form-control" id="Department" placeholder=" Department" name="Department" value="<?php echo e($studentInformationList->Department); ?>">
  </div>


<div class="form-group">
    <label for="Batch">Batch </label>
    <input type="text" class="form-control" id="Batch" placeholder=" Batch" name="Batch" value="<?php echo e($studentInformationList->Batch); ?>">
  </div>

<div class="form-group">
    <label for="DOB">DOB </label>
    <input type="text" class="form-control" id="DOB" placeholder=" DOB" name="DOB" value="<?php echo e($studentInformationList->DOB); ?>">
  </div>

  <div class="form-group">
    <label for="BG">BG </label>
    <input type="text" class="form-control" id="BG" placeholder=" BG" name="BG" value="<?php echo e($studentInformationList->BG); ?>">
  </div>

<div class="form-group">
    <label for="Religion">Religion </label>
    <input type="text" class="form-control" id="Religion" placeholder=" Religion" name="Religion" value="<?php echo e($studentInformationList->Religion); ?>">
  </div>

  <div class="form-group">
    <label for="Nationality">Nationality </label>
    <input type="text" class="form-control" id="Nationality" placeholder=" Nationality" name="Nationality" value="<?php echo e($studentInformationList->Nationality); ?>">
  </div>
    
    <div class="form-group">
    <label for="password">Password </label>
    <input type="text" class="form-control" id="password" placeholder=" password" name="password" value="<?php echo e($studentInformationList->password); ?>">
  </div>
 

  <button type="submit" class="btn btn-primary">Save</button>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>


		
<?php $__env->stopSection(); ?>		

<?php echo $__env->make('layout.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\14.01.2020-sir\student_portal\resources\views/partial/EditReq.blade.php ENDPATH**/ ?>