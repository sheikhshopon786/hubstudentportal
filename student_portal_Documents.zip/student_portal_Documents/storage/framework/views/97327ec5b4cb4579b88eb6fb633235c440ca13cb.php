 
 <?php $__env->startSection('content'); ?>
 




<div class="col-md-9">
    <div class="row row-striped">
      <div class="col-2 text-right">
        <h1 class="display-4"><span class="badge badge-secondary">16</span></h1>
        <h2>NOV</h2>
      </div>
      <div class="col-10">
        <h3 class="text-uppercase"><strong>Fresher’s Reception Fall 2019 held at Hamdard University Bangladesh</strong></h3>
        <ul class="list-inline">
            <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> saturday</li>
          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> 11:00 AM - 4:00 PM</li>
          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> multipurpose hall</li>
        </ul>
         
      </div>
    </div>



    <div class="row row-striped">
      <div class="col-2 text-right">
        <h1 class="display-4"><span class="badge badge-secondary">16</span></h1>
        <h2>NOV</h2>
      </div>
      <div class="col-10">
        <h3 class="text-uppercase"><strong>Fresher’s Reception Fall 2019 held at Hamdard University Bangladesh</strong></h3>
        <ul class="list-inline">
            <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> saturday</li>
          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> 11:00 AM - 4:00 PM</li>
          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> multipurpose hall</li>
        </ul>
         
      </div>
    </div>


    <div class="row row-striped">
      <div class="col-2 text-right">
        <h1 class="display-4"><span class="badge badge-secondary">28</span></h1>
        <h2>SEP</h2>
      </div>
      <div class="col-10">
        <h3 class="text-uppercase"><strong>A Seminar on “Education, Morality, Vision & Ethical Values in Life” held at Hamdard University Bangladesh</strong></h3>
        <ul class="list-inline">
            <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> saturday</li>
          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> 11:00 AM - 1:00 PM</li>
          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> multipurpose hall</li>
        </ul>
         
      </div>
    </div>
  </div><br> <br>

   
 


</div>
  
 
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\12.12.2019\student_portal\resources\views/partial/notice.blade.php ENDPATH**/ ?>