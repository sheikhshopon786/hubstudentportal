@extends('student.studentpart')
@section('content')
 
<!--Student Information form start -->

<!--Student Information form End --> 

<form action="{{url('/proUpdateReq')}}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 {{csrf_field()}}

 @foreach ($studentProfile as $data)                          
 <div class="card-body">
     <h4 class="card-title">Update profile</h4>


     <div class="form-group row">
        <label for="student_id" class="col-sm-3 text-right control-label col-form-label">Student ID</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="student_id" placeholder="Last Name" name="student_id" readonly value="{{$data->student_id}}">
        </div>
    </div>


    <div class="form-group row">
      <label for="FirstName" class="col-sm-3 text-right control-label col-form-label">First Name</label>
      <div class="col-sm-9">
          <input type="text" class="form-control" id="FirstName" placeholder="First Name" name="FirstName" readonly value="{{$data->FirstName}}">
      </div>
  </div>



  <div class="form-group row">
    <label for="LastName" class="col-sm-3 text-right control-label col-form-label">Last Name</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="LastName" placeholder="Last Name" name="LastName" readonly value="{{$data->LastName}}">
    </div>
</div>

<div class="form-group row">
    <label for="PresentAddress" class="col-sm-3 text-right control-label col-form-label">Present Address</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="PresentAddress" placeholder=" Present Address" name="PresentAddress" value="{{$data->PresentAddress}}">
 </div>
</div>

<div class="form-group row">
    <label for="ParmanentAddress" class="col-sm-3 text-right control-label col-form-label">Parmanent Address</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="ParmanentAddress" placeholder=" Parmanent Address" name="ParmanentAddress" readonly="" value="{{$data->ParmanentAddress}}">
 </div>
</div>

<div class="form-group row">
    <label for="FatherName" class="col-sm-3 text-right control-label col-form-label">Father's Name</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="FatherName" placeholder=" Father's Name" name="FatherName" readonly value="{{$data->FatherName}}">
    </div>
</div>

<div class="form-group row">
    <label for="MotherName" class="col-sm-3 text-right control-label col-form-label">Mother's Name</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="MotherName" placeholder=" Mother's Name" name="MotherName" readonly value="{{$data->MotherName}}">
 </div>
</div>


<div class="form-group row">
    <label for="Phone" class="col-sm-3 text-right control-label col-form-label">Phone</label>
    <div class="col-sm-9" >
        <input type="text" class="form-control" id="Phone" placeholder=" Phone" name="Phone" value="{{$data->Phone}}">
    </div>
</div>

<div class="form-group row">
    <label for="Email" class="col-sm-3 text-right control-label col-form-label">Email</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="Email" placeholder=" Email" name="Email" value="{{$data->Email}}">
  </div>
</div>


<div class="form-group row">
    <label for="Batch" class="col-sm-3 text-right control-label col-form-label">Batch</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Batch" placeholder=" Batch" name="Batch" readonly value="{{$data->Batch}}">
    </div>
</div>

<div class="form-group row">
    <label for="DOB" class="col-sm-3 text-right control-label col-form-label">Date of Birth</label>
    <div class="col-sm-9">
       <input type="text" class="form-control" id="DOB" placeholder=" Date of Birth" readonly name="DOB" value="{{$data->DOB}}">
   </div>
</div>

<div class="form-group row">
    <label for="BG" class="col-sm-3 text-right control-label col-form-label">Blood Group</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="BG" placeholder=" Blood Group" name="BG" value="{{$data->BG}}">
    </div>
</div>

<div class="form-group row">
    <label for="Religion" class="col-sm-3 text-right control-label col-form-label">Religion</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Religion" placeholder=" Religion" name="Religion" value="{{$data->Religion}}">
    </div>
</div>

<div class="form-group row">
    <label for="Nationality" class="col-sm-3 text-right control-label col-form-label">Nationality</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" id="Nationality" placeholder=" Nationality" name="Nationality" readonly="" value="{{$data->Nationality}}">
    </div>
</div>

 <div class="form-group">
    <label for="image">Image</label>
    <input type="file" class="form-control" id="image" placeholder="Image" name="image" value="{{$data->image}}">
  </div>
  

<div class="form-group row">
    <label for="Password" class="col-sm-3 text-right control-label col-form-label">Password</label>
    <div class="col-sm-9">
        <input type="password" class="form-control" id="password" placeholder=" password" name="password" value="{{$data->password}}">
    </div>
</div>

<div class="border-top">
    <div class="card-body">
        <button type="submit" class="btn btn-primary">Update</button>
    </div>
</div>@endforeach
</form>
@endsection

