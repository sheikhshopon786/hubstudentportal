@extends('student.studentpart')
@section('content')
 




<div class="card-body"><h5 class="card-title">Complete Course:</h5>
	<table class="mb-0 table table-dark">
		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th>Course Code and Title</th>
				<th style="text-align: center;">Credit Hour</th>
				<th style="text-align: center;">Letter Grade</th>
				<th style="text-align: center;">Grade Value</th>
				<!--<th>Credit Hour</th>-->
			</tr>
		</thead>
@foreach($courseListAfterReg as $courseListAfterReg)
		<tbody>
			<tr>
				
				<td>{{$courseListAfterReg->courseCodeTitile}} </td>

			<td style="text-align: center;">{{$courseListAfterReg->credit_hour}}</td>

				<td style="text-align: center;">{{$courseListAfterReg->Grade}}</td>




        

				<td style="text-align: center;">{{$courseListAfterReg->GradePoint}}</td>


			</tr>
		</tbody>
@endforeach
	</table>
	<br>

<!--

     <b>Semester Wise GPA:</b>
<table class="mb-0 table table-dark">
    <tr>
      <th style="text-align: center;">
        Semester: 01
      </th>
       <th style="text-align: center;">
        Semester: 02
      </th>     
       <th style="text-align: center;">
        Semester: 03
      </th>  
       <th style="text-align: center;">
        Semester: 04
      </th>  
       <th style="text-align: center;">
        Semester: 05
      </th>  
       <th style="text-align: center;">
        Semester: 06
      </th>  
       <th style="text-align: center;">
        Semester: 07
      </th>  
       <th style="text-align: center;">
        Semester: 08
      </th>  
    </tr>
   

    <tr>    
      @foreach($semesterNo1 as $semesterNo1)
      <td style="text-align: center;">Total GPA: {{$semesterNo1->GPA}}</td>
      @endforeach

       @foreach($semesterNo2 as $semesterNo2)
      <td style="text-align: center;">Total GPA: {{$semesterNo2->GPA}}</td>
      @endforeach    

       @foreach($semesterNo3 as $semesterNo3)
      <td style="text-align: center;">Total GPA: {{$semesterNo3->GPA}}</td>
      @endforeach  

       @foreach($semesterNo4 as $semesterNo4)
      <td style="text-align: center;">Total GPA: {{$semesterNo4->GPA}}</td>
      @endforeach  

       @foreach($semesterNo5 as $semesterNo5)
      <td style="text-align: center;">Total GPA: {{$semesterNo5->GPA}}</td>
      @endforeach  

       @foreach($semesterNo6 as $semesterNo6)
      <td style="text-align: center;">Total GPA: {{$semesterNo6->GPA}}</td>
      @endforeach  

       @foreach($semesterNo7 as $semesterNo7)
      <td style="text-align: center;">Total GPA: {{$semesterNo7->GPA}}</td>
      @endforeach  

       @foreach($semesterNo8 as $semesterNo8)
      <td style="text-align: center;">Total GPA: {{$semesterNo8->GPA}}</td>
      @endforeach  

    </tr>
</table>
<br><br>
-->



	<b>Credit Status:</b>
	<table class="mb-0 table table-dark">
    <tr>
      <td style="text-align: center;">
        Total Credit
      </td>
      <td style="text-align: center;">
        Attend Credit
      </td>
    </tr>
   
    <tr>    
      @foreach($totalCredit as $totalCredit)
      <td style="text-align: center;">{{$totalCredit->TotalCredit}}</td>
      @endforeach
      @foreach($creditComplete as $creditComplete)
      <td style="text-align: center;">{{$creditComplete->CreditComplete}}</td>
      @endforeach
    </tr>
</table>
</div>







@endsection