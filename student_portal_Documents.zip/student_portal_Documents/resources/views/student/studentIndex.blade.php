@extends('student.studentpart')
@section('content')
 
<div class="col-md-12">
	
<img src="images/studentIndex3.jpg">

</div>

@endsection