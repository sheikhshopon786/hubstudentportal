@extends('student.studentpart')
@section('content')

 
        
         
<!-- 
<div class="card-body"><h5 class="card-title">Class Routine</h5>


  <div class="mb-12 text-center">
    <div role="group" class="btn-group-sm nav btn-group">
      <a data-toggle="tab" href="#Saturday" class="btn-shadow  btn btn-primary"><b>Saturday</b></a>
      <a data-toggle="tab" href="#Sunday" class="btn-shadow  btn btn-primary"><b>Sunday</b></a>
      <a data-toggle="tab" href="#Monday" class="btn-shadow  btn btn-primary"><b>Monday</b></a>
      <a data-toggle="tab" href="#Tuesday" class="btn-shadow  btn btn-primary"><b>Tuesday</b></a>
      <a data-toggle="tab" href="#Wednesday" class="btn-shadow  btn btn-primary"><b>Wednesday</b></a>
      <a data-toggle="tab" href="#Thursday" class="btn-shadow  btn btn-primary"><b>Thursday</b></a>
      <a data-toggle="tab" href="#Friday" class="btn-shadow  btn btn-primary"><b>Friday</b></a>
    </div>
  </div>
-->


  <div class="card-header"  style="width: 100%;"><i class="header-icon lnr-license icon-gradient bg-plum-plate"> Class Routine </i> 
    <div class="btn-actions-pane-right">
      <div class="nav"  style="width: 100%;">
        
      <a data-toggle="tab" href="#Saturday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Saturday</b></a>

      <a data-toggle="tab" href="#Sunday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Sunday</b></a>

      <a data-toggle="tab" href="#Monday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Monday</b></a>

      <a data-toggle="tab" href="#Tuesday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Tuesday</b></a>

      <a data-toggle="tab" href="#Wednesday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Wednesday</b></a>

      <a data-toggle="tab" href="#Thursday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Thursday</b></a>

      <a data-toggle="tab" href="#Friday" class="btn-pill btn-wide  btn btn-outline-alternate btn-sm"><b>Friday</b></a>
      </div>
    </div>
  </div>






<div class="tab-content">
  <div class="tab-pane" id="Saturday" role="tabpanel">
      <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 20%; text-align: center;">Teacher's Name</th>
          <th style="width: 20%; text-align: center;">Time</th>
          <th style="width: 20%; text-align: center;">Room No</th>
        </tr>
        @foreach($one as $one)
        <tr>
            <td style="width: 20%;">{{$one->oneBatch}}</td>
            <td style="width: 20%;">{{$one->Saturday}}</td>
            <td style="width: 20%; text-align: center;">{{$one->oneTeacher}}</td>
            <td style="width: 20%; text-align: center;">{{$one->oneStartTime}}-{{$one->oneEndTime}}</td>
            <td style="width: 20%; text-align: center;">{{$one->oneRoom}}</td>
        </tr>
        @endforeach
      </table>
  </div>


  <div class="tab-pane" id="Sunday" role="tabpanel">
    <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
       @foreach($two as $two)
        <tr>
          <td style="width: 20%;">{{$two->twoBatch}}</td>
            <td style="width: 25%;">{{$two->Sunday}}</td>
            <td style="width: 25%; text-align: center;">{{$two->twoTeacher}}</td>
            <td style="width: 25%; text-align: center;">{{$two->twoStartTime}}-{{$two->twoEndTime}}</td>
            <td style="width: 25%; text-align: center;">{{$two->twoRoom}}</td>
        </tr>
        @endforeach
      </table>
  </div>

  <div class="tab-pane" id="Monday" role="tabpanel">
    <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
       @foreach($three as $three)
        <tr>
          <td style="width: 20%;">{{$three->threeBatch}}</td>
            <td style="width: 25%;">{{$three->Monday}}</td>
            <td style="width: 25%; text-align: center;">{{$three->threeTeacher}}</td>
            <td style="width: 25%; text-align: center;">{{$three->threeStartTime}}-{{$three->threeEndTime}}</td>
            <td style="width: 25%; text-align: center;">{{$three->threeRoom}}</td>
        </tr>
        @endforeach
      </table> 
  </div>

  <div class="tab-pane" id="Tuesday" role="tabpanel">
    <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
     @foreach($four as $four)
        <tr>
          <td style="width: 20%;">{{$four->fourBatch}}</td>
            <td style="width: 25%;">{{$four->Tuesday}}</td>
            <td style="width: 25%; text-align: center;">{{$four->fourTeacher}}</td>
            <td style="width: 25%; text-align: center;">{{$four->fourStartTime}}-{{$four->fourEndTime}}</td>
            <td style="width: 25%; text-align: center;">{{$four->fourRoom}}</td>
        </tr>
        @endforeach
      </table>
  </div>

  <div class="tab-pane" id="Wednesday" role="tabpanel">
      <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
    @foreach($five as $five)
        <tr>
          <td style="width: 20%;">{{$five->fiveBatch}}</td>
            <td style="width: 25%;">{{$five->Wednesday}}</td>
            <td style="width: 25%; text-align: center;">{{$five->fiveTeacher}}</td>
            <td style="width: 25%; text-align: center;">{{$five->fiveStartTime}}-{{$five->fiveEndTime}}</td>
            <td style="width: 25%; text-align: center;">{{$five->fiveRoom}}</td>
        </tr>
        @endforeach
      </table>
  </div>

  <div class="tab-pane" id="Thursday" role="tabpanel">
    <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
    @foreach($six as $six)
        <tr>
          <td style="width: 20%;">{{$six->sixBatch}}</td>
            <td style="width: 25%;">{{$six->Thursday}}</td>
            <td style="width: 25%; text-align: center;">{{$six->sixTeacher}}</td>
            <td style="width: 25%; text-align: center;">{{$six->sixStartTime}}-{{$six->sixEndTime}}</td>
            <td style="width: 25%; text-align: center;">{{$six->sixRoom}}</td>
        </tr>
        @endforeach
      </table>
  </div>

  <div class="tab-pane" id="Friday" role="tabpanel">
     <table border="1px solid" style="width: 100%; background-color: black; color: white;">
        <tr>
          <th>Batch/Semester</th>
          <th>Course Code & Ttile</th>
          <th style="width: 25%; text-align: center;">Teacher's Name</th>
          <th style="width: 25%; text-align: center;">Time</th>
          <th style="width: 25%; text-align: center;">Room No</th>
        </tr>
   @foreach($seven as $seven)
        <tr>
          <td style="width: 20%;">{{$seven->sevenBatch}}</td>
            <td style="width: 25%;">{{$seven->Friday}}</td>
            <td style="width: 25%; text-align: center;">{{$seven->sevenTeacher}}</td>
            <td style="width: 25%; text-align: center;">{{$seven->sevenStartTime}}-{{$seven->sevenEndTime}}</td>
            <td style="width: 25%; text-align: center;">{{$seven->sevenRoom}}</td>
        </tr>
        @endforeach
      </table>
  </div>





<div style="float: right;">
  <caption style="text-align: center;"><b>Teacher's Name List</b></caption>
<table border="1px">
  <tr>
    <th>Short Name</th>
    <th>Full Name</th>
  </tr>
@foreach($teachersname as $teachersname)
  <tr>
    <td>{{$teachersname->ShortName}}</td>
    <td>{{$teachersname->FullName}}</td>
  </tr>
@endforeach
</table>
</div>




</div>
 









@endsection