@extends('student.studentpart')
@section('content')
 
 
          <div class="col-12">
            <div class="card">
               
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 800px;">
            
         
  
      @foreach($studentProfile as $studentProfile)


        <div class="row" style="width: 100%; text-align: center;">
          <div class="col-md-12">
          
          <button class="btn btn-alternate" style="width: 100%;"><h4><b>Profile of {{$studentProfile->FirstName}}  {{$studentProfile->LastName}}</b></h4>
          </button>
        </div>
        </div><br>


        <div class="row" style="width: 100%; text-align: center;"> 

        <div class="col-md-3">
         <img src="{{url('/')}}/image/{{$studentProfile->image}}" style="width: 220px; height:260px; border-radius:10px;">  

         <a href="{{url('/proUpdateReq')}}" class="mm-active">
         <button class="mb-2 mr-2 btn btn-alternate btn-sm btn-block"><i class="metismenu-icon pe-7s-note"></i><b>EDIT PROFILE</b>
         </button></a>
       </div>


       <div class="col-md-9">
          



          <table class="table table-hover">
          <tbody>
           
            <tr>
              <td style="text-align: left;"><b>ID:</b></td>
              <td style="text-align: left;">{{$studentProfile->student_id}}</td>
            </tr>
            <tr>
               <td style="text-align: left;"><b>First Name:</b></td>
                <td style="text-align: left;">{{$studentProfile->FirstName}}</td>
            </tr>
            <tr>
                 <td style="text-align: left;"><b>Last Name:</b></td>
                <td style="text-align: left;">{{$studentProfile->LastName}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Batch:</b></td>
                <td style="text-align: left;">{{$studentProfile->Batch}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Gender:</b></td>
                <td style="text-align: left;">{{$studentProfile->Gender}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Religion:</b></td>
                <td style="text-align: left;">{{$studentProfile->Religion}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Blood Group:</b></td>
                <td style="text-align: left;">{{$studentProfile->BG}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Phone Number:</b></td>
                <td style="text-align: left;">{{$studentProfile->Phone}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Date of Birth:</b></td>
                <td style="text-align: left;">{{$studentProfile->DOB}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Email Address:</b></td>
                <td style="text-align: left;">{{$studentProfile->Email}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Department:</b></td>
                <td style="text-align: left;">{{$studentProfile->Department}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Faculty:</b></td>
                <td style="text-align: left;">{{$studentProfile->Faculty}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Father's Name:</b></td>
                <td style="text-align: left;">{{$studentProfile->FatherName}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Mother's Name:</b></td>
                <td style="text-align: left;">{{$studentProfile->MotherName}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Present Address:</b></td>
                <td style="text-align: left;">{{$studentProfile->PresentAddress}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Permanent Address:</b></td>
                <td style="text-align: left;">{{$studentProfile->ParmanentAddress}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Nationality:</b></td>
                <td style="text-align: left;">{{$studentProfile->Nationality}}</td>
              </tr>                 
       
          </tbody>
        </table>







        </div>   


        
      </div>                 
      @endforeach
 
   
 </div> <!-- /.card-body -->
</div><!-- /.card -->
</div>
<!-- /.row -->
@endsection 