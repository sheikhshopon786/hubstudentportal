@extends('student.studentpart')
@section('content')
 

 


<div class="card-body"><h4 class="" style="text-align: center;"><b>Semester Result</b></h4>


<form action="{{route('subjectRejultSearch')}}" method="post" 
    enctype="multipart/form-data">
    {{csrf_field()}}



<select value="semester" name="semester" id="semester"  style="width: 50%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Semester
            </option>
            @foreach($semester as $semester)

            <option value="{{$semester->semester}}">{{$semester->semester}}</option>
            
          @endforeach 
        </select>




    <button type="submit" class="btn btn-primary">Submit</button> 
</form>



    <br><br><br><br>
<caption style="text-align: center;"><h6><b>Semester Result</b></h6></caption>
  <table class="mb-0 table table-dark">

    <thead>
      <tr>
        <!--<th>Semester</th>-->
        <th style="text-align: left;">Course Code and Title</th>
        <th style="text-align: center;">Credit</th>
        <th style="text-align: center;">Letter Grade</th>
        <th style="text-align: center;">Grade Value</th>
               
      </tr>
    </thead>

    <tbody>
@foreach($subjectResult as $subjectResult)
      <tr>
        <td>{{$subjectResult->courseCodeTitile}}</td>
        <td style="text-align: center;">{{$subjectResult->credit_hour}}</td>
        <td style="text-align: center;">{{$subjectResult->Grade}}</td>
        <td style="text-align: center;">{{$subjectResult->GradePoint}}</td>
      </tr>
      @endforeach

      <tr>    
        @foreach($SGPA as $SGPA)
        <td style="text-align: center;"><b>Total SGPA:</b> {{$SGPA->GPA}}</td>
        @endforeach   
      </tr> 
    </tbody>

  </table>
 
  
</div>








































































 



@endsection