@extends('student.studentpart')
@section('content')
 
<div>
	<h1>Opps!!! Registration Time is Over</h1>
	<h4> Please Contact With Academic Office.</h4>
</div>

@endsection