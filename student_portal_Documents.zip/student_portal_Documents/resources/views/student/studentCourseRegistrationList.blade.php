@extends('student.studentpart')
@section('content')
 
<form action="{{url('studentCourseRegistrationList')}}" method="post" 
      enctype="multipart/form-data" role="form">
  {{csrf_field()}}
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Please Check Your Course List And Confirm Course Registration</h3>  

                 
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table class="mb-0 table table-dark">
         <thead>
            <tr> 

              
              <th scope="col">Course Code and Titile</th>
              <!--<th scope="col">Update</th> -->
              <th scope="col">Delete</th>       
            </tr>
   </thead>
    <tbody>
     @foreach($studentCourseRegistrationList as $studentCourseRegistrationList)
        <tr>
    
                        
           
          <td>{{$studentCourseRegistrationList->courseCodeTitile}}</td>
          <!--
           <td><a href="{{url('/courseEditReq',$studentCourseRegistrationList->Id)}}" class="btn btn-primary">Edit</a></td> -->

          <td><a href="{{url('/courseDelReq',$studentCourseRegistrationList->Id)}}" class="btn btn-danger">Delete</a></td>
        </tr>     
        </tr>                  
      @endforeach
    </tbody>
   </table>

    <button type="submit" value="submit" name="submit" class="btn btn-primary">Submit</button>
 </div> <!-- /.card-body -->
</div><!-- /.card -->
</div>

</form>
<!-- /.row -->
@endsection 