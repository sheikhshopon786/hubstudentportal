@extends('student.studentpart')
@section('content')
 

	
	<div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Your Registered Course List</h3>   

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table border="1px" class="table table-hover">
          
    <tbody>

     @foreach($courseListAfterReg as $courseListAfterReg)
        <div style="width: 100%; text-align: center;"> 

          
           <h3>
           {{$courseListAfterReg->courseCodeTitile}} 
          </h3>
           
                 
      </div>                 
      @endforeach
    </tbody>
   </table>
 </div> <!-- /.card-body -->
</div><!-- /.card -->
</div>
<!-- /.row -->


@endsection