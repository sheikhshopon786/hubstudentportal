 @extends('layout.master')
@section('content')

 
<h5><b>Insert Your Document</b></h5><br>

<form action="{{route('application')}}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 {{csrf_field()}}

<a href="{{url('#')}}" style="text-decoration: none;">
	<div role="group" class="btn-group-lg btn-group btn-group-toggle" >
		<button type="button" class="btn btn-alternate">Academic Office
		</button>	
	</div>
</a>
<br><br>


<div class="form-group row">
        <label for="AcademicOffice" class="col-sm-1 text-right control-label col-form-label"><b>Insert File</b></label>
        <div class="col-sm-9">
            <input type="file" class="form-control" id="AcademicOffice" placeholder="Academic Office" name="AcademicOffice" >
        </div>
</div>
<br><br>



<a href="{{url('#')}}" style="text-decoration: none;">
	<div role="group" class="btn-group-lg btn-group btn-group-toggle" >
		<button type="button" class="btn btn-alternate">Account's Office
		</button>	
	</div>
</a>
<br><br>

<div class="form-group row">
        <label for="AccountsOffice" class="col-sm-1 text-right control-label col-form-label"><b>Insert File</b></label>
        <div class="col-sm-9">
            <input type="file" class="form-control" id="Office" placeholder="Accounts Office" name="Office">
        </div>
</div>
<br><br>


<a href="{{url('#')}}" style="text-decoration: none;">
	<div role="group" class="btn-group-lg btn-group btn-group-toggle" >
		<button type="button" class="btn btn-alternate">Exam Controller
		</button>	
	</div>
</a>
<br><br>

<div class="form-group row">
        <label for="ExamController" class="col-sm-1 text-right control-label col-form-label"><b>Insert File</b></label>
        <div class="col-sm-9">
            <input type="file" class="form-control" id="ExamController" placeholder="Exam Controller" name="ExamController">
        </div>
</div>
<br>

<button type="submit" class="btn btn-primary">Submit</button>
</form>









@endsection