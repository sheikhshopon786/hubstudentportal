@extends('layout.master')
@section('content')

	
	<div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Sign In</h5><br>
            <form action="{{url('studentLogin')}}" method="post" 
      			enctype="multipart/form-data" role="form">
       				{{csrf_field()}}
              <div class="form-label-group">
                <input type="text" id="student_id" name="student_id" class="form-control" placeholder="Email address" required autofocus>
                <label for="student_id">Student ID</label>
              </div>

              <div class="form-label-group">
                <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                <label for="Password">Password</label>
              </div>

               

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Sign in</button>
              <br>
              <a href="{{url('/forgotPassword')}}" class="mm-active" style="text-decoration: none; color: black">
              <div for="forgotPassword">Forgot Password?</div></a>
               
        @if (Session('chklogin')!='0')
 			<p>
        	{{Session::get('chklogin')}}
        	</p>
    
		@endif
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>



@endsection

 

