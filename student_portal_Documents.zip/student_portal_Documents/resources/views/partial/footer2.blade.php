<!-- Start Footer-->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
	    <strong>Copyright &copy; 2019-2020 <a href="https://www.hamdarduniversity.edu.bd/">HUB</a></strong> 
	</div>
		All Rights Reserved @ Hamdard University Bangladesh
  </footer>
  <!-- End Footer-->