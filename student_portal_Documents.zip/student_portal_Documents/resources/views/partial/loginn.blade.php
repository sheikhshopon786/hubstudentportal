<form action="{{url('studentLogin')}}" method="post" 
      enctype="multipart/form-data" role="form">
       {{csrf_field()}}
  <div class="form-group row">
    <label for="student_id" class="col-sm-2 col-form-label">student_id</label>
    <div class="col-sm-10">
      <input type="student_id" class="form-control" id="student_id" name="student_id" placeholder="student_id">
    </div>
  </div>
  <div class="form-group row">
    <label for="password" class="col-sm-2 col-form-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="password" name="password" placeholder="password">
    </div>
  </div>
  
   
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Login in</button>
    </div>
  </div>



  @if (Session::has('chklogin'))
 <p>
        	{{Session::get('chklogin')}}
        </p>
    
@endif
</form>