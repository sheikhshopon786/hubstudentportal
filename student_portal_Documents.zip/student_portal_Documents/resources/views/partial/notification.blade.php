@extends('layout.master')
@section('content')




	<div role="group" class="btn-group-lg btn-group btn-group-toggle">
             <label class="btn btn-focus">
                 Academic Clearance is Successful
            </label>
    </div> <br> <br>


<!--
Notification Page
 <table>
 	<tr>
 		<td>Academic Clearance is Successful</td>
 	</tr>
 </table>-->




@endsection