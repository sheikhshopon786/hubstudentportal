@extends('layout.Master')
@section('content')
      <div class="col-md-9" >
          <div class="widget" srt>
          	
            <h3>Product List</h3>
          	<div >
              <div class="row">

                    

                    <table class="table table-hover">
    <thead>
      <tr>
        <th>Edit</th>
        <th>ID</th>
        <th>Tittle</th>
        <th>Description</th>
        <th>Delete</th>

      </tr>
    </thead>
    <tbody>
      @foreach($data as $data)
      <tr>
        <td><a href="{{url('/editreq',$data->Id)}}" class="btn btn-primary">Edit</a></td>
         
        <td>{{$data->Id}}</td>
        <td>{{$data->Tittle}}</td>
        <td>{{$data->Description}}</td>
         <td><a href="{{url('/delreq',$data->Id)}}" class="btn btn-danger">Delete</a></td>
        
      </tr>
      @endforeach
     
    </tbody>
  </table>

                    
                 
                    




              </div>
              </div>
            </div>
      </div>
@endsection