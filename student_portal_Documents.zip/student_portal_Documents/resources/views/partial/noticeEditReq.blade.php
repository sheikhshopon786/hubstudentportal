 @extends('layout.master')
 @section('content')
 
 
<div class="row">

<div class="col-md-9" style="text-align: center;">

  <div class="card-body table-responsive p-0" style="height: 550px;">

    <form action="/routineeditsv" method="post" enctype="multipart/form-data" >
        {{csrf_field()}}
      @foreach($studentInformationList as $studentInformationList)
  
	 <div class="" style="" >
 			<div class="uppercase" style="background-color:; color: #000">
				<h2><b class="">{{$studentInformationList->Title}}</b></h2>
        <br>
        <img src="{{url('/')}}/image/{{$studentInformationList->image}}" style="width: 80%;">
			</div>
 

      <div>
          <p><b>{{$studentInformationList->Description}}</b></p>
      </div>

		<ul class="list-inline">
          <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> {{$studentInformationList->Day}}</li>

          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> {{$studentInformationList->StartingTime}} - {{$studentInformationList->EndingTime}}</li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> {{$studentInformationList->Location}}</li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i>Category- {{$studentInformationList->Category}}</li>
        </ul> 
	   </div>

    @endforeach
  </form>
</div>


</div>



  











 <div class="col-md-3">
               
              <div role="group" class="btn-group-lg btn-group btn-group-toggle" data-toggle="buttons" style="width: 100%;">
      <button type="button" class="btn btn-alternate"><b>Recent Notice</b>
      </button>
    </div>


    <!-- /.card-header -->
   <div class="card-body table-responsive p-0" style="height: 550px;">
      <table class="mb-0 table table-dark">
         
      @foreach($recentNotice as $recentNotice)
          <tbody>
              <tr>
                  
       <a href="{{url('/noticeeditreq',$recentNotice->ID)}}" style="text-decoration: none; float: right;" >
        <div role="group" class="btn-group-lg btn-group btn-group-toggle">
             <label class="btn btn-focus">
                 <h6>{{$recentNotice->Title}}</h6>
            </label>
        </div>
      </a>
       
              </tr>                      
          </tbody>
      @endforeach
      </table>

    
 </div>  
 
</div>






















</div>
  
  


 @endsection