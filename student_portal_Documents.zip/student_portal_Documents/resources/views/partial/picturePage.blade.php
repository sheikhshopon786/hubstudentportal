@foreach($data as $data)
<table>
     <tr>
     	
    	<td><img src="{{url('/')}}/image/{{$data->image}}"></td>
    </tr>
    </table>
@endforeach