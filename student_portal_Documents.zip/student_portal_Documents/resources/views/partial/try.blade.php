
App\Exceptions\Handler

try { 
        
$studentInformationInsert = DB::insert('insert into admission (student_id,FirstName,LastName,PresentAddress,ParmanentAddress,MotherName,FatherName,Phone,Email,Department,Batch,DOB,BG,Religion,Nationality,image,password) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,md5(?))',[$request->student_id,$request->FirstName,$request->LastName,$request->PresentAddress,$request->ParmanentAddress,$request->MotherName,$request->FatherName,$request->Phone,$request->Email,$request->Department,$request->Batch,$request->DOB,$request->BG,$request->Religion,$request->Nationality,$request->image,$request->password]);
           


    } catch (Exception $e) {

session ='please use other id'
        
    }