@extends('student.studentpart')
@section('content')
 
 




    <div class="row">
      <div class="col-2">
@foreach($Notice as $Notice)
        <h1 class="display-4"><span class="badge badge-secondary">{{$Notice->Date}}</span></h1>
       
      </div>
    </div>


    <div class="row">
      <div class="col-md-12">
    <h3 class="text-uppercase"><strong>{{$Notice->Title}}</strong></h3>
 
      <a href="noticeDetails/{{$Notice->ID}}" class="btn btn-primary">Read More <i class="fa fa-arrow-circle-right"> </i></a>
      </div>
    </div>




    <div class="row">
       <div class="col-7">
        <ul class="list-inline">
          <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> {{$Notice->Day}}</li>

          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> {{$Notice->StartingTime}} - {{$Notice->EndingTime}}</li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> {{$Notice->Location}}</li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i>Category- {{$Notice->Category}}</li>
        </ul> 
@endforeach
         
      </div>
    </div>



 
      

   

   
 


   
 
 
@endsection

