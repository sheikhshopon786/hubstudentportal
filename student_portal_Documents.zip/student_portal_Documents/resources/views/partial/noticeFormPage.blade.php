@extends('academic.academicOffice')
@section('content')
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Notice</b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
              <form action="{{route('NoticeForm')}}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 {{csrf_field()}}
 {{session('msg')}}
                <div class="card-body">

                  <div class="form-group"> 
              <label for="Date">Date</label>
              <input type="date" class="form-control" id="Date" placeholder="Date" name="Date"  required="">   
                  </div>
<!--
                  <div class="form-group">
              <label for="Month">Month</label>
              <input type="month" class="form-control" id="Month" placeholder="Month" name="Month" required="">
                  </div>-->

                  <div class="form-group">
                    <label for="Title">Title</label>           
              <input type="text" class="form-control" id="Title" placeholder=" Title" name="Title" required="">
                  </div>

                  <div class="form-group">
                    <label for="Description">Description</label>
              <input type="text" class="form-control" id="Description" placeholder=" Description" name="Description">
                  </div>

                  <div class="form-group">
                    <label for="image">image</label>
              <input type="file" class="form-control" id="image" placeholder=" Description" name="image">
                  </div>

                  
                  <div class="form-group">
                    <label for="Day">Day</label>
              <input type="weekday" class="form-control" id="Day" placeholder="Day" name="Day">
              </div>



			<div class="form-group"> 
              <label for="StartingTime">Starting Time</label>
              <input type="time" class="form-control" id="StartingTime" placeholder="StartingTime" name="StartingTime">   
            </div>

                  <div class="form-group"> 
              <label for="EndingTime">Ending Time</label>
              <input type="time" class="form-control" id="EndingTime" placeholder="EndingTime" name="EndingTime">   
                  </div>

          
                  <div class="form-group">
              <label for="Location">Location</label>
              <input type="text" class="form-control" id="Location" placeholder="Location" name="Location" required="">
                  </div>

                  <div class="form-group">
                    <label for="Category">Category</label>
              <input type="text" class="form-control" id="Category" placeholder=" Category" name="Category" required="">
                  </div>

               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->

@endsection