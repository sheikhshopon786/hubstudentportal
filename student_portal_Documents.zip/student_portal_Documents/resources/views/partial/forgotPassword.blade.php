@extends('layout.master')
@section('content')

	
	<div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Forgort Password</h5><br>

            <form action="{{url('/fgp')}}" method="post" 
      			enctype="multipart/form-data" role="form">
       				{{csrf_field()}}
              <div class="form-label-group">
              	<label for="Email">Please Insert Your User ID</label>
                <input type="text" id="uid" name="uid" class="form-control" placeholder="User ID" required autofocus>
              </div><br>


                

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Submit</button>
               
   
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>



@endsection

 

