
@extends('academic.academicOffice')
@section('content')
      
   

	<div class="col-md-12" >
          <div class="widget" style="margin-left: 10px;">
            
            <h3>Student Profile Update</h3>
            <div >
              <div class="row"> 

                    
      <form action="/editsv" method="post" enctype="multipart/form-data" >
        {{csrf_field()}}

  

 @foreach($studentInformationList as $studentInformationList)
 <div class="form-group">
    <label for="student_id">Student ID</label>
    <input type="text" class="form-control" id="student_id" placeholder="student_id" name="student_id" readonly value="{{$studentInformationList->student_id}}">
  </div>
  <div class="form-group">
    <label for="FirstName">First Name</label>
    <input type="text" class="form-control" id="FirstName" placeholder="First Name" name="FirstName" value="{{$studentInformationList->FirstName}}">
  </div>

  <div class="form-group">
    <label for="LastName">Last Name</label>
    <input type="text" class="form-control" id="LastName" placeholder="Last Name" name="LastName" value="{{$studentInformationList->LastName}}">
  </div>

  <div class="form-group">
    <label for="PresentAddress">Present Address</label>
    <input type="text" class="form-control" id="PresentAddress" placeholder="Present Address" name="PresentAddress" value="{{$studentInformationList->PresentAddress}}">
  </div>

  <div class="form-group">
    <label for="ParmanentAddress"> Parmanent Address</label>
    <input type="text" class="form-control" id="ParmanentAddress" placeholder=" Parmanent Address" name="ParmanentAddress" value="{{$studentInformationList->ParmanentAddress}}">
  </div>

  <div class="form-group">
    <label for="FatherName">Father Name </label>
    <input type="text" class="form-control" id="FatherName" placeholder=" Father Name" name="FatherName" value="{{$studentInformationList->FatherName}}">
  </div>

  <div class="form-group">
    <label for="MotherName"> Mother Name</label>
    <input type="text" class="form-control" id="MotherName" placeholder=" Mother Name" name="MotherName" value="{{$studentInformationList->MotherName}}">
  </div>

  <div class="form-group">
    <label for="Phone"> Phone</label>
    <input type="text" class="form-control" id="Phone" placeholder=" Phone" name="Phone" value="{{$studentInformationList->Phone}}">
  </div>

  <div class="form-group">
    <label for="Email">Email </label>
    <input type="text" class="form-control" id="Email" placeholder=" Email" name="Email" value="{{$studentInformationList->Email}}">
  </div>

<div class="form-group">
    <label for="Department">Department </label>
    <input type="text" class="form-control" id="Department" placeholder=" Department" name="Department" value="{{$studentInformationList->Department}}">
  </div>


<div class="form-group">
    <label for="Batch">Batch </label>
    <input type="text" class="form-control" id="Batch" placeholder=" Batch" name="Batch" value="{{$studentInformationList->Batch}}">
  </div>

<div class="form-group">
    <label for="DOB">DOB </label>
    <input type="text" class="form-control" id="DOB" placeholder=" DOB" name="DOB" value="{{$studentInformationList->DOB}}">
  </div>

  <div class="form-group">
    <label for="BG">BG </label>
    <input type="text" class="form-control" id="BG" placeholder=" BG" name="BG" value="{{$studentInformationList->BG}}">
  </div>

<div class="form-group">
    <label for="Religion">Religion </label>
    <input type="text" class="form-control" id="Religion" placeholder=" Religion" name="Religion" value="{{$studentInformationList->Religion}}">
  </div>

  <div class="form-group">
    <label for="Nationality">Nationality </label>
    <input type="text" class="form-control" id="Nationality" placeholder=" Nationality" name="Nationality" value="{{$studentInformationList->Nationality}}">
  </div>

   <div class="form-group">
    <label for="image">Image</label>
    <input type="file" class="form-control" id="image" placeholder="Image" name="image" value="{{$studentInformationList->image}}">
  </div>

    <div class="form-group">
    <label for="password">Password </label>
    <input type="text" class="form-control" id="password" placeholder=" password" name="password" value="{{$studentInformationList->password}}">
  </div>
 

  <button type="submit" class="btn btn-primary">Save</button>

   @endforeach
</form>


		
@endsection		
