@extends('layout.master')
@section('content')


<!--Slider Start-->
   


<div class="col-md-12">
<div class="main-card mb-3 card">
<div class="card-body">
<div id="carouselExampleControls2" class="carousel slide carousel-fade" data-ride="carousel">
<div class="carousel-inner">
<div class="carousel-item active">
<img class="d-block w-100" src="images/slider1.jpg" alt="First slide">
<div class="carousel-caption d-none d-md-block" style="color:#000;"><!--
<h2><b>Present View</b></h2>
<h4><b>Hamdard University Bangladesh Present View</b></h4>-->
</div>
</div>
<div class="carousel-item">
<img class="d-block w-100" src="images/slider5.jpg" alt="Second slide">
<div class="carousel-caption d-none d-md-block" style="color: #000;"><!--
<h2><b>Future Plan</b></h2>
<h4><b>Hamdard University Bangladesh Future Plan</b></h4>-->
</div>
</div>
<!--
<div class="carousel-item">
<img class="d-block w-100" src="images/slider6.jpg" alt="Third slide">
<div class="carousel-caption d-none d-md-block" style="color: #000;">

<h2><b>Fresher’s Reception Fall 2019</b></h2>

<h4><b>On 16 November 2019 Hamdard University Bangladesh organized Freshers’ Reception.</b></h4>

</div>
</div>-->

</div>
<a class="carousel-control-prev" href="#carouselExampleControls2" role="button" data-slide="prev">
<span class="carousel-control-prev-icon" aria-hidden="true"></span>
<span class="sr-only">Previous</span>
</a>
<a class="carousel-control-next" href="#carouselExampleControls2" role="button" data-slide="next">
<span class="carousel-control-next-icon" aria-hidden="true"></span>
<span class="sr-only">Next</span>
</a>
</div>
</div>
</div>
</div>

<!--Slider End-->

<!--Marquee Start-->
 
	
  
<div class="col-md-12">

      <marquee style="background: #16191f; color: white;">
           @foreach($Notice1 as $Notice1)

          <b>Latest Notice-</b> {{$Notice1->Title}}

            @endforeach

      </marquee>
      
</div>
<!--Marquee End-->






@endsection
 