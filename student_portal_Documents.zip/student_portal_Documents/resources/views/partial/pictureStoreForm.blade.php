@extends('layout.master')
@section('content')


Notification

<form action="{{route('pictureStoreForm')}}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 {{csrf_field()}}

<a href="{{url('#')}}" style="text-decoration: none;">
	<div role="group" class="btn-group-lg btn-group btn-group-toggle" >
		<button type="button" class="btn btn-alternate">Academic Office
		</button>	
	</div>
</a>
<br><br>


<div class="form-group row">
        <label for="image" class="col-sm-1 text-right control-label col-form-label"><b>Insert File</b></label>
        <div class="col-sm-9">
            <input type="file" class="form-control" id="image" placeholder="Academic Office" name="image" >
        </div>
</div>
<br><br>
 

 

<button type="submit" class="btn btn-primary">Submit</button>
</form>








@endsection