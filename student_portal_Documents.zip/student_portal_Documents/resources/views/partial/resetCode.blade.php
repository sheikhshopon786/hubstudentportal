 @extends('layout.master')
@section('content')

	 
	<div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Reset Code</h5><br>
            <form action="{{url('/rc')}}" method="post" 
      			enctype="multipart/form-data" role="form">
       				{{csrf_field()}}
              <div class="form-label-group">
                <input type="text" id="rc" name="rc" class="form-control" placeholder="Enter your code" required autofocus><br>
              </div>      

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Submit</button>  
            </form>

            
               <a href="" style="text-decoration:none;"><label for="EmailCode">Send Code Again?</label></a>
                
          </div>
        </div>
      </div>
    </div>
  </div>



@endsection

 

