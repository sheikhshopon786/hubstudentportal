 @extends('layout.master')
 @section('content')
 




    <div class="row">
      <div class="col-2">
@foreach($studentInformationList as $studentInformationList)
        <h1 class="display-4"><span class="badge badge-secondary">{{$studentInformationList->Date}}</span></h1>
       
      </div>
    </div>



    <div class="row">
      <div class="col-md-12">
        <a href="{{url('/noticeeditreq',$studentInformationList->ID)}}" class="" style="text-decoration: none; color:#615f5b ">
          <h3 class=""><strong>{{$studentInformationList->Title}}</strong></h3>
        </a>
        <a href="{{url('/noticeeditreq',$studentInformationList->ID)}}" class="" style="text-decoration: none; color: #615f5b;"><b>Read More</b><i class="fa fa-arrow-circle-right"> </i></a>

        
      </div>
    </div>




    <div class="row">
       <div class="col-7">
        <ul class="list-inline">
          <li class="list-inline-item"><i class="fa fa-calendar-o" aria-hidden="true"></i> {{$studentInformationList->Day}}</li>

          <li class="list-inline-item"><i class="fa fa-clock-o" aria-hidden="true"></i> {{$studentInformationList->StartingTime}} - {{$studentInformationList->EndingTime}}</li>

          <li class="list-inline-item"><i class="fa fa-location-arrow" aria-hidden="true"></i> {{$studentInformationList->Location}}</li>

          <li class="list-inline-item"><i class="pe-7s-news-paper" aria-hidden="true"></i>Category- {{$studentInformationList->Category}}</li>
        </ul> 
@endforeach
         
      </div>
    </div>



 
      

   

   
 


   
 
 
@endsection

