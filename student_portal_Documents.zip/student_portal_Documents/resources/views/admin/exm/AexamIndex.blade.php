@extends('admin.exm.AexamOffice')
@section('content')

<div class="col-md-12">
	<img src="images/examIndexPic.jpg">
</div>


@endsection