@extends('admin.exm.AexamOffice')
@section('content')




<div class="card-body"><h5 class="card-title">Student Results:</h5>




 <form action="{{route('SSRsearch')}}" method="post" 
      enctype="multipart/form-data">
       {{csrf_field()}}
              <label for="" class="sr-only">ID</label>
               <input type="text" class="form-control" id="SSRsearch" placeholder="Enter Student ID" name="SSRsearch">

              <button type="submit" class="btn btn-primary">Submit</button>             
        </form>








<table class="mb-0 table table-dark">
   
  <thead>
    <tr>
        <th scope="col">Student ID</th>
      <th scope="col">Course Code And Ttile</th>
      <th scope="col"style="text-align: center;">Credit</th>
      <th scope="col"style="text-align: center;">Grade</th>
      <th scope="col"style="text-align: center;">GradePoint</th>
    
    </tr>
  </thead>
  <tbody>
   @foreach($studentResult as $studentResult)
      <tr>
      <td>{{$studentResult->student_id}}</td>
      <td>{{$studentResult->CourseCodeTitle}}</td>
      <td style="text-align: center;">{{$studentResult->Credit}}</td>
      <td style="text-align: center;">{{$studentResult->Grade}}</td>
      <td style="text-align: center;">{{$studentResult->GradePoint}}</td>
      
      
     
    </tr>
           
        @endforeach
  
    
  </tbody>
</table>






@endsection