@extends('admin.admin')
@section('content')


  
  <div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">User Registration</h5><br>
            <form action="{{url('SregisterFormEntry')}}" method="post" 
            enctype="multipart/form-data" role="form">
              {{csrf_field()}}
              


          <select value="type" name="type" id="type"      style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Position
              </option>
              <option value="Super Admin">
                Super Admin
              </option>
              <option value="Academic Office">
                Academic Office
              </option>
              <option value="Accounts Office">
                Accounts Office
              </option>
               <option value="Exam Controller">
                Exam Controller
              </option>
           </select>

            <div class="form-label-group">
                <input type="text" id="userID" name="email" class="form-control" placeholder="Email Address" required autofocus>
                <label for="email">Email Address</label>
              </div>


              <div class="form-label-group">
                <input type="text" id="userID" name="userID" class="form-control" placeholder="User ID" required autofocus>
                <label for="userID">User ID</label>
              </div>

              <div class="form-label-group">
                <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                <label for="Password">Password</label>
              </div>

               

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Sign in</button>
            
              
   

      
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>



@endsection

 

