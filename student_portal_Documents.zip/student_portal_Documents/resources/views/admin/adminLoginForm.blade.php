@extends('admin.admin')
@section('content')


	
	<div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Sign In</h5><br>
            <form action="{{url('adminLogin')}}" method="post" 
      			enctype="multipart/form-data" role="form">
       				{{csrf_field()}}
              


              <div class="form-label-group">
                <input type="text" id="userID" name="userID" class="form-control" placeholder="User ID" required autofocus>
                <label for="userID">User ID</label>
              </div>

              <div class="form-label-group">
                <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                <label for="Password">Password</label>
              </div>

               

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Sign in</button>
            
              
   

     @if (Session('userchklogin')!='0')
      <p>
          {{Session::get('userchklogin')}}
          </p>
    
    @endif
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>



@endsection

 

