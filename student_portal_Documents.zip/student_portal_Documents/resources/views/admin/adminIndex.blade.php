@extends('admin.admin')
@section('content')



<a href="{{url('/SacademicOffice')}}" style="text-decoration: none;" >
    <div class="row">
        <div class="col-lg-12 col-xl-3">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading">
                        </div>  
                    </div>

                    <div class="widget-content-left">
                        <div class="widget-numbers text-warning"><span>Academic Office</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</a>


 <a href="{{url('/SaccountOffice')}}" style="text-decoration: none;" >
    <div class="row">
        <div class="col-lg-12 col-xl-3">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading">
                        </div>  
                    </div>

                    <div class="widget-content-left">
                        <div class="widget-numbers text-warning"><span>Account Office</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</a>


<a href="{{url('/AexamOffice')}}" style="text-decoration: none;" >
    <div class="row">
        <div class="col-lg-12 col-xl-3">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading">
                        </div>  
                    </div>

                    <div class="widget-content-left">
                        <div class="widget-numbers text-warning"><span>Exam Controller</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</a>


<a href="{{url('SstudentPart')}}" style="text-decoration: none;" >
    <div class="row">
        <div class="col-lg-12 col-xl-3">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading">
                        </div>  
                    </div>

                    <div class="widget-content-left">
                        <div class="widget-numbers text-warning"><span>Student Profile</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</a>






@endsection