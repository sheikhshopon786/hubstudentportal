@extends('admin.std.SstudentPart')
@section('content')

<div class="col-lg-12">
        
          <h3 class="card-title">All Students</h3>
            <div class="card-tools">
              <form action="{{route('SstdSearch')}}" method="post" 
                  enctype="multipart/form-data">
                  {{csrf_field()}}
                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="SstdSearch" placeholder="Enter Student ID" name="SstdSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 
                 
  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">All Students</h5>
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Gender</th>
              <th>Present Address</th>
              <th>Parmanant Address</th>
              <th>Father's Name</th>
              <th>Mother's Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Program</th>
              <th>Faculty</th>
              <th>Batch</th>
              <th>Date of Birth</th>
              <th>Blood Group</th>
              <th>Religion</th>
              <th>Nationality</th>
              <th>Update</th> 
              <th>Delete</th> 
              <th>Clearance</th>
              <th>Clearance</th>
            </tr>
          </thead>
          <tbody>
             
           @foreach($studentInformationList as $studentInformationList)
        <tr>
    
                        
          <td>{{$studentInformationList->student_id}}</td>
          <td>{{$studentInformationList->FirstName}}</td>
          <td>{{$studentInformationList->LastName}}</td>
          <td>{{$studentInformationList->Gender}}</td>
          <td>{{$studentInformationList->PresentAddress}}</td>
          <td>{{$studentInformationList->ParmanentAddress}}</td>
          <td>{{$studentInformationList->MotherName}}</td>
          <td>{{$studentInformationList->FatherName}}</td>
          <td>{{$studentInformationList->Phone}}</td>
          <td>{{$studentInformationList->Email}}</td>
          <td>{{$studentInformationList->Department}}</td>
          <td>{{$studentInformationList->Faculty}}</td>
          <td>{{$studentInformationList->Batch}}</td>
          <td>{{$studentInformationList->DOB}}</td>
          <td>{{$studentInformationList->BG}}</td>
          <td>{{$studentInformationList->Religion}}</td>
          <td>{{$studentInformationList->Nationality}}</td>
           
           
        </tr>                  
      @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



@endsection 