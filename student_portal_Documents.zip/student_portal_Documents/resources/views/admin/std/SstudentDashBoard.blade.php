@extends('admin.std.SstudentPart')
@section('content')




 

  
  <div class="col-md-12" style="text-align:center; 
    background: ; color: white; padding: 20px;">
 
              <button type="button" class="btn btn-secondary btn-lg btn-block"><b>Type To Search To Get Student Information</b> </button>


        <form action="{{route('stdsearch')}}" method="post" 
      enctype="multipart/form-data">
       {{csrf_field()}}
              <label for="" class="sr-only">ID</label>
               <input type="text" class="form-control" id="stdsearch" placeholder="Enter Student ID" name="stdsearch">

              <button type="submit" class="btn btn-primary" style="width: 100%"><b>Submit</b></button> 
        </form>










<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Student Details</b></h4></caption>

 

     

    
  @foreach($studentInfo as $studentInfo) 
  <div class="row">

    <div class="col-md-3"> 
       <img src="{{url('/')}}/image/{{$studentInfo->image}}" style="width: 90%; height:40%; border-radius:10px;">  
    </div>

    <div class="col-md-9">
    <table class="table table-hover table-dark">
          <tbody>
           
            <tr>
              <td style="text-align: left;"><b>ID:</b></td>
              <td style="text-align: left;">{{$studentInfo->student_id}}</td>
            </tr>
            <tr>
               <td style="text-align: left;"><b>First Name:</b></td>
                <td style="text-align: left;">{{$studentInfo->FirstName}}</td>
            </tr>
            <tr>
                 <td style="text-align: left;"><b>Last Name:</b></td>
                <td style="text-align: left;">{{$studentInfo->LastName}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Batch:</b></td>
                <td style="text-align: left;">{{$studentInfo->Batch}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Gender:</b></td>
                <td style="text-align: left;">{{$studentInfo->Gender}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Religion:</b></td>
                <td style="text-align: left;">{{$studentInfo->Religion}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Blood Group:</b></td>
                <td style="text-align: left;">{{$studentInfo->BG}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Phone Number:</b></td>
                <td style="text-align: left;">{{$studentInfo->Phone}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Date of Birth:</b></td>
                <td style="text-align: left;">{{$studentInfo->DOB}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Email Address:</b></td>
                <td style="text-align: left;">{{$studentInfo->Email}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Department:</b></td>
                <td style="text-align: left;">{{$studentInfo->Department}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Faculty:</b></td>
                <td style="text-align: left;">{{$studentInfo->Faculty}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Father's Name:</b></td>
                <td style="text-align: left;">{{$studentInfo->FatherName}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Mother's Name:</b></td>
                <td style="text-align: left;">{{$studentInfo->MotherName}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Present Address:</b></td>
                <td style="text-align: left;">{{$studentInfo->PresentAddress}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Permanent Address:</b></td>
                <td style="text-align: left;">{{$studentInfo->ParmanentAddress}}</td>
              </tr>
              <tr>
                 <td style="text-align: left;"><b>Nationality:</b></td>
                <td style="text-align: left;">{{$studentInfo->Nationality}}</td>
              </tr>                 
       
          </tbody>
        </table>
      </div>

</div>

 @endforeach
  
</div>
<br><br><br>









<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Payment Scheme</b></h4></caption>

 <table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">Fee Type</th>
      <th scope="col">Amount</th>
      <th scope="col">Payment Type</th>
      <th scope="col">Payment Amount</th>
    </tr>
  </thead>
  <tbody>
    @foreach($paymentscheme as $paymentscheme) 
      <tr>
      <td>{{$paymentscheme->FeeType}}</td>
      <td>{{$paymentscheme->Amount}}</td>
      <td>{{$paymentscheme->PaymentType}}</td>
      <td>{{$paymentscheme->PaymentAmount}}</td>
          
    </tr>       
        @endforeach  
  </tbody>
</table>
<br><br><br>




<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Semestr Wise GPA</b></h4></caption>
 <table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">Semester</th>
      <th scope="col">SGPA</th>
    </tr>
  </thead>
  <tbody>
    @foreach($resultscheme as $resultscheme) 
      <tr>
      <td>{{$resultscheme->Semester}}</td>
      <td>{{$resultscheme->SGPA}}</td>    
    </tr>       
        @endforeach  
  </tbody>
</table>
</div>
</div>
<br><br><br>





<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Subject Wise Grade</b></h4></caption>
 <table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">Course Code And Title</th>
      <th scope="col">Credit</th>
      <th scope="col">Grade</th>
      <th scope="col">Grade Point</th>
    </tr>
  </thead>
  <tbody>
    @foreach($studentresult as $studentresult) 
      <tr>
      <td>{{$studentresult->CourseCodeTitle}}</td>
      <td>{{$studentresult->Credit}}</td>
      <td>{{$studentresult->Grade}}</td>    
      <td>{{$studentresult->GradePoint}}</td>
    </tr>       
        @endforeach  
  </tbody>
</table>
</div>
<br><br><br>



<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h4><b style="color:black;" class="card-title">Complete Course</b></h4></caption>
 <table class="table table-hover table-dark">
  <thead>
    <tr>
      <th scope="col">Course Code And Title</th>
    </tr>
  </thead>
  <tbody>
    @foreach($completecourse as $completecourse) 
      <tr>
      <td style="text-align: center;">{{$completecourse->courseCodeTitile}}</td>
       
    </tr>       
        @endforeach  
  </tbody>
</table>
</div>
<br><br><br>






















</div>
@endsection