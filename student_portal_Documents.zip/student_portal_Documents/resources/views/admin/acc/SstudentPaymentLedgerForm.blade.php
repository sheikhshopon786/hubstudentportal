@extends('admin.acc.SaccountOffice')
@section('content')
<!--Student Information form start -->

<!--Student Information form End -->  
<body>
<form action="{{route('SstudentPaymentLedgerStore')}}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 {{csrf_field()}}
<b>{{session('msg')}}</b>
  

 <div class="card-body">
    <h4 class="card-title">Student Payment Ledger Form</h4>
    <div class="form-group row">
        <label for="student_id" class="col-sm-3 text-right control-label col-form-label">Student ID</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="student_id" placeholder=" Student ID" name="student_id" required="">
        </div>
    </div>

<select value="FeeType" name="FeeType" id="FeeType" style="width: 100%; float: right; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Fee Type
              </option>
              <option value="Admission Fee">
                Admission Fee
              </option>
              <option value="Semester Fee">
                Semester Fee
              </option>
              <option value="Tuition Fee">
                Tuition Fee
              </option>
              <option value="Repeat Exam Fee">
                Repeat Exam Fee
              </option>
              <option value="Late Fine">
                Late Fine
              </option>
              <option value="Attendence Fine">
                Attendence Fine
              </option>
 </select>


    <div class="form-group row">
        <label for="Amount" class="col-sm-3 text-right control-label col-form-label">Amount</label>
        <div class="col-sm-9">
            <input type="number" class="form-control" id="Amount" placeholder="Amount" name="Amount" required="">
        </div>
    </div>

  <select value="PaymentType" name="PaymentType" id="PaymentType" style="width: 100%; float: right; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Payment Type
              </option>
              <option value="Total Payable">
                Total Payable
              </option>
              <option value="Waiver">
                Waiver
              </option>
              <option value="Previous Due">
                Previous Due
              </option>
              <option value="Previous Advanced">
                Previous Advanced
              </option>
              <option value="Net Payable">
                Net Payable
              </option>
              <option value="Total PaidPaymentType">
                Total Paid 
              </option>
              <option value="Total Due">
                Total Due
              </option>
 </select>

    <div class="form-group row">
        <label for="PresentAddress" class="col-sm-3 text-right control-label col-form-label">Payment Amount</label>
        <div class="col-sm-9">
         <input type="text" class="form-control" id="PaymentAmount" placeholder=" Payment Amount" name="PaymentAmount" required="">
      </div>
    </div>

<div class="border-top">
    <div class="card-body" class="alert alert-success">
        <button type="submit" id="btn" name="btn" value="btn" class="btn btn-primary">Submit</button>
        
         
    </div>

</div>
    
</form>
</body>


@endsection

