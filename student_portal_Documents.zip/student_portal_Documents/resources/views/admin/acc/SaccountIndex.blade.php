@extends('admin.acc.SaccountOffice')
@section('content')

<div class="col-md-12">
	<img src="images/accountIndexPic.jpg">
</div>






@endsection