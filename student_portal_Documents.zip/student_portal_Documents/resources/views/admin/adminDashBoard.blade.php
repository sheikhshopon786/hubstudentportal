@extends('admin.admin')
@section('content')


<div class="col-md-12">
	<img src="images/superAdminIndexPic.jpg">
</div>

 








@endsection