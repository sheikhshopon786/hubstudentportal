@extends('admin.aca.SacademicOffice')
@section('content')
 
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">CSE Course List</h3>  

                 
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table class="table table-hover">
         <thead>
            <tr>
             
              <th scope="col">Semester</th>
               
              <th scope="col">Course Code & Title</th>
              <th scope="col">Section</th>
              <th scope="col">Credit Hour</th> 
              <th scope="col">Department</th>
              <th scope="col">Teacher's Name</th>
              <th scope="col">Day</th>
              <th scope="col">Time</th>
              <th scope="col">Room No</th>     
            </tr>
          </thead>

          <tbody>
            @foreach($data as $data)
            <tr>
              <td>{{$data->semester}}</td>
              <td>{{$data->courseCodeTitile}}</td>
              
              <td>{{$data->section}}</td>
              <td>{{$data->credit_hour}}</td>
              <td>{{$data->department}}</td>
              <td>{{$data->teacher_name}}</td>
              <td>{{$data->day}}</td>
              <td>{{$data->starting_time}} - {{$data->ending_time}}</td>
              <td>{{$data->room_no}}</td>
            </tr>                  
          @endforeach
          </tbody>
        </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
     
        <!-- /.row -->

@endsection