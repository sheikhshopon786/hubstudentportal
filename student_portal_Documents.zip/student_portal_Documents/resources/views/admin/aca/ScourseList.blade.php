@extends('admin.aca.SacademicOffice')
@section('content')
 
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Course List</h3>  

             
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table class="table table-hover">
         <thead>
            <tr>
              <th scope="col">Semester</th>
              <th scope="col">Course Code & Title</th>
              <th scope="col">Section</th>
              <th scope="col">Credit Hour</th>      
            </tr>
          </thead>

          <tbody>
            @foreach($data as $data)
            <tr>
              <td>{{$data->semester}}</td> 
              <td>{{$data->courseCodeTitile}}</td>
              <td>{{$data->section}}</td>
              <td>{{$data->credit_hour}}</td>
            </tr>                  
          @endforeach
          </tbody>
        </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
     
        <!-- /.row -->

@endsection