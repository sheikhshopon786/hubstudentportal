@extends('admin.aca.SacademicOffice')
@section('content')


<div class="col-lg-12">
        
          <h3 class="card-title">Semester Drop List</h3>
          <!--
            <div class="card-tools">
              <form action="{{route('stdSearch')}}" method="post" 
                  enctype="multipart/form-data">
                  {{csrf_field()}}
                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="stdSearch" placeholder="Enter Student ID" name="stdSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 -->
                 
  <div class="main-card mb-3 card">
    <div class="card-body"> 
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>Semester</th>
              <th>Reason</th>
              <th>Description</th>
               
            </tr>
          </thead>
          <tbody>
             
           @foreach($semesterDropList as $semesterDropList)
        <tr>
    
                        
          <td>{{$semesterDropList->student_id}}</td>
          <td>{{$semesterDropList->Semester}}</td>
          <td>{{$semesterDropList->Cause}}</td>
          <td>{{$semesterDropList->Description}}</td>
           
           
          
         
        </tr>                  
      @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



@endsection studentPaymentLedger