@extends('admin.aca.SacademicOffice')
@section('content')

<div class="col-md-12">
	<img src="images/academicIndexPic.jpg">
</div>






@endsection