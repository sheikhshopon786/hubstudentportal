@extends('layout.master')
@section('content')

<div class="row">
	<div class="col-md-12">
		<h2><b><u>RULES AND REGULATIONS</u></b></h2>

<p>
Hamdard University Bangladesh is an independent, non-political and not-for-profit private academic institution. It gives top priority to maintain a healthy academic atmosphere on the campus. Students of Hamdard University Bangladesh are expected to cooperate to reach this goal to enhance their academic achievements, maintaining discipline, keeping the campus clean and being good neighbours and model of good citizens.<br><br>

The academic rules and regulations for studying at Hamdard University Bangladesh provide detailed information concerning class attendance, examination guidelines, students’ outfit, disciplinary matters, etc. Students are advised to strictly abide by these rules and regulations.<br><br>

 <b>REGISTRATION</b><br><br>

Students are required to complete their registration formalities for enrolment in the ensuing Semester. Without registration, no student will be allowed to attend classes and it will be considered that the student is absent from the Semester. Every student must register in-person.

REGISTRATION PROCEDURES

Registration forms are available at the registration office and also on the University website: www.hamdarduniversity.edu.bd<br><br>

Completed registration form must be submitted to the office with the payment receipt as a proof that 100% of the registered course fees incurred by registration have already been paid to the University.<br><br>

No registration form will be received without payment receipt.<br><br>

<b>ADVISEMENT</b><br><br>

All students in the undergraduate and graduate programs will receive advice from designated student advisor prior to the registration for each semester. The program advisor will declare courses for different batches and programs before registration and advice students for their convenience. It is the responsibility of each student to comply with degree requirements and general regulations of the registration.<br><br>

<b>PREREQUISITE COURSES</b><br><br>

If any course has prerequisite course(s), every student has to complete that course(s) before taking the desired higher level course. Without the completion of the prerequisite course(s), students will not be allowed to take the course any way.<br><br>

<b>CLASS ATTENDANCE</b><br><br>

A student is expected to attend all classes in each course. However, the following rules are set for attendance to further ease the process:<br><br>

A student would be required to attend at least 75% of classes in a course in order to sit for the Final Exam without penalty.<br><br>

A student having class attendance of 60% – 74% (in a course) may be allowed to sit for the examination on payment of a penalty of Tk. 1000 (One Thousand) for that course.<br><br>

A student having less than 60% class attendance will not be allowed to sit for the examination.<br><br>

<b>ADMINISTRATION AND MONITORING OF COURSES OFFERED</b><br><br>

The course-teacher shall provide the students a course outline indicating the list of textbooks and reference books to follow, probable dates of in-course tests and take-home assignments.<br><br>

The Academic Committee will monitor the progress of the course by sitting together at least once in a month, prepare the in-course examination schedules and conduct the examinations.<br><br>

For final examination, the course teacher will follow the central academic calendar and policy.<br><br>

Results of each semester will be published within a maximum period of 14 days from the date of the term final.<br><br>

<b>RESEARCH ASSIGNMENT/ INTERNSHIP/ PROJECT (6 CREDIT HOURS)</b><br><br>

There is a variation in nomenclature and procedures in conducting Research Assignment/ Internship/ Project respectively for Faculty of Arts and Social Sciences (FASS), Faculty of Business Administration (FBA) and Faculty of Science, Engineering & Technology (FSET), although the total credit hours for each of them is 6. A brief description is given here. The Faculty of Unani and Ayurvedic Medicine (FUAM) follows a different procedure for internship befitting to a medical degree awarded through two departments.<br><br>

<b>FASS: RESEARCH ASSIGNMENT (6 CREDIT HOURS)
</b><br><br>
Students graduating from the departments under FASS need to carry out a research on their chosen areas during the last semester of their undergrad study following the standard procedure of the University. FASS prepares its students for Research Assignment giving a course on Research Methodology in the prior semester(s) where they need to produce a complete research proposal with the objective to conduct the actual research in the ensuing semester(s). The teacher in charge of this course becomes the Advisor and two Co-advisors are chosen from amongst the teachers of the respective Department for each student. The student and advisors are jointly responsible for the Research Course.
<br><br>
<b>
FBA AND FSET: INTERNSHIP/ PROJECT (6 CREDIT HOURS)</b><br> <br>

For improving students’ skills and competence by earning supervised practical experience and, in addition, to enable them to demonstrate maturity and acceptable professionalism, personal and interpersonal attitude, FBA and FSET facilitate every student with  an Internship or taking up an Innovative project for 3-6 months under the supervision of a teacher. On completion of the required curriculum, a student must apply for internship/ project to the concerned office at least a semester earlier mentioning that he/ she is going to do an internship/ do a project in the next semester. After the completion of the internship/ project work, the student needs to submit a report on her/ his internship/ project to the Department for review and allocation of grade point for the course.<br><br>
<b>
FUAM: INTERNSHIP FOR BUMS AND BAMS (1-YEAR AFTER THE FINAL EXAM)</b><br><br>

The Faculty accommodates two groups of students in BUMS and BUMS: 2-year (diploma-holders) and 5-year (regular) programs. On successful completion of their respective program, students need to undergo an internship period of one year in designated hospitals/ clinics. The Faculty hospital is going to be commissioned during this year (2017) and graduates from these two departments will be able to carry out their internships on HUB-campus.<br><br>

<b>CAMPUS OUTFIT FOR STUDENTS</b><br><br>

Students are advised to put on clean and decent dresses as a proud student of Hamdard University Bangladesh.<br><br>

All students must carry in person the university ID card while on campus.<br><br>

Students must not wear half/ three-quarter pants, full-face veil or sponge slippers.<br><br>

<b>LIBRARY USE</b><br><br>

Students are advised to strictly observe the following code of conduct while using the library facilities of the University:<br><br>

Students must observe silence while in the library. All sorts of non-academic discussions and making unnecessary noise must be avoided.<br><br>

Keep all the library belongings in order and arrange the chairs before leaving.<br><br>

Eating and drinking inside the library are strictly prohibited.<br><br>

Use the books and other reading materials carefully.<br><br>

Students found hiding or stealing books and/ or other library materials, tearing out pages of books/ journals would be subject to punishment as per the guidelines of the code of conduct.<br><br>

Students can borrow books from the library against their library cards and return them in good condition. If a book is not in good condition, the librarian may ask the student to pay for the book or to replace it.<br><br>

<b>VIOLATION OF DISCIPLINE</b><br><br>

Students of Hamdard University Bangladesh are expected to abide by the rules and regulations of the University. Violation of any rules and/ or regulations by any student may result in committing an offense as determined by the Disciplinary Committee of the University. Furthermore, the University reserves the right to take appropriate disciplinary action in accordance with the rules and regulations of Hamdard University Bangladesh.<br><br>
<b>
Admission Requirement
Tuition Fee and Financial Assistance
Rules & Regulation
Apply Now
Admission Form
Admission Advertisement
Applications FAQ
REGISTRATION</b><br><br>

Students are required to complete their registration formalities for enrolment in the ensuing Semester. Without registration, no student will be allowed to attend classes and it will be considered that the student is absent from the Semester. Every student must register in-person.<br><br>
<b>
REGISTRATION PROCEDURES</b><br><br>

Registration forms are available at the registration office and also on the University website:<br> www.hamdarduniversity.edu.bd
Completed registration form must be submitted to the office with the payment receipt as a proof that 100% of the registered course fees incurred by registration have already been paid to the University.
No registration form will be received without payment receipt.
<br><br>
<b>
ADVISEMENT</b><br><br>

All students in the undergraduate and graduate programs will receive advice from designated student advisor prior to the registration for each semester. The program advisor will declare courses for different batches and programs before registration and advise students for their convenience. It is the responsibility of each student to comply with degree requirements and general regulations of the registration.<br><br>

<b>PREREQUISITE COURSES</b><br><br>

If any course has prerequisite course(s), every student has to complete that course(s) before taking the desired higher level course. Without the completion of the prerequisite course(s), students will not be allowed to take the course any way.<br><br>
<b>
CLASS ATTENDANCE</b><br> <br>

A student is expected to attend all classes in each course. However, the following rules are set for attendance to further ease the process:<br><br>

A student would be required to attend at least 75% of classes in a course in order to sit for the Final Exam without penalty.
A student having class attendance of 60% – 74% (in a course) may be allowed to sit for the examination on payment of a penalty of Tk. 1000 (One Thousand) for that course.
A student having less than 60% class attendance will not be allowed to sit for the examination.<br><br>
<b>
ADMINISTRATION AND MONITORING OF COURSES OFFERED</b><br><br>

The course-teacher shall provide the students a course outline indicating the objectives of the course, detailed syllabus, day-to-day progression for the entire semester, list of textbooks and reference books to follow, probable dates of in-course tests and take-home assignments.
The Academic Committee will monitor the progress of the course by sitting together at least once in a month, prepare the in-course examination schedules and conduct the examinations.
For final examination, the course teacher will follow the central academic calendar and policy.
Results of each semester will be published within a maximum period of 14 days from the date of the term final.<br>
<b>
RESEARCH WORK/ INTERNSHIP/ PROJECT (6 CREDIT HOURS)</b><br><br>

There is a variation in nomenclature and procedures in conducting Research Work/ Internship/ Project respectively for Faculty of Arts and Social Sciences (FASS), Faculty of Business Administration (FBA) and Faculty of Science, Engineering & Technology (FSET), although the total credit hours for each of them is 6. A brief description is given here. The Faculty of Unani and Ayurvedic Medicine (FUAM) follows a different procedure for internship befitting to a medical degree awarded through two departments.<br><br>

<b>FASS: RESEARCH/ PROJECT WORK (6 CREDIT HOURS)</b><br><br>

Research/ Project work students under FASS need to carry out a research on their chosen areas during the last semester of their under graduate/ graduate study following the standard procedure of the University. FASS prepares its students for Research/ Project giving a course on Research Methodology in the prior semester(s) where they need to produce a complete research proposal with the objective to conduct the actual research in the ensuing semester(s). The teacher in charge of this course becomes the Advisor and two Co-advisors are chosen from amongst the teachers of the respective Department for each student. The student and advisors are jointly responsible for the Research Course.
<br><br>
<b>
FBA AND FSET: INTERNSHIP/ PROJECT (6 CREDIT HOURS)</b><br><br>
<b>
For improving students’ skills and competence by earning supervised practical experience and, in addition, to enable them to demonstrate maturity and acceptable professionalism, personal and interpersonal attitude, FBA and FSET facilitate every student with  an Internship or taking up an Innovative project for 3-6 months under the supervision of a teacher. On completion of the required curriculum, a student must apply for internship/ project to the concerned office at least a semester earlier mentioning that he/ she is going to do an internship/ do a project in the next semester. After the completion of the internship/ project work, the student needs to submit a report on her/ his internship/ project to the Department for review and allocation of grade point for the course.<br><br>
<b>
FUAM: INTERNSHIP FOR BUMS AND BAMS (1-YEAR AFTER FINAL EXAM)</b><br><br>

The Faculty accommodates two groups of students in BUMS and BUMS: 2-year (diploma-holders) and 5-year (regular) programs. On successful completion of their respective program, students need to undergo an internship period of one year in designated hospitals/ clinics. The Faculty hospital is going to be commissioned during this year (2017) and graduates from these two departments will be able to carry out their internships on HUB-campus.<br><br>
<b>
CAMPUS OUTFIT FOR STUDENTS</b><br><br>
<ul class="b">
<li>Students are advised to put on clean and decent dresses as a proud student of Hamdard University Bangladesh.</li>
<li>All students must carry in person the university ID card while on campus.</li>
<li>Students must not wear half/ three-quarter pants, full-face veil or sponge slippers.</li>
</ul><br><br>
<b>
LIBRARY USE</b><br><br>

Students are advised to strictly observe the following code of conduct while using the library facilities of the University:
<ul class="b">
<li>Students must observe silence while in the library. All sorts of non-academic discussions and making unnecessary noise must be avoided.</li>
<li>Keep all the library belongings in order and arrange the chairs before leaving.
Eating and drinking inside the library are strictly prohibited.</li>
<li>Use the books and other reading materials carefully.</li>
<li>Students found hiding or stealing books and/ or other library materials, tearing out pages of books/ journals would be subject to punishment as per the guidelines of the code of conduct.</li>
<li>Students can borrow books from the library against their library cards and return them in good condition. If a book is not in good condition, the librarian may ask the student to pay for the book or to replace it.</li></ul><br><br>
<b>
VIOLATION OF DISCIPLINE</b><br><br>

Students of Hamdard University Bangladesh are expected to abide by the rules and regulations of the University. Violation of any rules and/ or regulations by any student may result in committing an offense as determined by the Disciplinary Committee of the University. Furthermore, the University reserves the right to take appropriate disciplinary action in accordance with the rules and regulations of Hamdard University Bangladesh.
		</p>


	</div>

	 
</div>

@endsection