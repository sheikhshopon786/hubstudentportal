@extends('layout.master')
@section('content')

<div class="row">
	<div class="col-md-6">
		<h2><b><u>CONTACT US</u></b></h2>
		<ul class="b">
		<li>Hamdard University Bangladesh
		Hamdard City of Science, Education & Culture
		Gazaria, Munshiganj</li>
		<li>01776439000, 01776439001
		+88 02 9669823</li>
		<li>hub.ac.bd</li>
		<li>info@hamdarduniversity.edu.bd, admission@hamdarduniversity.edu.bd</li>
		<li>Sunday — Sat: 9AM — 5PM</li>
	</ul>
	</div>

	<div class="col-md-6">

  

	</div>
</div>

@endsection