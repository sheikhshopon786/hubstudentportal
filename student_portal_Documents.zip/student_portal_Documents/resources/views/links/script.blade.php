<!--NavBar and Sidebar Start-->
<script type="text/javascript" src="{{ URL::asset('assets/scripts/main.js')}}"></script>

<script type="text/javascript" src="{{ URL::asset('assets/js.js')}}"></script>

<!--NavBar and Sidebar End-->
 

  

 