<!--NavBar and Sidebar Start-->
<link rel="stylesheet" href="{{URL:: asset('main.css')}}">
<!--NavBar and Sidebar End-->
 
 
  

<!--Footer Start-->
<link rel="stylesheet" href="{{asset('css/footer.css')}}">
<!--Font Awesome-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  
<!--Footer End--> 
 
