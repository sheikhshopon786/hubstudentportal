@extends('student.studentpart')
@section('content')



 <a href="{{url('/studentPaymentDetails')}}" style="text-decoration: none; float: right;" >
        <div role="group" class="btn-group-lg btn-group btn-group-toggle">
             <label class="btn btn-focus">
                 Payment Scheme
                 <i class="metismenu-icon pe-7s-right-arrow"></i>
            </label>
        </div>
    </a>
 
<h5><b>Payment Ledger For Current Semester</b></h5><br>
<!--
foreach(paymentBox as paymentBox)

  

							<div class="row">
								<div class="col-lg-12 col-xl-3">
                                    <div class="card mb-3 widget-content bg-premium-dark">
                                        <div class="widget-content-wrapper text-white">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">paymentBox-PaymentType}}
                                                </div>  
                                            </div>

                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-warning"><span>৳paymentBox-PaymentAmount}}</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
endforeach 
               -->                  
                            <!--
                                <div class="col-lg-12 col-xl-3">
                                    <div class="card mb-3 widget-content bg-premium-dark">
                                        <div class="widget-content-wrapper text-white">
                                            <div class="widget-content-left">
                                                <div class="widget-heading">Total Others</div>
                                                 
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="widget-numbers text-warning"><span>৳0.00</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
 							</div>
                        -->



<!-- Styles -->
<style>
#chartdiv {
  width: 100%;
  height: 550px;
}

</style>

<!-- Resources -->
<script src="https://www.amcharts.com/lib/4/core.js"></script>
<script src="https://www.amcharts.com/lib/4/charts.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>

<!-- Chart code -->
<script>
am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

// Create chart instance
var chart = am4core.create("chartdiv", am4charts.XYChart);

// Add data
chart.data = [
@foreach($payment as $payment)
{

  "country": "{{$payment->FeeType}}",
  "visits": "{{$payment->Amount}}"
},
@endforeach 

 



];

// Create axes

var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "country";
categoryAxis.renderer.grid.template.location = 0;
categoryAxis.renderer.minGridDistance = 30;

categoryAxis.renderer.labels.template.adapter.add("dy", function(dy, target) {
  if (target.dataItem && target.dataItem.index & 2 == 2) {
    return dy + 25;
  }
  return dy;
});

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

// Create series
var series = chart.series.push(new am4charts.ColumnSeries());
series.dataFields.valueY = "visits";
series.dataFields.categoryX = "country";
series.name = "Visits";
series.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
series.columns.template.fillOpacity = .8;

var columnTemplate = series.columns.template;
columnTemplate.strokeWidth = 2;
columnTemplate.strokeOpacity = 1;

}); // end am4core.ready()
</script>

<!-- HTML -->

    <div class="col-md-12">
        <div id="chartdiv"></div>
        <b>Fee Name</b>
    </div>


 
@endsection