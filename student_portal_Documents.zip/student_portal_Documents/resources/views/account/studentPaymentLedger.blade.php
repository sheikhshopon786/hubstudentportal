@extends('account.accountOffice')
@section('content')


<div class="col-lg-12">
        
          <h3 class="card-title">Students Payment Ledger</h3>
          <!--
            <div class="card-tools">
              <form action="{{route('stdSearch')}}" method="post" 
                  enctype="multipart/form-data">
                  {{csrf_field()}}
                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="stdSearch" placeholder="Enter Student ID" name="stdSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 -->
                 
  <div class="main-card mb-3 card">
    <div class="card-body"> 
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>Fee Type</th>
              <th>Paid</th>
              <th>Payment Type</th>
              <th>Paid</th>
               
            </tr>
          </thead>
          <tbody>
             
           @foreach($studentPaymentLedger as $studentPaymentLedger)
        <tr>
    
                        
          <td>{{$studentPaymentLedger->student_id}}</td>
          <td>{{$studentPaymentLedger->FeeType}}</td>
          <td>{{$studentPaymentLedger->Amount}}</td>
          <td>{{$studentPaymentLedger->PaymentType}}</td>
          <td>{{$studentPaymentLedger->PaymentAmount}}</td>
       
           
           
          
         
        </tr>                  
      @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



@endsection studentPaymentLedger