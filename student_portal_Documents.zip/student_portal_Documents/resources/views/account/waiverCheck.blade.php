 @extends('layout.master')
 @section('content')
 

 <div class="col-md-12">
  <div class="row">
    <div class="col-md-8" style="text-align:center; 
    background: #474747; color: white; padding: 20px;">

     

  


    <form action="{{route('wsearch')}}" method="post" 
    enctype="multipart/form-data">
    {{csrf_field()}}
<!--
    <label for="" class="sr-only">Select Program</label>
    <input type="text" class="form-control" id="Program" placeholder="Select Program" name="Program">
    <br>
    <label for="" class="sr-only">Waiver</label>
    <input type="text" class="form-control" id="Waiver" placeholder="Waiver" name="Waiver">
  -->


    <select value="Program" name="Program" id="Program"  style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">

      <option selected="" disabled="">
        Select Program
      </option>
 

             
              <option value="B.Sc in Computer Science & Engineering">
                 B.Sc in Computer Science & Engineering
              </option>
              <option value="B.Sc in Electrical & Electronics Engineering">
                B.Sc in Electrical & Electronics Engineering
              </option>
              <option value="B.Sc in Mathematics">
                B.Sc in Mathematics
              </option>

    </select>


    <select value="Waiver" name="Waiver" id="Waiver" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">

      <option selected="" disabled="">
        Select Waiver
      </option>

      <option value="10%">10% </option>

      <option value="20%">20% </option>


      <option value="40%">40% </option>


      <option value="50%">50% </option>


    </select>
 


    <button type="submit" class="btn btn-primary">Submit</button>             
  </form>








  <table class="table" style="color:#fff">
   @foreach($data as $data)
   <thead>
    <tr>
      <th scope="col">Total Fee</th>

    </tr>
  </thead>
  <tbody>

    <tr>
      <td>{{$data->Amount}}</td>
    </tr>

    @endforeach

  </tbody>
</table>
</div>





<div class="col-md-4" style="text-align: center; 
background:#302f2f; color:white ; opacity: .8;">
<div class="widget">

  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col" style="color: #fff">Results (SSC+HSC Without 4th Subject)</th>
        <th scope="col" style="color: #fff">Waiver</th>

      </tr>
    </thead>
    <tbody>

      <tr>
        <td scope="row" style="color: #fff">10.00</td>
        <td style="color: #fff">50%</td>


      </tr>

      <tr>
        <td scope="row" style="color: #fff">9.00 - 9.99</td>
        <td style="color: #fff">40%</td>


      </tr>

      <tr>
        <td scope="row" style="color: #fff">8.00 - 8.99</td>
        <td style="color: #fff">20%</td>

      </tr>

      <tr>
        <td scope="row" style="color: #fff">7.00 - 7.99</td>
        <td style="color: #fff">10%</td>

      </tr>
    </tbody>
  </table>


</div>
</div>




</div>
</div>








 






@endsection