@extends('student.studentpart')
@section('content')
 


 


<div class="card-body"><h4 class="" style="text-align: center;"><b>Payment Scheme</b></h4>


<form action="{{route('SPDSearch')}}" method="post" 
    enctype="multipart/form-data">
    {{csrf_field()}}



<select value="semester" name="semester" id="semester"  style="width: 50%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Semester
            </option>
            @foreach($semester as $semester)

            <option value="{{$semester->semester}}">{{$semester->semester}}</option>
            
          @endforeach 
        </select>




    <button type="submit" class="btn btn-primary">Submit</button> 
</form>



    <br><br><br><br>
<caption style="text-align: center;"><h6><b>Payment Scheme</b></h6></caption>
	<table class="mb-0 table table-dark">

		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th style="text-align: center;">Total Payable</th>
				<th style="text-align: center;">Total Waiver</th>
				<th style="text-align: center;">Total Paid</th>
				
				 
			</tr>
		</thead>

		<tbody>
			<tr>
				@foreach($liveResult as $liveResult) 	
				<td style="text-align: center;">{{$liveResult->TotalPayable}}</td>
				<td style="text-align: center;">{{$liveResult->Waiver}}</td>
				<td style="text-align: center;">{{$liveResult->PaidAmount}}</td>
				@endforeach	
			</tr>

	
			<tr>
				<td style="text-align: center;">
					<b>Total Due:-</b>
				</td>
				
				<td style="text-align: left;">
					@foreach($paymentLedger as $paymentLedger)
					{{$paymentLedger->Due}}
					@endforeach
				</td>
				
			</tr>
		
		</tbody>

	</table>
	
</div>



 


 

@endsection