@extends('account.accountOffice')
@section('content')






<div class="card-body"><h5 class="card-title">Student Results:</h5>




  <form action="{{route('StdRSearch')}}" method="post" 
    enctype="multipart/form-data">
    {{csrf_field()}}
<!--
    <label for="" class="sr-only">Select Program</label>
    <input type="text" class="form-control" id="Program" placeholder="Select Program" name="Program">
    <br>
    <label for="" class="sr-only">Waiver</label>
    <input type="text" class="form-control" id="Waiver" placeholder="Waiver" name="Waiver">
  -->


     <div class="form-group">
            <label for="student_id">Student ID</label>
            <input type="text" class="form-control" id="student_id" placeholder="Please Insert Student ID" name="student_id" required="">
        </div>


    <button type="submit" class="btn btn-primary">Submit</button>             
  </form>








 



<b>Semester Wise GPA Status: @foreach($studentResult as $studentResult)  @endforeach </b>
<table class="mb-0 table table-dark">
    <tr>
      <th style="text-align: center;">
        Semester: 01
      </th>
       <th style="text-align: center;">
        Semester: 02
      </th>     
       <th style="text-align: center;">
        Semester: 03
      </th>  
       <th style="text-align: center;">
        Semester: 04
      </th>  
       <th style="text-align: center;">
        Semester: 05
      </th>  
       <th style="text-align: center;">
        Semester: 06
      </th>  
       <th style="text-align: center;">
        Semester: 07
      </th>  
       <th style="text-align: center;">
        Semester: 08
      </th>  
    </tr>
   

    <tr>   
      @foreach($semesterNo1 as $semesterNo1)
      <td style="text-align: center;">Total GPA: {{$semesterNo1->GPA}}</td>
      @endforeach

       @foreach($semesterNo2 as $semesterNo2)
      <td style="text-align: center;">Total GPA: {{$semesterNo2->GPA}}</td>
      @endforeach    

       @foreach($semesterNo3 as $semesterNo3)
      <td style="text-align: center;">Total GPA: {{$semesterNo3->GPA}}</td>
      @endforeach  

       @foreach($semesterNo4 as $semesterNo4)
      <td style="text-align: center;">Total GPA: {{$semesterNo4->GPA}}</td>
      @endforeach  

       @foreach($semesterNo5 as $semesterNo5)
      <td style="text-align: center;">Total GPA: {{$semesterNo5->GPA}}</td>
      @endforeach  

       @foreach($semesterNo6 as $semesterNo6)
      <td style="text-align: center;">Total GPA: {{$semesterNo6->GPA}}</td>
      @endforeach  

       @foreach($semesterNo7 as $semesterNo7)
      <td style="text-align: center;">Total GPA: {{$semesterNo7->GPA}}</td>
      @endforeach  

       @foreach($semesterNo8 as $semesterNo8)
      <td style="text-align: center;">Total GPA: {{$semesterNo8->GPA}}</td>
      @endforeach  

    </tr>


</table>




@endsection