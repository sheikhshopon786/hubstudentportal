@extends('student.studentpart')
@section('content')
 
 
<div>
	<h1><b>You're Not Eligible for Course Registration.</b></h1>

	<h4>!---Please Clear Your Due Amount---!</h4>
</div>



@endsection