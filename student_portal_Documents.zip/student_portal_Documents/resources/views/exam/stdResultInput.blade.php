@extends('exam.examOffice')
@section('content')
     <div class="col-md-9" >
          <div class="widget" style="margin-left: 10px;">
            
            <h3>Product Entry</h3>
            <div >
              <div class="row">

                    
      <form action="/SReditsv" method="post" enctype="multipart/form-data" >
        {{csrf_field()}}

  

 @foreach($data as $data)
 <div class="form-group">
    <label for="ID">ID</label>
    <input type="text" class="form-control" id="ID" placeholder="Tittle" name="ID" readonly value="{{$data->ID}}">
  </div>

  <div class="form-group">
    <label for="student_id">Student ID</label>
    <input type="text" class="form-control" id="student_id" placeholder="Student ID" name="student_id" value="{{$data->student_id}}" readonly="">
  </div>

  <div class="form-group">
    <label for="semester">Semester</label>
    <input type="text" class="form-control" id="semester" placeholder="Semester" name="semester" value="{{$data->semester}}" readonly="">
  </div>


 <div class="form-group">
    <label for="courseCodeTitile">Course Code & Titile</label>
    <input type="text" class="form-control" id="courseCodeTitile" placeholder="Course Code & Titile" name="courseCodeTitile" value="{{$data->courseCodeTitile}}" readonly="">
  </div>

   <div class="form-group">
    <label for="credit_hour">Credit Hour</label>
    <input type="text" class="form-control" id="credit_hour" placeholder="Credit Hour" name="credit_hour" value="{{$data->credit_hour}}" readonly="">
  </div>

  <div class="form-group">
    <label for="Grade">Grade</label>
    <input type="text" class="form-control" id="Grade" placeholder="Grade" name="Grade" value="{{$data->Grade}}">
  </div>

  <div class="form-group">
    <label for="GradePoint">Grade Point</label>
    <input type="text" class="form-control" id="GradePoint" placeholder="Grade Point" name="GradePoint" value="{{$data->GradePoint}}">
  </div>


    
 

  <button type="submit" class="btn btn-primary">Save</button>

   @endforeach
</form>


    </div>
    </div>

    </div>
    </div>
    
@endsection   
