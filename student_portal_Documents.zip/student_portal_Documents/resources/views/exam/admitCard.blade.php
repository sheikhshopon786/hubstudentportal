 


 
<table style="width: 100%;">
    <tr>
        <td colspan="3">
        	<img src="images/hub_logo.png" style="width:100px"><br>
        	<b>Hamdard University Bangladesh</b>
        </td>
         

         

        <td colspan="0" style="text-align: right;"><font size="5"><b>    Admit Card</b></font><br>
        	Midterm Examination<br>
            
            @foreach($semester as $semester)
                {{$semester->semester}}
            @endforeach
           
            <br>
            @foreach($admitserial as $admitserial)
            SI No- {{$admitserial->Serial}}
            @endforeach
        </td>
    </tr>

    <tr>
	    <td colspan="6">
	    	--------------------------------------------------------------------------------------------------------------------------------------
	    </td>
    </tr>

    <tr>
        @foreach($stdInfo as $stdInfo)
        <td colspan="3">
        	Student ID: {{$stdInfo->student_id}}<br>
        	Student Name: {{$stdInfo->FirstName}} {{$stdInfo->LastName}} <br>
        	Faculty: {{$stdInfo->Faculty}}<br>
        	Program: {{$stdInfo->Department}}<br>
        </td>
        @endforeach

        @foreach($image as $image)
        <td colspan="2" style="text-align: right;"> 
            <img src="{{url('/')}}/image/{{$image->image}}" style="width: 90px; height:100px"><br> 
            RCH- {{$image->TotalCredit}}
        </td>
        @endforeach
    </tr>
    


    <tr>
	    <td colspan="6">
	    	--------------------------------------------------------------------------------------------------------------------------------------
	    </td>
    </tr>

 
    <tr>
    	<th style="text-align: left;">Course Code And Title</th>
        <th>Section</th>
        <th>Chr</th>
    </tr>


@foreach($courseForAdmit as $courseForAdmit)
    <tr>
        <td style="width: ">{{$courseForAdmit->courseCodeTitile}}</td>
        
    	<td style="text-align: center;">{{$courseForAdmit->section}}</td>
    	<td style="text-align: center;">{{$courseForAdmit->credit_hour}}</td>
         @endforeach
    </tr>

 
    <tr>
    	<td colspan="5">
    		<br><br><br><br><br><br><br><br><br><br>
    	</td>
	</tr>


    <tr>
    	<td colspan="4">
    		
    		<b><u>Instructions for Examinees</u></b><br>
    	<ul type="bullet">
    		<li>Examinees should enter the examination hall 10 minuties before the examination starts.<br></li>
    		
    		<li>No examinee shakk be alllowed to sit dor the examination without the Admit Card.<br></li>

    		<li>Cellular phone,Electronic Dairy or such kind of device will not be allowed in the examonation hall.<br></li>

    		<li>No examinees shall be allowed to carry any paper's except the Admit Card.<br></li>
    		<b>
    		<li>If an examinee lost, destroyed or forgot to bring the Admit Card, he/she will have to collect new Admit Card with payment of TK. 100 (one hundres).</b> <br></li>

    		<li>No examinee can go out within 30 minuties of Midterm Exam and 01 Hour of Final Exam.<br><br><br><br><br></li></ol>

    	</td>
    </tr>

    <tr>
    	<td colspan="4">
           <!-- <img src="images/ExamControllerSign.png" width="120px;"><br>-->
    		--------------------------<br>
    		<b>Controller of Examination</b>
    	</td>
    </tr>

     <tr>
    	<td colspan="4" style="text-align: center;">
    		Please Preserve this Admit Card for future references
    	</td>
    </tr>

</table>


<!--<button type="submit" class="btn btn-primary">Download</button>-->

 




 