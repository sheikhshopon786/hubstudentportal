@extends('exam.examOffice')
@section('content')

 
<div class="col-lg-12">
        
          <h3 class="card-title">All Students</h3>
            <div class="card-tools">
              <form action="{{route('stdLRSearch')}}" method="post" 
                  enctype="multipart/form-data">
                  {{csrf_field()}}
                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="stdLRSearch" placeholder="Enter Student ID" name="stdLRSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 
                 

  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">All Students</h5>
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>Semester</th>
              <th>Course Code & Titile</th>
              <th>Quiz1</th>
              <th>Quiz2</th>
              <th>Result Update</th>
               
              
            </tr>
          </thead>
          <tbody>
             
           @foreach($data as $data)
        <tr>
    
                        
          <td>{{$data->student_id}}</td>
          <td>{{$data->semester}}</td>
          <td>{{$data->courseCodeTitile}}</td>
          <td>{{$data->Quiz1}}</td>
          <td>{{$data->Quiz2}}</td>
           
           
           
          <td> 
            <a href="{{url('/Lieditreq',$data->ID)}}" class="btn btn-primary">Update</a>
          </td> 
           
          
        </tr>                  
      @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



@endsection 