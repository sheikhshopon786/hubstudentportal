@extends('exam.examOffice')
@section('content')
     <div class="col-md-9" >
          <div class="widget" style="margin-left: 10px;">
          	
            <h3>Product Entry</h3>
          	<div >
              <div class="row">

                    
      <form action="/Lieditsv" method="post" enctype="multipart/form-data" >
      	{{csrf_field()}}

  

 @foreach($data as $data)
 <div class="form-group">
    <label for="ID">ID</label>
    <input type="text" class="form-control" id="ID" placeholder="Tittle" name="ID" readonly value="{{$data->ID}}">
  </div>

  <div class="form-group">
    <label for="student_id">Student ID</label>
    <input type="text" class="form-control" id="student_id" placeholder="Student ID" name="student_id" value="{{$data->student_id}}" readonly="">
  </div>

  <div class="form-group">
    <label for="semester">Semester</label>
    <input type="text" class="form-control" id="semester" placeholder="Semester" name="semester" value="{{$data->semester}}" readonly="">
  </div>


 <div class="form-group">
    <label for="courseCodeTitile">Course Code & Titile</label>
    <input type="text" class="form-control" id="courseCodeTitile" placeholder="Course Code & Titile" name="courseCodeTitile" value="{{$data->courseCodeTitile}}" readonly="">
  </div>

  <div class="form-group">
    <label for="Quiz1">Quiz1</label>
    <input type="text" class="form-control" id="Quiz1" placeholder="Quiz1" name="Quiz1" value="{{$data->Quiz1}}">
  </div>

  <div class="form-group">
    <label for="Quiz2">Quiz2</label>
    <input type="text" class="form-control" id="Quiz2" placeholder="Quiz2" name="Quiz2" value="{{$data->Quiz2}}">
  </div>


    
 

  <button type="submit" class="btn btn-primary">Save</button>

   @endforeach
</form>


		</div>
		</div>

		</div>
		</div>
		
@endsection		
