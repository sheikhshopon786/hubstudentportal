@extends('exam.examOffice')
@section('content')
<!--Student Information form start -->

<!--Student Information form End --> 
<body>
<form action="{{route('resultVerifyForm')}}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 {{csrf_field()}} 
 <b>{{session('msg')}}</b>

 <div class="card-body">
    <h4 class="card-title">Result Verification Form</h4>
    <div class="form-group row">
        <label for="student_id" class="col-sm-3 text-right control-label col-form-label">Student ID</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="student_id" placeholder=" Student ID" name="student_id" required="">
        </div>
    </div>
    <div class="form-group row">
        <label for="Name" class="col-sm-3 text-right control-label col-form-label">Full Name</label>
        <div class="col-sm-9">
            <input type="text" class="form-control" id="Name" placeholder="Full Name" name="Name" required="">
        </div>
    </div>

    <select value="DepartmentName" name="DepartmentName" id="DepartmentName" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Department
              </option>
              <option value="B.Sc in Computer Science & Engineering">
                 B.Sc in Computer Science & Engineering
              </option>
              <option value="B.Sc in Electrical & Electronics Engineering">
                B.Sc in Electrical & Electronics Engineering
              </option>
              
           </select>


    <div class="form-group row">
        <label for="CGPA" class="col-sm-3 text-right control-label col-form-label">CGPA</label>
        <div class="col-sm-9">
         <input type="text" class="form-control" id="CGPA" placeholder=" CGPA" name="CGPA" required="">
     </div>
 </div>

 <div class="form-group row">
    <label for="PassingYear" class="col-sm-3 text-right control-label col-form-label"> Issuance Date</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="PassingYear" placeholder="Issuance Date" name="PassingYear" required="">
 </div>
</div>


 <div class="form-group row">
    <label for="PassingYear" class="col-sm-3 text-right control-label col-form-label"> Serial Number</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="SerialNumber" placeholder="Serial Number" name="SerialNumber" required="">
 </div>
</div>

 

<div class="border-top">
    <div class="card-body" class="alert alert-success">
        <button type="submit" class="btn btn-primary" id="btn" name="btn" value="btn">Submit</button>
        
         
    </div>

</div>
</form>
</body>


@endsection

