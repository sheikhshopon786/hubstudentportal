@extends('exam.examoffice')
@section('content')


      






          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Applcant List For Transcript</h3>  

             
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table class="table table-hover">
         <thead>
            <tr>
              <th scope="col">Student ID</th>
              <th scope="col">Apply Date</th>
              <th scope="col">Dalivery Date</th>
              <th scope="col">Alternate Email</th>
              <th scope="col">Mobile Number</th>      
              <th scope="col">Document Name</th>
              <th scope="col">Document Type</th>
              <th scope="col">Number Of Copy</th>
              <th scope="col">UrgencyType</th>
               
            </tr>
          </thead>

          <tbody>
           
@foreach($certificateApplicationList as $certificateApplicationList)
            <tr>
              <td>{{$certificateApplicationList->student_id}}</td> 
              <td>{{$certificateApplicationList->ApplyDate}}</td>
              <td>{{$certificateApplicationList->DaliveryDate}}</td>
              <td>{{$certificateApplicationList->AlternateEmail}}</td>
              <td>{{$certificateApplicationList->MobileNumber}}</td>
              <td>{{$certificateApplicationList->Document}}</td>
              <td>{{$certificateApplicationList->DocumentType}}</td>
              <td>{{$certificateApplicationList->NumberOfCopy}}</td>
              <td>{{$certificateApplicationList->UrgencyType}}</td> 
            </tr>                  
          @endforeach
          </tbody>
        </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>

@endsection