@extends('exam.examoffice')
@section('content')






<div class="card-body"><h5 class="card-title">Student Results:</h5>




 <form action="{{route('SRsearch')}}" method="post" 
      enctype="multipart/form-data">
       {{csrf_field()}}
              <label for="" class="sr-only">ID</label>
               <input type="text" class="form-control" id="SRsearch" placeholder="Enter Student ID" name="SRsearch">

              <button type="submit" class="btn btn-primary">Submit</button>             
        </form>








<table class="mb-0 table table-dark">
   
  <thead>
    <tr>
      <th scope="col">Student ID</th>
      <th scope="col">Course Code And Ttile</th>
      <th scope="col"style="text-align: center;">Credit</th>
      <th scope="col"style="text-align: center;">Grade</th>
      <th scope="col"style="text-align: center;">Grade Point</th>
    
    </tr>
  </thead>
  <tbody>
   @foreach($data as $data)
      <tr>
      <td>{{$data->student_id}}</td>
      <td>{{$data->courseCodeTitile}}</td>
      <td style="text-align: center;">{{$data->credit_hour}}</td>
      <td style="text-align: center;">{{$data->Grade}}</td>
      <td style="text-align: center;">{{$data->GradePoint}}</td>
      
      <td> 
            <a href="{{url('/SReditreq',$data->ID)}}" class="btn btn-primary">Edit</a>
      </td>

           
    </tr>
           
        @endforeach
  
    
  </tbody>
</table>






@endsection