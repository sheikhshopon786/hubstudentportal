@extends('student.studentpart')
@section('content')
 


 


<div class="card-body"><h4 class="" style="text-align: center;"><b>Live Result</b></h4>


<form action="{{route('lRSearch')}}" method="post" 
    enctype="multipart/form-data">
    {{csrf_field()}}



<select value="Semester" name="Semester" id="Semester"  style="width: 50%; height: 10%;" class="mb-2 form-control-lg form-control">
  
        <option selected="" disabled="">
              Select Semester
            </option>
            @foreach($semester as $semester)

            <option value="{{$semester->semester}}">{{$semester->semester}}</option>
            
          @endforeach 
        </select>




    <button type="submit" class="btn btn-primary">Submit</button> 
</form>



    <br><br><br><br>
<caption style="text-align: center;"><h6><b>Registered Course List</b></h6></caption>
	<table class="mb-0 table table-dark">

		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th style="text-align: left;">Action</th>
 
				 
				<th style="text-align: center;">Course Code and Title</th>
				 
			</tr>
		</thead>
@foreach($liveResult as $liveResult)
		<tbody>
			<tr>
 
           



				<td>

					<a href="{{url('/Leditreq',$liveResult->ID)}}" style="text-decoration: none;">
						<div role="group" class="btn-group-lg btn-group btn-group-toggle" >
						<button type="button" class="btn btn-alternate"> View Live Result
						</button>	
						</div>
					</a>
				</td>

			<td style="text-align: center;">{{$liveResult->courseCodeTitile}}</td>

			 
@endforeach

			</tr>
		</tbody>

	</table>
	
</div>






<!--
<div class="card-body"><h5 class="card-title"></h5>
<caption style="text-align: center;"><h6><b></b></h6></caption>
	<table class="mb-0 table table-dark">
 
		<thead>
			<tr>
				<!--<th>Semester</th>--
				 
				<th style="text-align: center;">Live Result:</th>
			</tr>
		</thead>
 
		
 @foreach($LR as $LR)
		<tbody>
			<tr>
				<td style="text-align: left;">Course Code & Title: <b>{{$LR->courseCodeTitile}}</b></td>
			</tr>
			<tr>
				<td style="text-align: left;">Quiz 1: {{$LR->Quiz1}}</td>
			</tr>
			<tr>
				<td style="text-align: left;">Quiz 2: {{$LR->Quiz2}}</td>
			</tr>
			<tr>
				<td style="text-align: left;">Quiz Average: {{$LR->Average}}</td>
			</tr>
			<tr>
				<td style="text-align: left;">Midterm: {{$LR->MidTerm}}</td>
			</tr>
			<tr>
				<td style="text-align: left;">Midterm Improvement: {{$LR->Improvement}}</td>
			</tr>
		</tbody>

 @endforeach
	</table>
</div>-->









@endsection