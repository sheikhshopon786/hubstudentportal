@extends('student.studentpart')
@section('content')
 


 



<div class="card-body"><h4 class="" style="text-align: center;"><b>Live Result</b></h4>
	
</div>


<div class="card-body"><h5 class="card-title"></h5>
	 @foreach($LR as $LR)
<caption style="text-align: center;"><h6><b>Live Result of: {{$LR->courseCodeTitile}}</b></h6></caption>
	<table class="mb-0 table table-dark">

		<thead>
			<tr>
				<!--<th>Semester</th>-->
				<th style="text-align: center;">Quiz 1:</th>
				<th style="text-align: center;">Quiz 2:</th>
				<th style="text-align: center;">Quiz Average</th>
				<th style="text-align: center;">Midterm</th>
				<th style="text-align: center;">Midterm Improvement(If Eligible)</th>
			</tr>
		</thead>

		

		<tbody>
			<tr>
				
				
				<td style="text-align: center;">{{$LR->Quiz1}}</td>
				<td style="text-align: center;">{{$LR->Quiz2}}</td>
				<td style="text-align: center;">{{$LR->Average}}</td>
				<td style="text-align: center;">{{$LR->MidTerm}}</td>
				<td style="text-align: center;">{{$LR->Improvement}}</td>
			</tr>
		</tbody>

 @endforeach
	</table>
</div>


			




@endsection