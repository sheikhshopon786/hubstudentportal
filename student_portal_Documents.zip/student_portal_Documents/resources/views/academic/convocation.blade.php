@extends('student.studentpart')
@section('content')
 

<h1><b>Convocation Work is processing</b></h1>

@endsection

