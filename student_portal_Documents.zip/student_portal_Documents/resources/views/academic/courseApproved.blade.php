@extends('academic.academicOffice')
@section('content')

 
<div class="col-lg-12">
        
          <h3 class="card-title">All Students</h3>
            <div class="card-tools">
              <form action="{{route('CourseSearch')}}" method="post" 
                  enctype="multipart/form-data">
                  {{csrf_field()}}
                  <label for="" class="sr-only">ID</label>
                  <input type="text" class="form-control" id="CourseSearch" placeholder="Enter Student ID" name="CourseSearch" required="">

                  <button type="submit" class="btn btn-primary">Submit</button>
             </form>
          </div>
                 
                 
  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">All Students</h5>
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Student ID</th>
              <th>Semester No</th>
              <th>Semester</th>
              <th>Course Code Titile</th>
              <th>Approval</th>         
            </tr>
          </thead>
          <tbody>
             
           @foreach($studentInformationList as $studentInformationList)
        <tr>
    
                        
          <td>{{$studentInformationList->student_id}}</td>
          <td>{{$studentInformationList->semesterNo}}</td>
          <td>{{$studentInformationList->semester}}</td>
          <td>{{$studentInformationList->courseCodeTitile}}</td>
          
           
          
           
           
          <td>

            @php
            {{
              $chk=DB::select('select IFNULL(CourseApproval,0)CourseApproval  from courseregistration c, admission a where a.student_id=c.student_id and c.student_id=? order by a.student_id',[$studentInformationList->student_id]);
            }}
            @endphp

            @foreach($chk as $chk)
            @if($chk->CourseApproval!=1)
            <a href="{{url('/approvalForCourse',$studentInformationList->student_id)}}"  class="btn btn-danger">Approve</a>
            @else
            <a href="{{url('/approvalForCourse',$studentInformationList->student_id)}}"  class="btn btn-success">Approved</a>
            @endif
            @endforeach
            
          </td>
        </tr>                  
      @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



@endsection 