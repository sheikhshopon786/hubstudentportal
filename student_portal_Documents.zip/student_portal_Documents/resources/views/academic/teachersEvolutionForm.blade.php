@extends('academic.academicOffice')
@section('content')
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Course Offer & Class Schedule</b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
              <form action=" " method="post" 
      enctype="multipart/form-data" role="form">
       {{csrf_field()}}
                <div class="card-body">

                  <div class="form-group"> 
              <label for="CourseName">Course Name</label>
              <input type="text" class="form-control" id="CourseName" placeholder="CourseName" name="CourseName"  required="">   
                  </div>

                  <div class="form-group">
              <label for="TeachersName">Teacher's Name</label>
              <input type="text" class="form-control" id="TeachersName" placeholder="TeachersName" name="TeachersName" required="">
                  </div>

                  <div class="form-group">
                    <label for="Question">Question</label>
              <input type="text" class="form-control" id="Question" placeholder=" Question" name="Question" required="">
                  </div>

                  <div class="form-group">
                    <label for="course_title">Course Tittle</label>
              <input type="text" class="form-control" id="course_title" placeholder="Course Tittle" name="course_title" required="">
              </div>



                  <div class="form-group">
                    <label for="section">Section</label>
              <input type="text" class="form-control" id="section" placeholder="Section" name="section" required="">
                  </div>


                  <div class="form-group"> 
              <label for="credit_hour">Credit Hour </label>
              <input type="text" class="form-control" id="credit_hour" placeholder="Credit Hour" name="credit_hour" required="">   
                  </div>

          
                  <div class="form-group">
              <label for="department">Department</label>
              <input type="text" class="form-control" id="department" placeholder="department" name="department" required="">
                  </div>

                  <div class="form-group">
                    <label for="teacher_name">Teacher Name</label>
              <input type="text" class="form-control" id="teacher_name" placeholder=" Teacher Name" name="teacher_name" required="">
                  </div>

                  <div class="form-group">
                    <label for="day">Day</label>
              <input type="text" class="form-control" id="day" placeholder="Day" name="day" required="">
              </div>



                  <div class="form-group">
                    <label for="time">Time</label>
              <input type="time" class="form-control" id="time" placeholder="Time" name="time" required="">
                  </div>


                  <div class="form-group"> 
              <label for="room_no">Room No</label>
              <input type="text" class="form-control" id="room_no" placeholder="Room No" name="room_no" required="">   
                  </div>





               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->

@endsection