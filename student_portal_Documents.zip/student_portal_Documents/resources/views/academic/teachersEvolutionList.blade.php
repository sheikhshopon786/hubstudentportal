 @extends('academic.academicOffice')
@section('content')


@extends('admin.admin')
@section('content')
 
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Teachers Evolution List</h3>  

             
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 500px;">
            
        <table class="table table-hover">
         <thead>
            <tr>
              <th scope="col">Teacher Name</th>
              <th scope="col">Course Name</th>
              <th scope="col">Marks</th>
              <th scope="col">Comment</th>
              <th scope="col">Good</th>      
              <th scope="col">Well</th>
            </tr>
          </thead>

          <tbody>
            @foreach($teachersEvolutionList as $teachersEvolutionList)
            <tr>
              <td>{{$teachersEvolutionList->TeachersName}}</td> 
              <td>{{$teachersEvolutionList->CourseName}}</td>
              <td>{{$teachersEvolutionList->Marks}}</td>
              <td>{{$teachersEvolutionList->Comment}}</td>
              <td>{{$teachersEvolutionList->good}}</td>
              <td>{{$teachersEvolutionList->well}}</td>
            </tr>                  
          @endforeach
          </tbody>
        </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
     
        <!-- /.row -->

@endsection


@endsection