
@extends('layout.Master')
@section('content')
     <div class="col-md-9" >
          <div class="widget" style="margin-left: 10px;">
          	
            <h3>Product Entry</h3>
          	<div >
              <div class="row">

                    
      <form action="/courseEditsv" method="post" enctype="multipart/form-data" >
      	{{csrf_field()}}

  

 @foreach($studentCourseRegistrationList as $studentCourseRegistrationList)
 <div class="form-group">
    <label for="Id">Id</label>
    <input type="text" class="form-control" id="Id" placeholder="Id" name="Id" readonly value="{{$studentCourseRegistrationList->Id}}">
  </div>
  <div class="form-group">
    <label for="courseCodeTitile">Course Code & Titile</label>
    <input type="text" class="form-control" id="courseCodeTitile" placeholder="courseCodeTitile" name="courseCodeTitile" value="{{$studentCourseRegistrationList->courseCodeTitile}}">
  </div>

 

  <button type="submit" class="btn btn-primary">Save</button>

   @endforeach
</form>


		</div>
		</div>

		</div>
		</div>
		
@endsection		
