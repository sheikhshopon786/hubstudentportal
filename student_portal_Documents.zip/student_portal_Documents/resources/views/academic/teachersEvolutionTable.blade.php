 @extends('student.studentPart')
@section('content')



<div class="row">


<div class="col-lg-10">                       
  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">Please Confirm Teacher's Evolution</h5>
      <div class="table-responsive">
        <form action="{{route('teachersEvolution')}}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
 {{csrf_field()}}

        	<table class="mb-0 table">
          <thead>
            <tr> 

              <th>

 
                <select name="courseCodeTitile" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
  
                    <option selected="" disabled="">
                      Select Course
                    </option>
   @foreach($course as $course)
                    <option value="{{$course->courseCodeTitile}}">{{$course->courseCodeTitile}} </option>
               @endforeach                
                </select>
          		</th> 



  			       <th> 
             
          			</th>
               </tr>
          </thead>
          <tbody>
        


          <tr>
             <th>Question</th>
             <th colspan="3">Scale</th>
          </tr> 



    <tr>
      <td><b>The instructor has provide me with a Course Outline at the beginning of the Semester.</b></td>

      <td> 
           <input type="radio" required="" name="qus1" id="qus1" value="1">1 
           <input type="radio" required="" name="qus1" id="qus1" value="2">2
           <input type="radio" required="" name="qus1" id="qus1" value="3">3 
           <input type="radio" required="" name="qus1" id="qus1" value="4">4   
           <input type="radio" required="" name="qus1" id="qus1" value="5">5 
      </td>
    </tr>

     <tr>
      <td><b>The recommended textbooks, references and/ or materials used for this Course were relevant.</b></td>

      <td> 
           <input type="radio" required="" name="qus2" id="qus2" value="1">1 
           <input type="radio" required="" name="qus2" id="qus2" value="2">2
           <input type="radio" required="" name="qus2" id="qus2" value="3">3 
           <input type="radio" required="" name="qus2" id="qus2" value="4">4   
           <input type="radio" required="" name="qus2" id="qus2" value="5">5 
      </td>
    </tr>

     <tr>
      <td><b>The instructor has explained ideas/ topics Lucidly(easily understandable).</b></td>

      <td> 
           <input type="radio" required="" name="qus3" id="qus3" value="1">1 
           <input type="radio" required="" name="qus3" id="qus3" value="2">2
           <input type="radio" required="" name="qus3" id="qus3" value="3">3 
           <input type="radio" required="" name="qus3" id="qus3" value="4">4   
           <input type="radio" required="" name="qus3" id="qus3" value="5">5 
      </td>
    </tr>

     <tr>
      <td><b>The presentations/ lectures of the instructor were of good quality.</b></td>

      <td> 
           <input type="radio" required="" name="qus4" id="qus4" value="1">1 
           <input type="radio" required="" name="qus4" id="qus4" value="2">2
           <input type="radio" required="" name="qus4" id="qus4" value="3">3 
           <input type="radio" required="" name="qus4" id="qus4" value="4">4   
           <input type="radio" required="" name="qus4" id="qus4" value="5">5 
      </td>
    </tr>

    
     <tr>
      <td><b>The instructor has related theories to practical and life-oriented examples.</b></td>

      <td> 
           <input type="radio" required="" name="qus5" id="qus5" value="1">1 
           <input type="radio" required="" name="qus5" id="qus5" value="2">2
           <input type="radio" required="" name="qus5" id="qus5" value="3">3 
           <input type="radio" required="" name="qus5" id="qus5" value="4">4   
           <input type="radio" required="" name="qus5" id="qus5" value="5">5 
      </td>
    </tr>

     <tr>
      <td><b>The instructor has been available to me for counselling.</b></td>

      <td> 
           <input type="radio"required="" name="qus6" id="qus6" value="1">1 
           <input type="radio"required="" name="qus6" id="qus6" value="2">2
           <input type="radio"required="" name="qus6" id="qus6" value="3">3 
           <input type="radio"required="" name="qus6" id="qus6" value="4">4   
           <input type="radio"required="" name="qus6" id="qus6" value="5">5 
      </td>
    </tr>

    <tr>
      <td><b>The instructor has covered the syllabus/ metarials sufficently.</b></td>

      <td> 
           <input type="radio"required="" name="qus7" id="qus7" value="1">1 
           <input type="radio"required="" name="qus7" id="qus7" value="2">2
           <input type="radio"required="" name="qus7" id="qus7" value="3">3 
           <input type="radio"required="" name="qus7" id="qus7" value="4">4   
           <input type="radio"required="" name="qus7" id="qus7" value="5">5 
      </td>
    </tr>

     <tr>
      <td><b>The examinations reflected the materials taught in the course.</b></td>

      <td> 
           <input type="radio"required="" name="qus8" id="qus8" value="1">1 
           <input type="radio"required="" name="qus8" id="qus8" value="2">2
           <input type="radio"required="" name="qus8" id="qus8" value="3">3 
           <input type="radio"required="" name="qus8" id="qus8" value="4">4   
           <input type="radio"required="" name="qus8" id="qus8" value="5">5 
      </td>
    </tr>

     <tr>
      <td><b>The instructor has graded/ marked the examination papers fairly.</b></td>

      <td> 
           <input type="radio" required="" name="qus9" id="qus9" value="1">1 
           <input type="radio" required="" name="qus9" id="qus9" value="2">2
           <input type="radio" required="" name="qus9" id="qus9" value="3">3 
           <input type="radio" required="" name="qus9" id="qus9" value="4">4   
           <input type="radio" required="" name="qus9" id="qus9" value="5">5 
      </td>
    </tr>

     <tr>
      <td><b>I would recommend the instructor to other students.</b></td>

      <td> 
           <input type="radio"required="" name="qus10" id="qus10" value="1">1 
           <input type="radio"required="" name="qus10" id="qus10" value="2">2
           <input type="radio"required="" name="qus10" id="qus10" value="3">3 
           <input type="radio"required="" name="qus10" id="qus10" value="4">4   
           <input type="radio"required="" name="qus10" id="qus10" value="5">5 
      </td>
    </tr>

	
 
      
    </tbody>
</table>



 		<textarea rows="4" cols="130" id="Comment" name="Comment" placeholder="Please give your general obserbation(s) about the Course teacher:">
 			
		</textarea>
        <br>

    <button type="submit" value="submit" name="submit" class="btn btn-primary">Submit</button>
    </form>

      </div>
    </div>
  </div>
</div>



<div class="col-lg-2">
  <b>Please read the following statements and provide your best opinion for each item on a 5-point scale as:</b> <br>

  <table border="2px" style="width: 100%;">
    <tr>
      <th>Satements</th>
      <th style="text-align: center;">Scale</th>
    </tr>
    <tr>
      <td>Strongly Agree</td>
      <td style="text-align: center;">5</td>
    </tr>
    <tr>
      <td>Agree</td>
      <td style="text-align: center;">4</td>
    </tr>
    <tr>
      <td>Neutral</td>
      <td style="text-align: center;">3</td>
    </tr>
    <tr>
      <td>Disagree</td>
      <td style="text-align: center;">2</td>
    </tr>
    <tr>
      <td>Strongly Disagree</td>
      <td style="text-align: center;">1</td>
    </tr>
  </table>
</div>




</div>



@endsection 