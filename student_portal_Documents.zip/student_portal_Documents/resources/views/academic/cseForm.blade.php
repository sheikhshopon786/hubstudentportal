@extends('academic.academicOffice')
@section('content')

  <div class="row">
    <div class="col-md-12" style="text-align: center; background: #2d2e30; color: white; padding: 5px; margin-bottom: 5px;">
     <h1><b>Computer Science & Engineering Form Section</b></h1>    </div>

 


 <!-- form start-1 -->
            <div class="col-md-6">
            <!-- general form elements -->
           <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Student Admission Form</b></h5>
    </div>
              <!-- /.card-header -->

              <!-- form start-->
              <form action="{{route('studentInformationInsert')}}" method="post" 
      enctype="multipart/form-data" role="form">
       {{csrf_field()}}
                <div class="card-body">
                   
                  <div class="form-group">
                    <label for="ID">ID</label>
              <input type="text" class="form-control" id="ID" placeholder=" ID" name="ID">
                  </div>

                  <div class="form-group">
                    <label for="FirstName">First Name</label>
              <input type="text" class="form-control" id="FirstName" placeholder="First Name" name="FirstName">
              </div>


                  <div class="form-group">
                    <label for="LastName">Last Name</label>
              <input type="text" class="form-control" id="LastName" placeholder="Last Name" name="LastName">
                  </div>


                  <div class="form-group">
                    <label for="PresentAddress">Present Address</label>
              <input type="text" class="form-control" id="PresentAddress" placeholder=" Present Address" name="PresentAddress">
                  </div>


                  <div class="form-group">
                    <label for="ParmanentAddress">Parmanent Address</label>
              <input type="text" class="form-control" id="ParmanentAddress" placeholder=" Parmanent Address" name="ParmanentAddress">
                  </div>

                  <div class="form-group">
                    <label for="FatherName">Father's Name</label>
              <input type="text" class="form-control" id="FatherName" placeholder=" Father's Name" name="FatherName">
                  </div>

                  <div class="form-group">
                    <label for="MotherName">Mother's Name</label>
              <input type="text" class="form-control" id="MotherName" placeholder=" Mother's Name" name="MotherName">
                  </div>

                  <div class="form-group">
                    <label for="Phone">Phone</label>
              <input type="text" class="form-control" id="Phone" placeholder=" Phone" name="Phone">
                  </div>

                  <div class="form-group">
                    <label for="Email">Email</label>
              <input type="text" class="form-control" id="Email" placeholder=" Email" name="Email">
                  </div>

                  <div class="form-group">
                    <label for="Department">Department</label>
              <input type="text" class="form-control" id="Department" placeholder=" Department" name="Department">
                  </div>

                  <div class="form-group">
                    <label for="Batch">Batch</label>
              <input type="text" class="form-control" id="Batch" placeholder=" Batch" name="Batch">
                  </div>

               <div class="form-group">
                    <label for="DOB">Date of Birth</label>
              <input type="text" class="form-control" id="DOB" placeholder=" Date of Birth" name="DOB">
                  </div>
                  

                   <div class="form-group">
                    <label for="BG">Blood Group</label>
              <input type="text" class="form-control" id="BG" placeholder=" BG" name="BG">
                  </div>


                  <div class="form-group">
                    <label for="Religion">Religion</label>
              <input type="text" class="form-control" id="Religion" placeholder=" Religion" name="Religion">
                  </div>

                  <div class="form-group">
                    <label for="Nationality">Nationality</label>
              <input type="text" class="form-control" id="Nationality" placeholder=" Nationality" name="Nationality">
                  </div>

                  

                  <div class="form-group">
                    <label for="Password">Password</label>
              <input type="Password" class="form-control" id="Password" placeholder=" Password" name="Password">
                  </div>


               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->



<!-- form start-2 -->
  <div class="col-md-6">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Upload Course List</b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
              <form action="{{route('store')}}" method="post" 
      enctype="multipart/form-data" role="form">
       {{csrf_field()}}
                <div class="card-body">

                  <div class="form-group"> 
              <label for="session">Session</label>
              <input type="text" class="form-control" id="session" placeholder="Session" name="session">   
                  </div>

                  <div class="form-group">
              <label for="semester">Semester</label>
              <input type="text" class="form-control" id="semester" placeholder="Semester" name="semester">
                  </div>

                  <div class="form-group">
                    <label for="course_code">Course Code</label>
              <input type="text" class="form-control" id="course_code" placeholder=" Course code" name="course_code">
                  </div>

                  <div class="form-group">
                    <label for="course_title">Course Tittle</label>
              <input type="text" class="form-control" id="course_title" placeholder="Course Tittle" name="course_title">
              </div>



                  <div class="form-group">
                    <label for="section">Section</label>
              <input type="text" class="form-control" id="section" placeholder="Section" name="section">
                  </div>


                  <div class="form-group"> 
              <label for="credit_hour">Credit Hour </label>
              <input type="text" class="form-control" id="credit_hour" placeholder="Credit Hour" name="credit_hour">   
                  </div>

          
                  <div class="form-group">
              <label for="department">Department</label>
              <input type="text" class="form-control" id="department" placeholder="department" name="department">
                  </div>

                  <div class="form-group">
                    <label for="teacher_name">Teacher Name</label>
              <input type="text" class="form-control" id="teacher_name" placeholder=" Teacher Name" name="teacher_name">
                  </div>

                  <div class="form-group">
                    <label for="day">Day</label>
              <input type="text" class="form-control" id="day" placeholder="Day" name="day">
              </div>



                  <div class="form-group">
                    <label for="time">Time</label>
              <input type="time" class="form-control" id="time" placeholder="Time" name="time">
                  </div>


                  <div class="form-group"> 
              <label for="room_no">Room No</label>
              <input type="text" class="form-control" id="room_no" placeholder="Room No" name="room_no">   
                  </div>





               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->








            <!-- form start-3 -->
            <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Admission</h3>
              </div>
              <!-- /.card-header -->

              <!-- form start-->
              <form action="{{route('studentListstore')}}" method="post" 
      enctype="multipart/form-data" role="form">
       {{csrf_field()}}
                <div class="card-body">
                   
                  <div class="form-group">
                    <label for="ID">ID</label>
              <input type="text" class="form-control" id="ID" placeholder=" ID" name="ID">
                  </div>

                  <div class="form-group">
                    <label for="FirstName">First Name</label>
              <input type="text" class="form-control" id="FirstName" placeholder="First Name" name="FirstName">
              </div>



                  <div class="form-group">
                    <label for="LastName">Last Name</label>
              <input type="text" class="form-control" id="LastName" placeholder="Last Name" name="LastName">
                  </div>

               
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->














    <div class="col-md-6">
            <!-- general form elements 3 -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Quick Example</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">File input</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="exampleInputFile">
                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                      </div>
                      <div class="input-group-append">
                        <span class="input-group-text" id="">Upload</span>
                      </div>
                    </div>
                  </div>
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>



    <div class="col-md-6">
            <!-- general form elements 3 -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Quick Example</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">File input</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="exampleInputFile">
                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                      </div>
                      <div class="input-group-append">
                        <span class="input-group-text" id="">Upload</span>
                      </div>
                    </div>
                  </div>
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>

    </div>







@endsection