@extends('academic.academicOffice')
@section('content')

	<div class="col-md-12" style="text-align: center;">
		<h2><b>CSE Table List</b></h2>
	</div>

   <a href="{{url('/studentInformationList')}}" button type="button" class="btn btn-success btn-lg btn-block"><b>Student Information</b></button></a>
  <a href="{{url('/courseList')}}" button type="button" class="btn btn-primary btn-lg btn-block"><b>Course List</b></button></a>

  <a href="{{url('/courseRegistrationRoutine')}}" button type="button" class="btn btn-danger btn-lg btn-block">Course and Routine</button></a>
  <a href="{{url('/cseForm')}}" button type="button" class="btn btn-primary btn-lg btn-block">Button 4</button></a>

 	

@endsection