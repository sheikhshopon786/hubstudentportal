 
  

  <!-- Site footer -->
  <footer class="site-footer">
  	<div class="container">
  		<div class="row">
  			<div class="col-sm-12 col-md-4"style="text-align: center;">
  				<h6>Important Links</h6>
  				<p class="">
            
          
               <a href="https://www.hamdarduniversity.edu.bd" target="blank">Main Website</a><br>

               <a href="https://192.168.1.249:90" target="blank">Student Database</a>
          </p>
  			</div>

  			<div class="col-xs-12 col-md-4" style="text-align: center;">
  				<img src="images/hub_logo.png" width="60px">

  				<p>
  					Founded in 2012<br> 
            Hamdard University Bangladesh<br>
            Hamdard Nagar, Gazaria, Munshiganj<br>
            info@hub.edu
  				</p>
  			</div>

  			<div class="col-xs-12 col-md-4" style="text-align: center;">
  				<h6>Quick Links</h6>
  				<ul class="footer-links">
  					<li><a href="{{url('/about')}}">About Us</a></li>

  					<li><a href="{{url('/contact')}}">Contact Us</a></li>
  					 
  					<li><a href="{{url('/rulesAndRegulation')}}">Rules & Regulations</a></li>
  					 
  				</ul>
  			</div>
  		</div>
  		<hr>
  	</div>
  	<div class="container">
  		<div class="row">
  			
  			<div class="col-md-4 col-sm-6 col-xs-12">
  				<ul class="social-icons" style="text-align: left;">
  					<li><a class="facebook" href="https://www.facebook.com/hubadmission/" target="blank"><i class="fa fa-facebook"></i></a></li>
  					
            <!--<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>-->

  					<li><a class="yotube" href="https://www.youtube.com/channel/UCD2K9QxzOdW2GJxfiMbAP2A" target="blank"><i class="fa fa-youtube"></i></a></li>
  				<!--	<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>-->   
  				</ul>
  			</div>

        <div class="col-md-8 col-sm-6 col-xs-12" style="text-align: right;">
          
         <!-- <p class="copyright-text">Copyright &copy; 2019 All Rights Reserved by 
            <a href="http://www.hamdarduniversity.edu.bd/" target="blank">HUB</a>.
          </p>-->

          <p class="copyright-text">Developed by 
            <a href="https://www.facebook.com/fatima.urmee08" target="blank" style="text-decoration: none">Fatima-Tuz-Zohra</a> &
            <a href="https://www.linkedin.com/in/Azharul-Islam-Shopon" target="blank" style="text-decoration: none">Azharul Islam</a>
            </p>

        </div>




  		</div>
  	</div>
  </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>