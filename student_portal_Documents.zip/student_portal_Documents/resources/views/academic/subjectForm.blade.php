@extends('academic.academicOffice')
@section('content')
 
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Course </b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->

<form action="{{route('subjectInput')}}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
       {{csrf_field()}}
      <div class="card-body">

          <div class="form-group">
              <label for="courseCodeTitile">Course Code & Titile</label>
              <input type="text" class="form-control" id="courseCodeTitile" placeholder="Course Code & Titile" name="courseCodeTitile" required="">
          </div>
 
               
      </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->

@endsection