@extends('academic.academicOffice')
@section('content')
     <div class="col-md-9" >
          <div class="widget" style="margin-left: 10px;">
          	
             
          	<div >
              <div class="row">

                    
      <form action="/ETeditsv" method="post" enctype="multipart/form-data" >
      	{{csrf_field()}}

  

 @foreach($data as $data)
 
 <div class="form-group">
    <label for="ID">ID</label>
    <input type="text" class="form-control" id="ID" placeholder="Tittle" name="ID" readonly value="{{$data->ID}}">
  </div>

  
  <div class="form-group">
    <label for="endTime">Please Enter The Date and Month</label>
    <input type="text" class="form-control" id="endTime" placeholder="Please Enter The Date and Month" name="endTime" value="{{$data->endTime}}">
  </div>

   

    
 

  <button type="submit" class="btn btn-primary">Save</button>

   @endforeach
</form>


		</div>
		</div>

		</div>
		</div>
		
@endsection		
