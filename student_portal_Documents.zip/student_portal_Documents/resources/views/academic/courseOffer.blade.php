@extends('academic.academicOffice')
@section('content')
 
<!-- form start-2 -->
 
<!-- form start-2 -->
  <div class="col-md-12">
            <!-- general form elements -->
    <div class="card card-primary">
      <div class="card-header"  >
        <h5 style="text-align: center;"><b>Course Offer & Class Schedule</b></h5>
    </div>
              <!-- /.card-header -->
              <!-- form start-1 -->
 <form action="{{route('store')}}" method="post" 
      enctype="multipart/form-data" role="form">
       {{csrf_field()}}
      <div class="card-body">



          <select value="semesterNo" name="semesterNo" id="semesterNo"      style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Semester
              </option>
              <option value="1">
                1
              </option>
              <option value="2">
                2
              </option>
              <option value="3">
                3
              </option>
              <option value="4">
                4
              </option>
              <option value="5">
                5
              </option>
              <option value="6">
                6
              </option>
              
              <option value="7">
                7
              </option>
              <option value="8">
                8
              </option>
           </select>


          

           <select value="courseCodeTitile" name="courseCodeTitile" id="courseCodeTitile" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Course Code & Titile
              </option>

            @foreach($subject as $subject)
              <option value="{{$subject->courseCodeTitile}}">
               {{$subject->courseCodeTitile}}
              </option>              
            @endforeach

             
           </select>



           <select value="section required" name="section" id="section" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Course Section
              </option>
              <option value="1">
                1
              </option>
              <option value="2">
                2
              </option>
              <option value="3">
                3
              </option>
              <option value="4">
                4
              </option>
           </select>

           <select value="credit_hour" required="" name="credit_hour" id="credit_hour" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Credit Hour
              </option>
              <option value="1.0">
                1.0
              </option>
              <option value="1.5">
                1.5
              </option>
              <option value="3.0">
                3.0
              </option>
              <option value="6.0">
                6.0
              </option>

           </select>

           <select value="department" required="" name="department" id="department" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
              <option selected="" disabled="">
                Select Department
              </option>
              
               @foreach($Department as $Department)
              <option value="{{$Department->departmentName}}">
               {{$Department->departmentName}}
              </option>              
            @endforeach
              
           </select>

           <select value="teacher_name" name="teacher_name" id="teacher_name" style="width: 100%; height: 10%;" class="mb-2 form-control-lg form-control">
               <option selected="" disabled="">
                Select Teacher
              </option>
              
               @foreach($teacher as $teacher)
              <option value="{{$teacher->ShortName}}">
               {{$teacher->ShortName}}
              </option>              
            @endforeach
           </select>

                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
        </div>
  <!-- /.card -->
 



  <div class="col-lg-12">
        
           
                 
                 
  <div class="main-card mb-3 card">
    <div class="card-body"><h5 class="card-title">Registration End Time</h5>
      <div class="">
        <table class="mb-0 table">
          <thead>
            <tr>               
              <th>Last Date</th>
              <th>Update</th>
             
            </tr>
          </thead>
          <tbody>
             
           @foreach($data as $data)
        <tr>
    
                        
          <td>{{$data->endTime}}</td>
           
                  <td> 
            <a href="{{url('/ETeditreq',$data->ID)}}" class="btn btn-primary">Update</a>
          </td> 
           
       
        </tr>                  
      @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

 

 
@endsection