<?php 

namespace App\Http\Controllers;

use App\result_verification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
  
class examController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function examOffice()
    { 

           $value = session('examchklogin');

       if ($value!=0) {

        return view('exam.examIndex');
        }
        else

       {
         return redirect ('/');
       }

    }



//Exam Registration
 public function examRegisterFormEntry(Request $request)
    {


        $users = DB::insert('insert into examlogin (type,email,password,userID) values (?,?,?,?)',[$request->type,$request->email,$request->password,$request->userID]);

        return view ('exam.examRegisterForm');
    }


    public function examRegisterForm()
    {
        return view ('exam.examRegisterForm');
    }

//Academic Admin Login


    public function examLogin(Request $request)
    {

        $examLogin= DB::select('select count(*) chk from examlogin where userID=? and password=?', [$request->userID,$request->password]);


        foreach ($examLogin as $key ) {


            if ($key->chk==1) {
                 

                 session(['examchklogin' => $request->userID]);


             return redirect  ('/examOffice');

         }else
         {
             
            session(['examchklogin' => 0]);
             session()->flash('examchklogin','Login Faild');

           return view ('exam.examLoginForm');
       }

   }


}

public function examLoginForm()
{
    return view ('exam.examLoginForm');
}


public function examLogout()
{
    session(['examchklogin' => 0]);
    return redirect('/');
}











//Student Information

     public function studentInformationExam()
    {

$studentInformationList = DB::select('select * from admission', []);


session()->flash('FirstName','stuentInformationList');

           return view ('exam.studentInformationExam')->with('studentInformationList',$studentInformationList);
         
    }

 

//For Running Student

//Student Result Scheme/GPA in Chart
public function resultScheme(Request $request)
    {
        $value = session('chklogin');

        $cs=DB::select('select * from courseregistration where student_id='.$value);
        $ts=DB::select('select * from teachers_evolution where student_id='.$value);
        
if (count($cs)>count($ts)) {
   return redirect('/teachersEvolutionTable');
}
        

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

 
 $resultScheme = DB::select('select * from resultScheme where student_id=?', [$value]);

 }
       return view('exam.resultScheme')->with('resultScheme',$resultScheme)->with('studentName',$studentName)->with('studentPicture',$studentPicture);
    }


//Student Result/Grade Sheet In Table

    public function studentResult(Request $request)
    {
 
   $data = DB::select('select * from studentresult where student_id=0', []);
 
 

       return view('exam.studentResult')->with('data',$data);
    }





      public function studentResultSearch(Request $request)
        {

            $data = DB::select('select * from studentresult where student_id=?', [$request->SRsearch]);


            return view ('exam.studentResult')->with('data',$data);

         
        }



//Result Update
 

           public function SReditreq($id)
    {
     
        $data = DB::select('select * from studentresult where id=?',[$id]);
      //->with('data',$data);  
      return view('exam.stdResultInput')->with('data',$data);    
        
    }

public function SReditsv(Request $request)
    {
            
            if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);
 // for convert  image to text

                 $feedback=DB::update('update studentresult set student_id=?,semester=?,courseCodeTitile=?,credit_hour=?,Grade=?,GradePoint=? image=? where ID=?',[$request->student_id,$request->semester,$request->courseCodeTitile,$request->credit_hour,$request->Grade,$request->GradePoint,$fileName,$request->ID]);


                 $studentInformationList= DB::insert('insert into completeresult (student_id,courseCodeTitile,credit_hour,Grade,GradePoint) values (?,?,?,?,?)',[$request->student_id,$request->courseCodeTitile,$request->credit_hour,$request->Grade,$request->GradePoint]);

            }else
            {
                $feedback=DB::update('update studentresult set student_id=?,semester=?,courseCodeTitile=?,credit_hour=?,Grade=?,GradePoint=?  where ID=?',[$request->student_id,$request->semester,$request->courseCodeTitile,$request->credit_hour,$request->Grade,$request->GradePoint,$request->ID]);


                 $studentInformationList= DB::insert('insert into completeresult (student_id,courseCodeTitile,credit_hour,Grade,GradePoint) values (?,?,?,?,?)',[$request->student_id,$request->courseCodeTitile,$request->credit_hour,$request->Grade,$request->GradePoint]);

            }


         
          return redirect('/studentResult');
    }
  




//Live Result

public function liveResultInputPage(Request $request)
    {

$data = DB::select('select * from liveresult', []);
 
           return view ('exam.liveResultInputPage')->with('data',$data); 

    }



 public function StdLRSearch(Request $request)
        {
          $data = DB::select('select * from liveresult where student_id=?', [$request->stdLRSearch]); 

            return view ('exam.liveResultInputPage')->with('data',$data);

         
        }



           public function Lieditreq($id)
    {
     
        $data = DB::select('select * from liveresult where id=?',[$id]);
      //->with('data',$data);  
      return view('exam.liveResultInput')->with('data',$data);    
        
    }


public function Lieditsv(Request $request)
    {
            
            if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);
 // for convert  image to text

                 $feedback=DB::update('update liveresult set student_id=?,semester=?,courseCodeTitile=?,department=?,credit_hour=?,section=?,teacher_name=?,Quiz1=?,Quiz2=?,Average=?,MidTerm=?,Improvement=?, image=? where ID=?',[$request->student_id,$request->semester,$request->courseCodeTitile,$request->department,$request->credit_hour,$request->section,$request->teacher_name,$request->Quiz1,$request->Quiz2,$request->Average,$request->MidTerm,$request->Improvement,$fileName,$request->ID]);

            }else
            {
                $feedback=DB::update('update liveresult set student_id=?,semester=?,courseCodeTitile=?,department=?,credit_hour=?,section=?,teacher_name=?,Quiz1=?,Quiz2=?,Average=?,MidTerm=?,Improvement=?  where ID=?',[$request->student_id,$request->semester,$request->courseCodeTitile,$request->department,$request->credit_hour,$request->section,$request->Department,$request->Quiz1,$request->Quiz2,$request->Average,$request->MidTerm,$request->Improvement,$request->ID]);

            }
         
          return redirect('/liveResultInputPage');
    }
    
   








    public function liveResult(Request $request)
    {

        $value = session('chklogin');

       if ($value!=0) {
         
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
 
    $liveResult = DB::select('select * from liveResult where ID=0', [$value]);
 

         $semester = DB::select('select distinct semester from liveResult where student_id=?', [$value]);
 

  $LR = DB::select('select * from liveResult where ID=?', [$request->ID]);
 
 
 }
       return view('exam.liveResult')->with('liveResult',$liveResult)->with('semester',$semester)->with('LR',$LR)->with('studentName',$studentName)->with('studentPicture',$studentPicture);
    }
    

//Live Result Search step-1
     public function liveResultSearch(Request $request)
        { 
            $value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

            $liveResult = DB::select('select * from liveResult where (Semester=? and student_id=?)',[$request->Semester,$value]);

           

         $semester = DB::select('select distinct semester from liveResult where student_id=?', [$value]);

       $LR = DB::select('select * from liveResult where ID=?', [$request->ID]);
 
 
    } 
            
            return view ('exam.liveResult')->with('liveResult',$liveResult)->with('semester',$semester)->with('LR',$LR)->with('studentName',$studentName)->with('studentPicture',$studentPicture);

         
        }






    

//Student information Edit & Delete
 


           public function Leditreq($ID)
    {
        

$value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

        $liveResult = DB::select('select * from  liveresult where ID=0',[]);
      //->with('data',$data);  

        
         $semester = DB::select('select * from liveResult where student_id=?', [$value]);


           $LR = DB::select('select * from liveResult where ID=?', [$ID]);
 
}
      return view('exam.liveResult2')->with('liveResult',$liveResult)->with('semester',$semester)->with('LR',$LR)->with('studentName',$studentName)->with('studentPicture',$studentPicture);
    }

 


           public function Ldelreq($student_id)
    {
     
        $liveResult = DB::delete('delete from  liveresult where student_id=?',[$student_id]);
      //->with('data',$data);  
      return redirect('/liveResult');
        
    }

      public function Leditsv(Request $request)
    {
            
           if ($request->hasFile('image')) // for store image to file system
            {
                $image=$request->file('image');
                $imgName=time().'.'.$image->getClientOriginalExtension();
                $img = Image::make($request->file('image')->getRealPath());
                Image::make($img)->save('Images/'.$imgName)->resize(300, 200);
                 $base64 = base64_encode($img); // for convert  image to text

                 $feedback=DB::update('update  liveresult set semseter=?,courseCodeTitile=?,department=?,credit_hour=?,section=?,teacher_name=?,Quiz1=?,Quiz2=?,Average=? where student_id=?',[$request->semseter,$request->courseCodeTitile,$request->department,$request->credit_hour,$request->section,$request->teacher_name,$request->Quiz1,$request->Quiz2,$request->Average,$request->student_id]);

            }else
            {
                $feedback=DB::update('update  liveresult set semseter=?,courseCodeTitile=?,department=?,credit_hour=?,section=?,teacher_name=?,Quiz1=?,Quiz2=?,Average=? where student_id=?',[$request->semester,$request->courseCodeTitile,$request->department,$request->credit_hour,$request->section,$request->teacher_name,$request->Quiz1,$request->Quiz2,$request->Average,$request->student_id]);

            }

         
          return redirect('/studentInformationList');
    }

 






//Live Result Search step-2 Action


          

   







//For Alumni Student

//Result Verification Start

    //For Verify Result Input Form Start
    public function resultVerifyFormPage()
    {
        return view('exam.resultVerifyFormPage');
    }

 public function resultVerifyForm(Request $request)

   {

            $resultVerifyForm = DB::insert('insert into result_verification (student_id,Name,DepartmentName,CGPA,PassingYear,SerialNumber) values (?,?,?,?,?,?)',[$request->student_id,$request->Name,$request->DepartmentName,$request->CGPA,$request->PassingYear,$request->SerialNumber]);
            
            if ($request->btn=='btn') {
             session(['msg'=>'Data Inserted Successfully']);
        }
 
           return view ('exam.resultVerifyFormPage');
    }
//For Verify Result Input Form End


    
      public function resultVerifyList()
    {

$data = DB::select('select * from result_verification where student_id=0', []);

           return view ('exam.resultVerify')->with('data',$data);       
    }
     

// search for result verification

      public function resultVerifySearch(Request $request)
        {

            $data = DB::select('select * from result_verification where student_id=?', [$request->search]);

            return view ('exam.resultVerify')->with('data',$data);

         
        }

//Result Verification End


//Admit Card with course
    
 

//Admit Card Serial

 public function admitSerial(Request $request)
    {
        $value = session('examchklogin');

       if ($value!=0) 
         $admitSerialForExam=DB::select('select * from admitserial where student_id=?', [$value]);

        return view('exam.admitSerial')->with('admitSerialForExam',$admitSerialForExam);
    }





//Certificate and Transcript Apply

 public function certificate(Request $request)
    {

        $certificate = DB::insert('insert into certificate (ApplyDate,DaliveryDate,AlternateEmail,MobileNumber, PaidAmount,PaidDate,PaymentMedia,MoneyReceipt,Document,DocumentType,NumberOfCopy,UrgencyType,student_id) values (?,?,?,?,?,?,?,?,?,?,?,?,?)',[$request->ApplyDate,$request->DaliveryDate,$request->AlternateEmail,$request->MobileNumber,$request->PaidAmount,$request->PaidDate,$request->PaymentMedia,$request->MoneyReceipt,$request->Document,$request->DocumentType,$request->NumberOfCopy,$request->UrgencyType,session('chklogin')]);

 $value = session('chklogin');

        if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
         
      $stdInfo=DB::select('select * from admission where student_id=?', [$value]);

}
        return view('exam.certificate')->with('stdInfo',$stdInfo) ->with('studentName',$studentName)->with('studentPicture',$studentPicture);

    }



 public function CertificateStdInfo(Request $request)
    {
         $value = session('chklogin');

 if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
         
      $stdInfo=DB::select('select * from admission where student_id=?', [$value]);

}
        return view('exam.certificate')->with('stdInfo',$stdInfo)->with('studentName',$studentName)->with('studentPicture',$studentPicture);

    }




//For Office
public function certificateApplicationList(Request $request)
    { 
         
      $certificateApplicationList=DB::select('select * from certificate', []);


        return view('exam.certificateApplicationList')->with('certificateApplicationList',$certificateApplicationList);
    }




                         
 





    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
