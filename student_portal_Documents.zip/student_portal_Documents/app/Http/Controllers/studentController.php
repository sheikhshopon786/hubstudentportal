<?php 

namespace App\Http\Controllers;

use App\result_verification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class studentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

//Student Main Page
     public function studentpart()
    {
        return view('student.studentIndex');
    }

//Student Side Bar
     public function studentSidebar()
    {
        return view('student.studentSidebar');
    }



   

   //Class Routine
    public function classRoutine(request $request)
    {
         $value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);


          $one = DB::select('select * from routine where ID and Department=?', [session('dept')]);
           
          $two = DB::select('select * from routine where ID and Department=?', [session('dept')]);
           
          $three = DB::select('select * from routine where ID and Department=?', [session('dept')]);
           
          $four = DB::select('select * from routine where ID and Department=?', [session('dept')]);
           
          $five = DB::select('select * from routine where ID and Department=?', [session('dept')]);
           
          $six = DB::select('select * from routine where ID and Department=?', [session('dept')]);
          
          $seven = DB::select('select * from routine where ID and Department=?', [session('dept')]);

          $teachersname = DB::select('select * from teachersname', [session('dept')]);

          
           return view ('student.classRoutine')->with('studentName',$studentName)->with('studentPicture',$studentPicture)->with('one',$one)->with('two',$two)->with('three',$three)->with('four',$four)->with('five',$five)->with('six',$six)->with('seven',$seven)->with('teachersname',$teachersname);
        }

            else

       {
         return redirect ('/login');
       }        
    }


 


//Course Registration Approval Start
        public function courseapproval($student_id)
    {
           
        $studentInformationList = DB::update('update courseapproval set courseapproval=1  where student_id=?',[$student_id]);
        
      
      return redirect ('/courseRegistrationPage');   
        
    }


//Course Registration Approval End



  
 public function courseRegistrationPage(Request $request)
 {
   
  $value = session('chklogin');
  
       if ($value!=0) {

          

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
    
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

  
 

 $extraCourseLists  = DB::select('select * from  courseregistration where student_id=?', [$value]);
 
 $extraCourseList  = DB::select('select * from courseandroutine where ID=0', []);

$endTime = DB::select('select * from endTTime');
foreach ($endTime as $key ) {
 $last_date=$key->endTime;
}

$curr_date=date('dm');

if ($curr_date>=$last_date) {
    
   // $data = DB::select('select  * from courseregistration where student_id=?',[session('chklogin')]);


    if (count($extraCourseLists)>0) {
        return redirect ('courseListAfterReg');

    }
    else 
    {
       return redirect('CourseRegTimeOut');
    }
}

 $semesterNo = DB::select('select distinct semesterNo from courseandroutine where (department=?)',[session('dept')]);

$studentCourseRegistrationList = DB::select('select * from season', []);



 $studentCourseRegistrationList = DB::select('select * from courseregistration_temp where transfer=0 and student_id=?', [session('chklogin')]);




}




$courseapproval = DB::select('select * from courseapproval where student_id=? and courseapproval=1', [$value]);

foreach ($courseapproval as $key ) {
 $courseapproval=$key->courseapproval;
}

$Approval=('1');
       

if ($Approval==$courseapproval) {
    
   // $data = DB::select('select  * from courseregistration where student_id=?',[session('chklogin')]);


       
      

        return view ('student.courseRegistrationPage')->with('extraCourseList',$extraCourseList)->with('semesterNo',$semesterNo)->with('studentCourseRegistrationList',$studentCourseRegistrationList)->with('studentName',$studentName)->with('studentPicture',$studentPicture)->with('studentCourseRegistrationList',$studentCourseRegistrationList);  
    }

    else
    {
      return redirect ('paymentMessage');
    }

}


//Cencel Button 
  
           //public function Cencel($Id)
   // {
     
       // $extraCourseList = DB::delete('DELETE FROM courseregistration_temp;',[$Id]);

       //return redirect('/studentProfile');
        
   // }
      public function courseCencelReq($Id)
    {
     
        $studentCourseRegistrationList = DB::delete('delete from courseregistration_temp',[$Id]);
      //->with('data',$data);  
      return redirect('/courseRegistrationPage');
        
    }

    




   public function paymentMessage()
    {
      $value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
}
        return view('account.paymentMessage')->with('studentName',$studentName)->with('studentPicture',$studentPicture);
    } 




    

         public function courseRegApproval($student_id)
    {
      
        
        $studentInformationList = DB::update('update courseapproval set courseapproval=1  where student_id=?',[$student_id]);

        
      return redirect ('/studentInformationAcc');   
        
    }

    






    
    public function courseRegistration(Request $request)
    {

   

            DB::insert("INSERT INTO courseregistration_temp (courseCodeTitile,semesterNo,semester,credit_hour,department)
            SELECT courseCodeTitile,semesterNo,semester,credit_hour,department FROM courseandroutine WHERE courseandroutine.semesterNo=? and courseandroutine.department=?",[$request->semesterNo,session('dept')]);

            $extraCourseList= DB::insert("INSERT INTO courseregistration_temp (courseCodeTitile,semesterNo,semester,credit_hour,department)
            SELECT courseCodeTitile,semesterNo,semester,credit_hour,department FROM courseandroutine WHERE courseandroutine.courseCodeTitile=?",[$request->courseCodeTitile]);


             DB::update("UPDATE `courseregistration_temp`a set a.transfer=0,a.Grade='Incomplete',a.GradePoint='Incomplete'");

              DB::update('UPDATE `admission`a,courseregistration_temp b set b.student_id=a.student_id where a.student_id=?', [session('chklogin')]);

 

              

            DB::update("UPDATE `season`a,courseregistration_temp b set b.semester=a.semester");



           /* $data = DB::insert('insert into courseregistrationForAcademic(Id,Fname) values(?,?)',[$request->Id,$request->Fname]);*/

 
         return redirect('/courseRegistrationPage');
    }





//Student Course Registration Process
  public function studentCourseRegistrationList(Request $request)
    {

      $value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);


$studentCourseRegistrationList = DB::select('select * from courseregistration_temp where transfer=0 and student_id=?', [session('chklogin')]);



if ($request->submit) {

     
      
      $fb=DB::insert('insert into studentresult(semester,courseCodeTitile,credit_hour,semesterNo,student_id,Grade,GradePoint) select semester,courseCodeTitile,credit_hour,semesterNo,student_id,Grade,GradePoint from courseregistration_temp where transfer=0 and student_id=?', [session('chklogin')]);
      

     $fb=DB::insert('insert into liveresult(semester,courseCodeTitile,student_id) select semester,courseCodeTitile,student_id from courseregistration_temp where transfer=0 and student_id=?', [session('chklogin')]);
    

    $fb=DB::insert('insert into courseregistration(semester,courseCodeTitile,student_id) select semester,courseCodeTitile,student_id from courseregistration_temp where transfer=0 and student_id=?', [session('chklogin')]);
    
 
    $fb=DB::insert('insert into courseregistrationforacademic(semester,courseCodeTitile,credit_hour,student_id) select semester,courseCodeTitile,credit_hour,student_id from courseregistration_temp where transfer=0 and student_id=?', [session('chklogin')]);

    $fb=DB::delete('delete from courseregistration_temp where transfer=0 and student_id=?', [session('chklogin')]);

         return redirect('/courseRegistrationPage');

    
}

}

           return view ('student.studentCourseRegistrationList')->with('studentCourseRegistrationList',$studentCourseRegistrationList)->with('studentName',$studentName)->with('studentPicture',$studentPicture);       
    }  
//Student Course Registration Process End


//Student Course List After Registration Start

public function courseListAfterReg()
    {
$value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

           $courseListAfterReg= DB::select('select * from courseregistration where student_id=? and CourseApproval=1', [$value]);


          

}
           return view ('student.courseListAfterReg')->with('courseListAfterReg',$courseListAfterReg)->with('studentName',$studentName)->with('studentPicture',$studentPicture);       
    }

//Student Course List After Registration End
 


//Course Registration Time Out Start

    public function CourseRegTimeOut()
    {
      $value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
}
        return view('student.CourseRegTimeOut')->with('studentName',$studentName)->with('studentPicture',$studentPicture);
    } 

//Course Registration Time Out End


//Course Registration List Edit & Delete Start


           public function courseEditReq($Id)
    {
     $value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

        $studentCourseRegistrationList = DB::select('select * from courseregistration_temp where Id=?',[$Id]);
      }
     
      //->with('data',$data);  
      return view('academic.courseEditReq')->with('studentCourseRegistrationList',$studentCourseRegistrationList)->with('studentName',$studentName)->with('studentPicture',$studentPicture);
   
    }


           public function courseDelReq($Id)
    {
     
        $studentCourseRegistrationList = DB::delete('delete from courseregistration_temp where Id=?',[$Id]);
      //->with('data',$data);  
      return redirect('/courseRegistrationPage');
        
    }
 
      public function courseEditsv(Request $request)
    {
            
           if ($request->hasFile('image')) // for store image to file system
            {
                $image=$request->file('image');
                $imgName=time().'.'.$image->getClientOriginalExtension();
                $img = Image::make($request->file('image')->getRealPath());
                Image::make($img)->save('Images/'.$imgName)->resize(300, 200);
                 $base64 = base64_encode($img); // for convert  image to text

                 $feedback=DB::update('update courseregistration_temp set courseCodeTitile=? where Id=?',[$request->courseCodeTitile,$request->Id]);

            }else
            {
                $feedback=DB::update('update courseregistration_temp set courseCodeTitile=?  where Id=?',[$request->courseCodeTitile,$request->Id]);

            }

         
          return redirect('/courseRegistrationPage');
    }

//Course Registration List Edit & Delete End

//Extra Course List

     public function extraCourseList(Request $request)
    {
  
         $value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
          


            $extraCourseList = DB::select('select * from courseandroutine where (department=?)',[session('dept')]);


          $semesterNo = DB::select('select distinct semesterNo from courseandroutine where (department=?)',[session('dept')]);

          $studentCourseRegistrationList = DB::select('select * from courseregistration_temp where transfer=0 and student_id=?', [session('chklogin')]);


           

}
       return view('student.courseRegistrationPage')->with('studentName',$studentName)->with('studentPicture',$studentPicture)->with('extraCourseList',$extraCourseList)->with('semesterNo',$semesterNo)->with('studentCourseRegistrationList',$studentCourseRegistrationList);


    }

 

  

 
// Student course Complete  list

public function completeCourse()
    
 {
$value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

          $courseListAfterReg = DB::select('select * from  completeresult where student_id=?', [$value]);

          $creditComplete = DB::select('SELECT SUM(credit_hour) AS CreditComplete FROM completeresult where student_id=?',[$value]);

          $totalCredit = DB::select('select * from admission where student_id=?', [$value]);


           $semesterNo1 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=1 and student_id=?', [session('chklogin')]);

          $semesterNo2 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=2 and student_id=?', [session('chklogin')]);

          $semesterNo3 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=3 and student_id=?', [session('chklogin')]);

          $semesterNo4 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=4 and student_id=?', [session('chklogin')]);

          $semesterNo5 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=5 and student_id=?', [session('chklogin')]);

          $semesterNo6 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=6 and student_id=?', [session('chklogin')]);

          $semesterNo7 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=7 and student_id=?', [session('chklogin')]);

          $semesterNo8 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=8 and student_id=?', [session('chklogin')]);



}
           return view ('student.completeCoursePage')->with('courseListAfterReg',$courseListAfterReg)->with('studentName',$studentName)->with('studentPicture',$studentPicture)->with('creditComplete',$creditComplete)->with('totalCredit',$totalCredit)->with('semesterNo1',$semesterNo1)->with('semesterNo2',$semesterNo2)->with('semesterNo3',$semesterNo3)->with('semesterNo4',$semesterNo4)->with('semesterNo5',$semesterNo5)->with('semesterNo6',$semesterNo6)->with('semesterNo7',$semesterNo7)->with('semesterNo8',$semesterNo8);       
    }


// Student course Registration and List End


//Student Result/Grade Sheet In Table

    public function subjectResult(Request $request)
    {
  
         $value = session('chklogin');

        $cs=DB::select('select * from courseregistration where student_id='.$value);
        $ts=DB::select('select * from teachers_evolution where student_id='.$value);

      
 

    if (count($cs)>count($ts)) {
          

   return redirect('/teachersEvolutionTable');

   }


 
 

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

          $subjectResult = DB::select('select * from studentresult where student_id=0', [$value]);


          $totalCredit = DB::select('select * from admission where student_id=?', [$value]);


          $creditComplete = DB::select('SELECT SUM(credit_hour) AS CreditComplete FROM studentresult where student_id=?',[$value]);


          $SGPA = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semester=? and student_id=?', [$request->semester,session('chklogin')]);

          
           $semester = DB::select('select distinct semester from studentresult where student_id=?', [$value]);



}


       return view('student.subjectResult')->with('subjectResult',$subjectResult)->with('studentName',$studentName)->with('studentPicture',$studentPicture)->with('creditComplete',$creditComplete)->with('totalCredit',$totalCredit)->with('SGPA',$SGPA)->with('semester',$semester);


    }




 public function subjectResultSearch(Request $request)
    {
      $value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);


         $semester = DB::select('select distinct semester from studentresult where student_id=?', [$value]);







          $subjectResult = DB::select('select * from studentresult where (semester=? and student_id=?)',[$request->semester,$value]);









          $SGPA = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semester=? and student_id=?', [$request->semester,session('chklogin')]);
}
        return view('student.subjectResult')->with('studentName',$studentName)->with('studentPicture',$studentPicture)->with('semester',$semester)->with('subjectResult',$subjectResult)->with('SGPA',$SGPA);
    } 


        











//Student Profile
      public function studentProfile()
    {
/*

 $aproval= DB::select('select count(*) chk from tablname where userid=? ,aproval=1, function_name=? ', [$value,'studentProfile' );

*/

        $value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

          

          $studentProfile = DB::select('select * from admission where student_id=?', [$value]);


 
           return view ('student.studentProfile')->with('studentProfile',$studentProfile)->with('studentName',$studentName)->with('studentPicture',$studentPicture);
       }else
       {
         return redirect ('/login');
       }
         
    }





    public function proUpdateView()
    {

        $value = session('chklogin');

       if ($value!=0) {
          $studentProfile = DB::select('select * from admission where student_id=?', [$value]);
 
   $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
            
           return view('student.profileUpdate')->with('studentProfile',$studentProfile) ->with('studentName',$studentName)->with('studentPicture',$studentPicture);


             
       }else
       {
         return redirect ('/login');
       }

    }


    public function proUpdate(Request $request)
    {

         $value = session('chklogin');

          if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);

        $feedback=DB::update('update admission set FirstName=?,LastName=?,PresentAddress=?,ParmanentAddress=?,FatherName=?,MotherName=?,Phone=?,Email=?,Batch=?,DOB=?,BG=?,Religion=?,Nationality=?,image=?,password=md5(?) where student_id=?',[$request->FirstName,$request->LastName,$request->PresentAddress,$request->ParmanentAddress,$request->FatherName,$request->MotherName,$request->Phone,$request->Email,$request->Batch,$request->DOB,$request->BG,$request->Religion,$request->Nationality,$fileName,$request->password,$value]);
      }

      else{
        $feedback=DB::update('update admission set FirstName=?,LastName=?,PresentAddress=?,ParmanentAddress=?,FatherName=?,MotherName=?,Phone=?,Email=?,Batch=?,DOB=?,BG=?,Religion=?,Nationality=?,password=md5(?) where student_id=?',[$request->FirstName,$request->LastName,$request->PresentAddress,$request->ParmanentAddress,$request->FatherName,$request->MotherName,$request->Phone,$request->Email,$request->Batch,$request->DOB,$request->BG,$request->Religion,$request->Nationality,$request->password,$value]);
      }

        return redirect ('/studentProfile'); 
    }


//Student Name
   

//Student Profile End


 


 




    //end 




    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
