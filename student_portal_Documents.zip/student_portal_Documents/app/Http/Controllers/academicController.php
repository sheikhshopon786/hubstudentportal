<?php 

namespace App\Http\Controllers;
 
  
use App\result_verification;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\DB;
use file;
use Response;

class academicController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function academicOffice()
    {

        $value = session('academicchklogin');

       if ($value!=0) {
       

        return view('academic.academicIndex');
 }
        else

       {
         return redirect ('/');
       }
    
    }



 public function academicRegisterFormEntry(Request $request)
    {


        $users = DB::insert('insert into academiclogin (type,email,password,userID) values (?,?,?,?)',[$request->type,$request->email,$request->password,$request->userID]);

        return view ('admin.academicRegisterForm');
    }


    public function academicRegisterForm()
    {
        return view ('admin.academicRegisterForm');
    }

//Academic Admin Login


    public function academicLogin(Request $request)
    {

        $academicLogin= DB::select('select count(*) chk from academiclogin where userID=? and password=?', [$request->userID,$request->password]);


        foreach ($academicLogin as $key ) {


            if ($key->chk==1) {
                 

                 session(['academicchklogin' => $request->userID]);


             return redirect  ('/academicOffice');

         }else 
         {
             
            session(['academicchklogin' => 0]);
             session()->flash('academicchklogin','Login Faild');

           return view ('academic.academicLoginForm');
       }

   }


}

public function academicLoginForm()
{
    return view ('academic.academicLoginForm');
}


public function academicLogout()
{
    session(['academicchklogin' => 0]);
    
    return redirect('/');
}



    


//Admission

 
  public function studentInformationInsert(Request $request)

 
   {


    if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);

        DB::insert("insert into admission (student_id,FirstName,LastName,Gender,PresentAddress,ParmanentAddress,MotherName,FatherName,Phone,Email,Faculty,Department,Batch,DOB,BG,Religion,Nationality,image,password) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,md5(?))",[$request->student_id,$request->FirstName,$request->LastName,$request->Gender,$request->PresentAddress,$request->ParmanentAddress,$request->MotherName,$request->FatherName,$request->Phone,$request->Email,$request->Faculty,$request->Department,$request->Batch,$request->DOB,$request->BG,$request->Religion,$request->Nationality,$fileName,$request->password]);


             DB::insert("insert into courseapproval (student_id,courseapproval) values (?,0)",[$request->student_id,$request->courseapproval]);



        
        if ($request->btn=='btn') {
             session(['msg'=>'Your Data Successfully Inserted']);
        }



}
            

           return view ('academic.studentInformation');
    }






     public function studentInformationList()
    {

$studentInformationList = DB::select('select * from admission order by student_id', []);


session()->flash('FirstName','stuentInformationList');

           return view ('academic.studentInformationList')->with('studentInformationList',$studentInformationList);
         
    }


//Student Information Search
     public function stdInformationSearch(Request $request)
        {

            $studentInformationList = DB::select('select * from admission where student_id=?', [$request->stdSearch]);

            return view ('academic.studentInformationList')->with('studentInformationList',$studentInformationList);

         
        }

//End
    


 
//Start Course Registration Input & Output
 
 public function courseList()
    {

$data = DB::select('select * from courseandroutine', []);

           return view ('academic.courseList')->with('data',$data);
         
    }



//Course Offer
 public function store(Request $request)
    {
 
   
            $test = DB::insert('insert into courseandroutine (semesterNo, courseCodeTitile,section,credit_hour,department,teacher_name,day,starting_time,ending_time,room_no,reg_end_time) values (?,?,?,?,?,?,?,?,?,?,?)',[$request->semesterNo,$request->courseCodeTitile,$request->section,$request->credit_hour,$request->department,$request->teacher_name,$request->day,$request->starting_time,$request->ending_time,$request->room_no,$request->reg_end_time]);


     $fb=DB::insert('insert into courseregistration(department,credit_hour,section,teacher_name) select department,credit_hour,section,teacher_name from courseandroutine', [session('dept')]);


           return view ('academic.courseOffer');
    }


public function courseApproved()
    
 { 
 
      $studentInformationList=DB::select('select * from courseregistration', []);

           return view ('academic.courseApproved')->with('studentInformationList',$studentInformationList);
         
    }
                 
    



//Admit Approval For Academic Office
            public function approvalForCourse($student_id)
    {
      
        
        $studentInformationList = DB::update('update courseregistration set CourseApproval=1  where student_id=?',[$student_id]);

        
      return redirect ('/courseApproved');   
        
    }



public function CourseSearch(Request $request)
        {

            $studentInformationList = DB::select('select * from courseregistration where student_id=?', [$request->CourseSearch]);

            return view ('academic.courseApproved')->with('studentInformationList',$studentInformationList);

         
        }

//Subject



          public function subjectForm(Request $request)
    {
 
        return view ('academic.subjectForm');
    }


        public function subjectInput(Request $request)
    {

        $subjectForm = DB::insert('insert into subject (courseCodeTitile) values (?)',[$request->courseCodeTitile]);

        return view ('academic.subjectForm');
    }






//Course Offer
    public function courseOffer()


    {

        $subject = DB::select('select * from subject', []);


        $teacher = DB::select('select * from teachersname', []);

        $Department = DB::select('select * from Department', []);
         

         $data = DB::select('select * from endttime', []);

        return view ('academic.courseOffer')->with('subject',$subject)->with('teacher',$teacher)->with('Department',$Department)->with('data',$data); 

    }


 




           public function ETeditreq($ID)
    {
     
        $data = DB::select('select * from endttime where ID=?',[$ID]);
      //->with('data',$data);  
      return view('academic.RegEndTimeEdit')->with('data',$data);    
        
    }


 
    

    public function ETeditsv(Request $request)
    {
            
            if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);
 // for convert  image to text

                 $data=DB::update('update endttime set endTime=?, image=? where ID=?',[$request->endTime,$fileName,$request->ID]);

            }else
            {
                $data=DB::update('update endttime set endTime=?  where ID=?',[$request->endTime,$request->ID]);

            }
         
          return redirect('/courseOffer');
    }
    



//Classs Routine

 public function classRoutineFormPage(Request $request)
    {
         $Saturday = DB::insert('insert into routine (oneBatch,Saturday,oneTeacher,oneStartTime,oneEndTime,oneRoom,twoBatch,Sunday,twoTeacher,TwoStartTime,twoEndTime,twoRoom,threeBatch,Monday,threeTeacher,threeStartTime,threeEndTime,threeRoom,fourBatch,Tuesday,fourTeacher,fourStartTime,fourEndTime,fourRoom,fiveBatch,Wednesday,fiveTeacher,fiveStartTime,fiveEndTime,fiveRoom,sixBatch,Thursday,sixTeacher,sixStartTime,sixEndTime,sixRoom,sevenBatch,Friday,sevenTeacher,sevenStartTime,sevenEndTime,sevenRoom) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[$request->oneBatch,$request->Saturday,$request->oneTeacher,$request->oneStartTime,$request->oneEndTime,$request->oneRoom,$request->twoBatch,$request->Sunday,$request->twoTeacher,$request->TwoStartTime,$request->twoEndTime,$request->twoRoom,$request->threeBatch,$request->Monday,$request->threeTeacher,$request->threeStartTime,$request->threeEndTime,$request->threeRoom,$request->fourBatch,$request->Tuesday,$request->fourTeacher,$request->fourStartTime,$request->fourEndTime,$request->fourRoom,$request->fiveBatch,$request->Wednesday,$request->fiveTeacher,$request->fiveStartTime,$request->fiveEndTime,$request->fiveRoom,$request->sixBatch,$request->Thursday,$request->sixTeacher,$request->sixStartTime,$request->sixEndTime,$request->sixRoom,$request->sevenBatch,$request->Friday,$request->sevenTeacher,$request->sevenStartTime,$request->sevenEndTime,$request->sevenRoom]);
     
       
      return view('academic.classRoutineFormPage'); 
    }














     public function classRoutineList()
    {

$studentInformationList = DB::select('select * from courseandroutine order by ID', []);


session()->flash('FirstName','stuentInformationList');

           return view ('academic.classRoutineList')->with('studentInformationList',$studentInformationList);
         
    }


   

           public function routineeditreq($ID)
    {
     
        $studentInformationList = DB::select('select * from courseandroutine where ID=?',[$ID]);
      //->with('data',$data);  
      return view('academic.routineEditReq')->with('studentInformationList',$studentInformationList); 
    }




           public function routinedelreq($ID)
    {
     
        $studentInformationList = DB::delete('delete from courseandroutine where ID=?',[$ID]);
      //->with('data',$data);  
      return redirect('/studentInformationList');
        
    } 

      public function routineeditsv(Request $request)
    {
            
            if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);
 // for convert  image to text

                 $feedback= DB::insert('insert into courseandroutine (semester, courseCodeTitile,section,credit_hour,department,teacher_name,day,starting_time,ending_time,room_no,reg_end_time) values (?,?,?,?,?,?,?,?,?,?,?)',[$request->semester,$request->courseCodeTitile,$request->section,$request->credit_hour,$request->department,$request->teacher_name,$request->day,$request->starting_time,$request->ending_time,$request->room_no,$request->reg_end_time]);

            }else
            {
                $feedback= DB::insert('insert into courseandroutine (semester, courseCodeTitile,section,credit_hour,department,teacher_name,day,starting_time,ending_time,room_no,reg_end_time) values (?,?,?,?,?,?,?,?,?,?,?)',[$request->semester,$request->courseCodeTitile,$request->section,$request->credit_hour,$request->department,$request->teacher_name,$request->day,$request->starting_time,$request->ending_time,$request->room_no,$request->reg_end_time]);


            }

         
          return redirect('/studentInformationList');
    }




 
    public function courseRegistrationRoutine()
    {

$data = DB::select('select * from courseandroutine', []);

           return view ('academic.courseRegistrationRoutine')->with('data',$data);
         
    }




 
//End Course Registration Input & output


//start teachers evolution

    //teachersEvolutionTable
 public function teachersEvolutionTable()

    {
         $value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

            $course = DB::select('select * from courseregistration where student_id=?', [$value]);


            


}
        return view ('academic.teachersEvolutionTable')->with('studentName',$studentName)->with('course',$course)->with('studentPicture',$studentPicture);
    } 


public function teacherList()
    {
        return view ('academic.teacherList');
    
    }






    public function teachersEvolution(Request $request)

 
   {

            $teachersEvolution = DB::insert('insert into teachers_evolution(TeachersName,courseCodeTitile,qus1,qus2,qus3,qus4,qus5,qus6,qus7,qus8,qus9,qus10,Comment,Average,student_id) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[$request->TeachersName,$request->courseCodeTitile,$request->qus1,$request->qus2,$request->qus3,$request->qus4,$request->qus5,$request->qus6,$request->qus7,$request->qus8,$request->qus9,$request->qus10,$request->Comment,$request->Average,session('chklogin')]);

            DB::update("UPDATE `routine`a,teachers_evolution b set b.teachersname=a.oneTeacher  where a.Saturday=b.courseCodeTitile ");
            DB::update("UPDATE `routine`a,teachers_evolution b set b.teachersname=a.twoTeacher  where a.Sunday=b.courseCodeTitile ");
            DB::update("UPDATE `routine`a,teachers_evolution b set b.teachersname=a.threeTeacher  where a.Monday=b.courseCodeTitile ");
            DB::update("UPDATE `routine`a,teachers_evolution b set b.teachersname=a.fourTeacher  where a.Tuesday=b.courseCodeTitile ");
            DB::update("UPDATE `routine`a,teachers_evolution b set b.teachersname=a.fiveTeacher  where a.Wednesday=b.courseCodeTitile ");
            DB::update("UPDATE `routine`a,teachers_evolution b set b.teachersname=a.sixTeacher  where a.Thursday=b.courseCodeTitile ");
            DB::update("UPDATE `routine`a,teachers_evolution b set b.teachersname=a.sevenTeacher  where a.Friday=b.courseCodeTitile ");
 



            DB::update("update teachers_evolution set average=qus1+qus2+qus3+qus4+qus5+qus6+qus7+qus8+qus9+qus10");


      

if ($request->submit) {



    return redirect ('/teachersEvolutionTable');
}
        

          
    
    }




    public function teachersEvolutionList(Request $request)

    {
$teachersEvolutionList = DB::select('select * from teachers_evolution', []);

         return view ('academic.teachersEvolutionList')->with('teachersEvolutionList',$teachersEvolutionList);
    }

    //end 





//Admit Card with course
    
public function admitCard()
    
 { 

         $value = session('chklogin');

       if ($value!=0) 
          $courseForAdmit = DB::select('select * from courseregistration where student_id=? and adminApproval=1 and adminApproval2=1', [$value]);

      $stdInfo=DB::select('select * from admission where student_id=?', [$value]);

       $admitserial=DB::select('select * from admitserial where student_id=?', [$value]);

           
         $semester = DB::select('select distinct semester from courseregistration where student_id=?', [$value]);

         $image = DB::select('select * from admission where student_id=?', [$value]);

           return view ('exam.admitCard')->with('courseForAdmit',$courseForAdmit)->with('stdInfo',$stdInfo)->with('admitserial',$admitserial)->with('semester',$semester)->with('image',$image);        
    }


//Admit Card Serial

 public function admitSerial(Request $request)
    {
        $value = session('academicchklogin');

       if ($value!=0) 
         $admitSerialForExam=DB::select('select * from admitserial', [$value]);

        return view('exam.admitSerial')->with('admitSerialForExam',$admitSerialForExam);
    }

 




//Drop Semester 

public function semesterDrop()
    {

        $value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
      }
        return view ('academic.semesterDrop')->with('studentName',$studentName)->with('studentPicture',$studentPicture);
    } 


    public function semesterDropApply(Request $request)
    {

   
            $data = DB::insert('insert into semesterdrop(Semester,Cause,Description,student_id) values(?,?,?,?)',[$request->Semester,$request->Cause,$request->Description,session('chklogin')]);

         return redirect('/semesterDrop');
    }

public function semesterDropList()

    {
$semesterDropList = DB::select('select * from semesterdrop', []);

         return view ('academic.semesterDropList')->with('semesterDropList',$semesterDropList);
    } 

     





//Convocation
public function convocation()
    {
         $value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
    }     
        return view ('academic.convocation') ->with('studentName',$studentName)->with('studentPicture',$studentPicture);

    } 



//Start FORM
     public function cseForm()
    {
        return view ('academic.cseForm');
    } 
//Student Information Form

public function studentInformation()
    {session(['msg'=>'']);
        return view ('academic.studentInformation');
    } 

    


//Start Table
    //CSE Table
      public function cseTable()
    {
        return view ('academic.cseTable');
    
    }







    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
