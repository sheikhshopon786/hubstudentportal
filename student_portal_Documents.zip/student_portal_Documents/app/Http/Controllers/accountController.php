<?php

namespace App\Http\Controllers;
 
 
use App\result_verification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class accountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function accountOffice()
    {
           $value = session('accountchklogin');

       if ($value!=0) {

        return view('account.accountIndex');
        }
        else

       {
         return redirect ('/');
       }
         
    }



//Accounts Registration
 public function accountRegisterFormEntry(Request $request)
    {


        $users = DB::insert('insert into accountlogin (type,email,password,userID) values (?,?,?,?)',[$request->type,$request->email,$request->password,$request->userID]);

        return view ('account.accountRegisterForm');
    }


    public function accountRegisterForm()
    {
        return view ('account.accountRegisterForm');
    }

//Academic Admin Login


    public function accountLogin(Request $request)
    {

        $accountLogin= DB::select('select count(*) chk from accountlogin where userID=? and password=?', [$request->userID,$request->password]);


        foreach ($accountLogin as $key ) {


            if ($key->chk==1) {
                 

                 session(['accountchklogin' => $request->userID]);


             return redirect  ('/accountOffice');

         }else
         {
             
            session(['accountchklogin' => 0]);
             session()->flash('accountchklogin','Login Faild');

           return view ('account.accountLoginForm');
       }

   }


}

public function accountLoginForm()
{
    return view ('account.accountLoginForm');
}


public function accountLogout()
{
    session(['accountchklogin' => 0]);
    return redirect('/');
}










//Student Information

     public function studentInformationAcc()
    {

$studentInformationList = DB::select('select * from admission', []);


session()->flash('FirstName','stuentInformationList');

           return view ('account.studentInformationAcc')->with('studentInformationList',$studentInformationList);
         
    }

//Waiver Check Page

 //For Waiver Input Form Start
    public function waiverFormPage()
    {
        return view('account.waiverFormPage');
    }


 public function waiverForm(Request $request)

   {

            $waiverForm = DB::insert('insert into waiver (Program,Waiver,Amount,RequiredResult) values (?,?,?,?)',[$request->Program,$request->Waiver,$request->Amount,$request->RequiredResult]);
           
 
        return view('account.waiverFormPage');
    }



//Waiver List Table 
 public function waiverCheck()
    {

        $data = DB::select('select * from waiver where ID=0', []);


        return view('account.waiverCheck')->with('data',$data);
    }





//Waiver Search
       
 public function waiverSearch(Request $request)
        { 

            $data = DB::select('select * from waiver where (Program=? and Waiver=?)',[$request->Program,$request->Waiver]);

            return view ('account.waiverCheck')->with('data',$data);
         
        }


     
//Waiver Check End


//Payment Scheme
public function paymentScheme(Request $request)
    {

$value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

$payment = DB::select('select * from paymentScheme where student_id=?', [$value]);

       if ($value!=0) 
$paymentBox = DB::select('select * from paymentScheme where student_id=?', [$value]);

 }
 
       return view('account.paymentScheme')->with('payment',$payment)->with('paymentBox',$paymentBox)->with('studentName',$studentName)->with('studentPicture',$studentPicture);
    }


//Student Payment Ledger


//Form

     public function studentPaymentLedgerForm()
    {


        return view('account.studentPaymentLedgerForm');
    }

 public function studentPaymentLedgerStore(Request $request)
    {

            $test = DB::insert('insert into paymentscheme (student_id,semester,FeeType,Amount,PaymentType,PaymentAmount) values (?,?,?,?,?,?)',[$request->student_id,$request->semester,$request->FeeType,$request->Amount,$request->PaymentType,$request->PaymentAmount]);

        return view('account.studentPaymentLedgerForm');
    }



//Table
     public function studentPaymentLedger()
    {


$studentPaymentLedger = DB::select('select * from paymentscheme', []);

        return view('account.studentPaymentLedger')->with('studentPaymentLedger',$studentPaymentLedger);
         
    }




//For Student paymentscheme
    
 public function studentPaymentDetails(Request $request)
    {

        $value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
 
    $liveResult = DB::select('select * from paymentscheme where ID=0', [$value]);
 

         $semester = DB::select('select distinct semester from paymentscheme where student_id=?', [$value]);


         $paymentLedger = DB::select ('SELECT ((TotalPayable-Waiver)-PaidAmount) AS  Due FROM  paymentscheme WHERE semester=? and student_id=?',[$request->semester,session('chklogin')]);

 
 }
       return view('account.studentPaymentDetails')->with('liveResult',$liveResult)->with('semester',$semester)->with('studentName',$studentName)->with('studentPicture',$studentPicture)->with('paymentLedger',$paymentLedger);
    }
    




 public function studentPaymentDetailsSearch(Request $request)
        { 
            $value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

            $liveResult = DB::select('select * from paymentscheme where (semester=? and student_id=?)',[$request->semester,$value]);

           

         $semester = DB::select('select distinct semester from paymentscheme where student_id=?', [$value]);
 
 

  $paymentLedger = DB::select ('SELECT ((TotalPayable-Waiver)-PaidAmount) AS  Due FROM  paymentscheme WHERE semester=? and student_id=?',[$request->semester,session('chklogin')]);
 
    } 
            
            return view ('account.studentPaymentDetails')->with('liveResult',$liveResult)->with('semester',$semester)->with('studentName',$studentName)->with('studentPicture',$studentPicture)->with('paymentLedger',$paymentLedger);

         
        }



//Student Result
        public function studentResultAcc(Request $request)
    {

        $studentResult = DB::select('select * distinct student_id from  studentresult where ID=0', []);

        $semesterNo1 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=1 and student_id=0', []);

          $semesterNo2 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=2 and student_id=0', []);

          $semesterNo3 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=3 and student_id=0', []);

          $semesterNo4 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=4 and student_id=0', []);

          $semesterNo5 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=5 and student_id=0', []);

          $semesterNo6 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=6 and student_id=0', []);

          $semesterNo7 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=7 and student_id=0', []);

          $semesterNo8 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=8 and student_id=0', []);


        return view('account.studentResult')->with('studentResult',$studentResult)->with('semesterNo1',$semesterNo1)->with('semesterNo2',$semesterNo2)->with('semesterNo3',$semesterNo3)->with('semesterNo4',$semesterNo4)->with('semesterNo5',$semesterNo5)->with('semesterNo6',$semesterNo6)->with('semesterNo7',$semesterNo7)->with('semesterNo8',$semesterNo8);
    }





//Waiver Search 

 public function studentResultAccSearch(Request $request)
        { 

            $studentResult = DB::select('select * from  studentresult where ( student_id=?)',[$request->student_id]);

            $semesterNo1 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=1 and student_id=?', [$request->student_id]);

          $semesterNo2 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=2 and student_id=?', [$request->student_id]);

          $semesterNo3 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=3 and student_id=?', [$request->student_id]);

          $semesterNo4 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=4 and student_id=?', [$request->student_id]);

          $semesterNo5 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=5 and student_id=?', [$request->student_id]);

          $semesterNo6 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=6 and student_id=?', [$request->student_id]);

          $semesterNo7 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=7 and student_id=?', [$request->student_id]);

          $semesterNo8 = DB::select('SELECT (SUM(GradePoint * credit_hour) / SUM(credit_hour)) AS GPA
            FROM studentresult WHERE semesterNo=8 and student_id=?', [$request->student_id]);

            return view ('account.studentResult')->with('studentResult',$studentResult)->with('semesterNo1',$semesterNo1)->with('semesterNo2',$semesterNo2)->with('semesterNo3',$semesterNo3)->with('semesterNo4',$semesterNo4)->with('semesterNo5',$semesterNo5)->with('semesterNo6',$semesterNo6)->with('semesterNo7',$semesterNo7)->with('semesterNo8',$semesterNo8);
         
        }





    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
