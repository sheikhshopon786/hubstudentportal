<?php

namespace App\Http\Controllers;

use App\result_verification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use file;
use Response;
class pagesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

//index/home page

public function rc(Request $request)
{
    if (session('rand')==$request->rc) {
        session(['rand1' => $request->rc]);
        return redirect('/newPassword');
    }else
    {
       return redirect('/resetCode'); 
    }



}

public function chp(Request $request)
{
   if (session('rand')==session('rand1')) {
        DB::update('update admission set password=md5(?) where student_id=?',[$request->confirmPassword,session('rcid')]);

          return redirect('/studentProfile');
    }else
    {
       return redirect('/resetCode'); 
    } 





}
 public function fgp(Request $request)
 {
    
    //return rand(111111,999999);

    session(['rand' => rand(111111,999999)]);
    session(['rcid' => $request->uid]);
    $phone=DB::select('select phone from admission where student_id='.$request->uid);
    foreach ($phone as $key ) {
        $phone=$key->phone;
    }
    file_get_contents("http://api.greenweb.com.bd/api.php?token=c66a6116809291c1f8658c558d9215ee&to=".$phone."&message=".session('rand'));
    return redirect('/resetCode');
 }

//index/home page content
    public function index(Request $request)
    {
         

        $Notice1 = DB::select('select * from Notice  ORDER BY ID DESC', [$request->Date,$request->Month,$request->Title]);
  
           return view ('partial.indexContent')->with('Notice1',$Notice1);

       
    }


//Register Form

    public function registerFormEntry(Request $request)
    {


        $users = DB::insert('insert into users (type,email,password,userID) values (?,?,?,?)',[$request->type,$request->email,$request->password,$request->userID]);

        return view ('partial.registerForm');
    }


    public function registerForm()
    {
        return view ('partial.registerForm');
    }

 
//Forgot Password Start
     public function forgotPassword()
    {
        return view ('partial.forgotPassword');
    }

 

//Reset Code
     public function resetCode()
    {
        return view ('partial.resetCode');
    }

//New Password
     public function newPassword()
    {
        return view ('partial.newPassword');
    }





// Student Login

    public function studentLogin(Request $request)
    {

        $studentLogin= DB::select('select count(*) chk from admission where student_id=? and password=md5(?) ', [$request->student_id,$request->password]);



        foreach ($studentLogin as $key ) {


            if ($key->chk==1) {
                 

                 session(['chklogin' => $request->student_id]);


                 $fb= DB::insert('insert into user_trac values (?,?)', 
                    [$request->student_id,date('Y-m-d H:i:s')]);

                 $dept= DB::select('select Department from admission where student_id=?', 
                    [$request->student_id]);

                 foreach ($dept as $key ) {

                   


                    session(['dept' => $key->Department]);
                     
                 }



               

             return redirect  ('/studentProfile');
         }else
         {
             
            session(['chklogin' => 0]);
             session()->flash('chklogin','Login Failed');
           return view ('partial.login');
       }



   }



}


public function login()
{
    return view ('partial.login');
}


public function logout()
{
    session(['chklogin' => 0]);
    return redirect('/');
}







//Admit Approval For Academic Office
            public function approval($student_id)
    {
     
     DB::delete('delete from admitserial where student_id=?',[$student_id]);
        
        $studentInformationList = DB::update('update courseregistration set adminApproval=1  where student_id=?',[$student_id]);

        DB::insert('insert into admitserial values (?,?)',[$student_id,time()]);
      
      return redirect ('/studentInformationAcc');   
        
    }
 

//Admit Approval For Acccount Office
            public function approval2($student_id)
    {
     
     DB::delete('delete from admitserial where student_id=?',[$student_id]);
        
        $studentInformationList = DB::update('update courseregistration set adminApproval2=1  where student_id=?',[$student_id]);

        DB::insert('insert into admitserial values (?,?)',[$student_id,time()]);
      
      return redirect ('/studentInformationExam');   
        
    }



    
//Student information Edit & Delete
 


           public function editreq($student_id)
    {
     
        $studentInformationList = DB::select('select * from admission where student_id=?',[$student_id]);
      //->with('data',$data);  
      return view('partial.EditReq')->with('studentInformationList',$studentInformationList); 
    }




           public function delreq($student_id)
    {
     
        $studentInformationList = DB::delete('delete from admission where student_id=?',[$student_id]);
      //->with('data',$data);  
      return redirect('/studentInformationList');
        
    } 

      public function editsv(Request $request)
    {
            
            if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);
 // for convert  image to text

                 $feedback=DB::update('update admission set FirstName=?,LastName=?,PresentAddress=?,ParmanentAddress=?,MotherName=?,FatherName=?,Phone=?,Email=?,Department=?,Batch=?,DOB=?,BG=?,Religion=?,Nationality=?,password=?, image=? where student_id=?',[$request->FirstName,$request->LastName,$request->PresentAddress,$request->ParmanentAddress,$request->MotherName,$request->FatherName,$request->Phone,$request->Email,$request->Department,$request->Batch,$request->DOB,$request->BG,$request->Religion,$request->Nationality,$request->password,$fileName,$request->student_id]);

            }else
            {
                $feedback=DB::update('update admission set FirstName=?,LastName=?,PresentAddress=?,ParmanentAddress=?,MotherName=?,FatherName=?,Phone=?,Email=?,Department=?,Batch=?,DOB=?,BG=?,Religion=?,Nationality=?,password=?  where student_id=?',[$request->FirstName,$request->LastName,$request->PresentAddress,$request->ParmanentAddress,$request->MotherName,$request->FatherName,$request->Phone,$request->Email,$request->Department,$request->Batch,$request->DOB,$request->BG,$request->Religion,$request->Nationality,$request->password,$request->student_id]);

            }

         
          return redirect('/studentInformationList');
    }




//Footer
public function footer()
{
    return view ('partial.footer');
}


//Notice
 


public function notice(Request $request)
    {
         $value = session('chklogin');
 
       if ($value!=0) {

          $studentName = DB::select('select * from admission where student_id=?', [$value]);
          $studentPicture = DB::select('select * from admission where student_id=?', [$value]);

        $Notice = DB::select('select * from Notice', [$request->Date,$request->Month,$request->Title]);

}
        return view('partial.notice')->with('Notice',$Notice)->with('studentName',$studentName)->with('studentPicture',$studentPicture);

        
    }

    
public function notice1(Request $request)
    {
          

        $studentInformationList = DB::select('select * from Notice ORDER BY ID DESC', [$request->Date,$request->Month,$request->Title]);


        return view('partial.notice1')->with('studentInformationList',$studentInformationList);

        
    }

//Notice Show

     public function noticeeditreq($ID)
    {
     
        $studentInformationList = DB::select('select * from Notice where ID=?',[$ID]);
      $recentNotice = DB::select('select * from Notice ORDER BY ID DESC',[]);

      return view('partial.noticeEditReq')->with('studentInformationList',$studentInformationList)->with('recentNotice',$recentNotice); 
    }




           public function noticedelreq($ID)
    {
     
        $studentInformationList = DB::delete('delete from Notice where ID=?',[$ID]);
      //->with('data',$data);  
      return redirect('/studentInformationList');
        
    } 

      public function noticeeditsv(Request $request)
    {
            
            if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);
 // for convert  image to text

                 $feedback=DB::insert('insert into Notice (Date,Title,Description,Day,StartingTime,EndingTime,Location,Category)values (?,?,?,?,?,?,?,?)',[$request->Date,$request->Title,$request->Description,$request->Day,$request->StartingTime,$request->EndingTime,$request->Location,$request->Category]);

            }else
            {
                $feedback=DB::insert('insert into Notice (Date,Title,Description,Day,StartingTime,EndingTime,Location,Category)values (?,?,?,?,?,?,?,?)',[$request->Date,$request->Title,$request->Description,$request->Day,$request->StartingTime,$request->EndingTime,$request->Location,$request->Category]);

            }

         
          return redirect('/studentInformationList');
    }
//End Notice   




public function NoticeFormPage()
{
    return view ('partial.noticeFormPage');
}


public function NoticeForm(Request $request)
 
   {  

    if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);

            $NoticeForm = DB::insert('insert into Notice (Date,Title,image,Description,Day,StartingTime,EndingTime,Location,Category)values (?,?,?,?,?,?,?,?,?)',[$request->Date,$request->Title,$fileName,$request->Description,$request->Day,$request->StartingTime,$request->EndingTime,$request->Location,$request->Category]);

            session(['msg'=>'Your Data Successfully Inserted']);

}
           return view ('partial.noticeFormPage');
    }
    







//Celender
public function celender()
{

 $value = session('chklogin');

       if ($value!=0) {
        
          $studentName = DB::select('select * from admission where student_id=?', [$value]);

            $studentPicture = DB::select('select * from admission where student_id=?', [$value]);
        }
    return view ('partial.celender') ->with('studentName',$studentName)->with('studentPicture',$studentPicture);

}


public function celender1()
{

  
    return view ('partial.celender1');

}

//Notification
public function notification()
{
    return view ('partial.notification');
}



//Student Clearance
    
 public function studentClearance(Request $request)
    {

$data= DB::select('select * from application', [$request->AcademicOffice]);

           return view ('partial.studentClearance')->with('data',$data);
         

    } 


//picture
public function pictureStoreForm(Request $r)
{
 
        
if ($r->hasFile('image'))
     { 

        $file=$r->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);

        DB::insert("insert into picture(name,image) values (?,?)",[$r->name,$fileName]);
    }
        
         // $file->move('userFiles/'.session('client_id').'/studentImage',$fileName);
  

        return view ('partial.pictureStoreForm');
}


public function picture(Request $request)
    {

$data= DB::select('select * from picture', [$request->image]);

           return view ('partial.picturePage')->with('data',$data);
         

    } 



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
