<?php

namespace App\Http\Controllers;


use App\result_verification;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\DB;
use file;
use Response;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function admin()
    {
        return view('admin.adminDashBoard');      
    }


    //Admin Index
    public function adminIndex()
    {

        $value = session('userchklogin');

       if ($value!=0) {

        return view('admin.adminIndex');

        }
        else

       {
         return redirect ('/adminLoginForm');
       }
    }

//User Register Form


    public function SregisterFormEntry(Request $request)
    {


        $users = DB::insert('insert into users (type,email,password,userID) values (?,?,?,?)',[$request->type,$request->email,$request->password,$request->userID]);

        return view ('admin.userRegisterForm');
    }


    public function userRegisterForm()
    {
        return view ('admin.userRegisterForm');
    }


//Super Admin Login


    public function adminLogin(Request $request)
    {

        $adminLogin= DB::select('select count(*) chk from users where userID=? and password=?', [$request->userID,$request->password]);


        foreach ($adminLogin as $key ) {


            if ($key->chk==1) {
                 

                 session(['userchklogin' => $request->userID]);


             return redirect  ('/admin');

         }else
         {
             
            session(['userchklogin' => 0]);
             session()->flash('userchklogin','Login Faild');

           return view ('admin.adminLoginForm');
       }

   }


}




public function adminLoginForm()
{
    return view ('admin.adminLoginForm');
}


public function adminLogout()
{
    session(['userchklogin' => 0]);
    return redirect('/');
}




//************Academic For Super Admin******************

public function SacademicOffice()
{
    return view ('admin.aca.SacademicIndex');
}



//Student Information Insert Form Start
  public function SstudentInformationInsert(Request $request)

 
   {


    if ($request->hasFile('image'))
     { 

        $file=$request->file('image');
        $fileName=time().'.'.$file->getClientOriginalExtension();
        $file->move('image/',$fileName);

        DB::insert("insert into admission (student_id,FirstName,LastName,Gender,PresentAddress,ParmanentAddress,MotherName,FatherName,Phone,Email,Faculty,Department,Batch,DOB,BG,Religion,Nationality,image,password) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,md5(?))",[$request->student_id,$request->FirstName,$request->LastName,$request->Gender,$request->PresentAddress,$request->ParmanentAddress,$request->MotherName,$request->FatherName,$request->Phone,$request->Email,$request->Faculty,$request->Department,$request->Batch,$request->DOB,$request->BG,$request->Religion,$request->Nationality,$fileName,$request->password]);
        if ($request->btn=='btn') {
             session(['msg'=>'Your Data Successfully Inserted']);
        }
}
            

           return view ('admin.aca.SstudentInformation');
    }


public function SstudentInformation()
    {session(['msg'=>'']);
        return view ('admin.aca.SstudentInformation');
    }

     public function SstudentInformationList()
    {

$studentInformationList = DB::select('select * from admission order by student_id', []);


session()->flash('FirstName','stuentInformationList');

           return view ('admin.aca.SstudentInformationList')->with('studentInformationList',$studentInformationList);
         
    }

//Student Information Insert Form Start End

//Course List  
public function ScourseList()
    {

$data = DB::select('select * from courseandroutine', []);

           return view ('admin.aca.ScourseList')->with('data',$data);
         
    }

//Course Offer
public function ScourseOffer()
    {
        return view ('admin.aca.ScourseOffer');
    }


 public function Sstore(Request $request)
    {

   
            $test = DB::insert('insert into courseandroutine (semester, courseCodeTitile,section,credit_hour,department,teacher_name,day,starting_time,ending_time,room_no,reg_end_time) values (?,?,?,?,?,?,?,?,?,?,?)',[$request->semester,$request->courseCodeTitile,$request->section,$request->credit_hour,$request->department,$request->teacher_name,$request->day,$request->starting_time,$request->ending_time,$request->room_no,$request->reg_end_time]);


     $fb=DB::insert('insert into courseregistration(department,credit_hour,section,teacher_name) select department,credit_hour,section,teacher_name from courseandroutine', [session('dept')]);


           return view ('admin.aca.ScourseOffer');
    }


 public function ScourseRegistrationRoutine()
    {

$data = DB::select('select * from courseandroutine', []);

           return view ('admin.aca.ScourseRegistrationRoutine')->with('data',$data);
         
    }

//Class Routine
     public function SclassRoutineFormPage()
    {
     
       
      return view('admin.aca.SclassRoutineFormPage'); 
    }



//Semsester Drop
    public function SsemesterDrop()
    {
        return view ('admin.aca.SsemesterDrop');
    } 

 public function SsemesterDropApply(Request $request)
    {

   
            $data = DB::insert('insert into semesterdrop(Semester,Cause,Description,student_id) values(?,?,?,?)',[$request->Semester,$request->Cause,$request->Description,session('userchklogin')]);

         return redirect('/SsemesterDrop');
    }


public function SsemesterDropList()

    {
$semesterDropList = DB::select('select * from semesterdrop', []);

         return view ('admin.aca.SsemesterDropList')->with('semesterDropList',$semesterDropList);
    } 

//teachersEvolutionTable
 public function SteachersEvolutionTable()
    {
        return view ('admin.aca.SteachersEvolutionTable');
    } 



    public function teachersEvolution(Request $request)

   {
            $teachersEvolution = DB::insert('insert into teachers_evolution(TeachersName,CourseName,Marks,Comment,good,well) values (?,?,?,?,?,?)',[$request->TeachersName,$request->CourseName,$request->Marks,$request->Comment,$request->good,$request->well]);

if ($request->submit) {

    return redirect ('/admitCard');
}   
         return view ('admin.aca.SteachersEvolutionTable'); 
    }


public function SteachersEvolutionList(Request $request)

    {
$SteachersEvolutionList = DB::select('select * from teachers_evolution', []);

         return view ('admin.aca.SteachersEvolutionList')->with('SteachersEvolutionList',$SteachersEvolutionList);
    } 

//End teachers evolution 





//**********Start Account Office For Super Admin****************
   public function SaccountOffice()
{
    return view ('admin.acc.SaccountIndex');
}

//Student Information

     public function SstudentInformationAcc()
    {

$studentInformationList = DB::select('select * from admission', []);


session()->flash('FirstName','stuentInformationList');

           return view ('admin.acc.SstudentInformationAcc')->with('studentInformationList',$studentInformationList);
      

}
 //Student Payment Ledger
//Form

     public function SstudentPaymentLedgerForm()
    {


        return view('admin.acc.SstudentPaymentLedgerForm');
    }

 public function SstudentPaymentLedgerStore(Request $request)
    {

            $test = DB::insert('insert into paymentscheme (student_id,FeeType,Amount,PaymentType,PaymentAmount) values (?,?,?,?,?)',[$request->student_id,$request->FeeType,$request->Amount,$request->PaymentType,$request->PaymentAmount]);

        return view('admin.acc.SstudentPaymentLedgerForm');
    }



//Table
     public function SstudentPaymentLedger()
    {


$studentPaymentLedger = DB::select('select * from paymentscheme', []);

        return view('admin.acc.SstudentPaymentLedger')->with('studentPaymentLedger',$studentPaymentLedger);
         
    }


//Waiver Check Page

 //For Waiver Input Form Start
    public function SwaiverFormPage()
    {
        return view('admin.acc.SwaiverFormPage');
    }


 public function SwaiverForm(Request $request)

   {

            $waiverForm = DB::insert('insert into waiver (Program,Waiver,Amount,RequiredResult) values (?,?,?,?)',[$request->Program,$request->Waiver,$request->Amount,$request->RequiredResult]);
           
 
        return view('admin.acc.SwaiverFormPage');
    }



//************Exam Controller For Super Admin******************

public function AexamOffice()
{
    return view ('admin.exm.AexamIndex');
}


//Student Information

     public function SstudentInformationExam()
    {

$studentInformationList = DB::select('select * from admission', []);


session()->flash('FirstName','stuentInformationList');

           return view ('admin.exm.SstudentInformationExam')->with('studentInformationList',$studentInformationList);
         
    }


//Certificate
    public function SCertificateApplicationList(Request $request)
    { 
         
      $certificateApplicationList=DB::select('select * from certificate', []);


        return view('admin.exm.ScertificateApplicationList')->with('certificateApplicationList',$certificateApplicationList);
    }

//Admit Serial
     public function SadmitSerial(Request $request)
    {  
         $admitSerialForExam=DB::select('select * from admitserial', []);

        return view('admin.exm.SadmitSerial')->with('admitSerialForExam',$admitSerialForExam);
    }



//Admit Approval For Academic Office
            public function Sapproval($student_id)
    {
     
     DB::delete('delete from admitserial where student_id=?',[$student_id]);
        
        $studentInformationList = DB::update('update courseregistration set adminApproval=1  where student_id=?',[$student_id]);

        DB::insert('insert into admitserial values (?,?)',[$student_id,time()]);
      
      return redirect ('/SstudentInformationAcc');   
        
    }


//Admit Approval For Acccount Office
            public function Sapproval2($student_id)
    {
     
     DB::delete('delete from admitserial where student_id=?',[$student_id]);
        
        $studentInformationList = DB::update('update courseregistration set adminApproval2=1  where student_id=?',[$student_id]);

        DB::insert('insert into admitserial values (?,?)',[$student_id,time()]);
      
      return redirect ('/SstudentInformationExam');   
        
    }







 
//For Verify Result Input Form Start
    public function SresultVerifyFormPage()
    {
        return view('admin.exm.SresultVerifyFormPage');
    }

 public function SresultVerifyForm(Request $request)

   {

            $resultVerifyForm = DB::insert('insert into result_verification (student_id,Name,DepartmentName,CGPA,PassingYear) values (?,?,?,?,?)',[$request->student_id,$request->Name,$request->DepartmentName,$request->CGPA,$request->PassingYear]);
           
 
           return view ('admin.exm.SresultVerifyFormPage');
    }


//Student Result/Grade Sheet In Table

    public function SstudentResult(Request $request)
    {
 
   $studentResult = DB::select('select * from studentresult where student_id=0', []);
 

       return view('admin.exm.SstudentResult')->with('studentResult',$studentResult);
    }



      public function SstudentResultSearch(Request $request)
        {

            $studentResult = DB::select('select * from studentresult where student_id=?', [$request->SSRsearch]);


            return view ('admin.exm.SstudentResult')->with('studentResult',$studentResult);

         
        }














//************Student DashBoard For Super Admin******************

   public function SstudentPart()
{
    return view ('admin.std.SstudentIndex');
}





//For Verify Result Input Form End


    
      public function SstudentDashBoard()
    {

$studentInfo = DB::select('select * from admission where student_id=0', []);

$paymentscheme = DB::select('select * from paymentscheme where student_id=0', []);

$resultscheme = DB::select('select * from resultscheme where student_id=0', []);

$studentresult = DB::select('select * from studentresult where student_id=0', []);

$completecourse = DB::select('select * from completecourse where student_id=0', []);


           return view ('admin.std.SstudentDashBoard')->with('studentInfo',$studentInfo)->with('paymentscheme',$paymentscheme)->with('resultscheme',$resultscheme)->with('studentresult',$studentresult)->with('completecourse',$completecourse);       
    }
     

// search for result verification

      public function SstudentInfoSearch(Request $request)
        {

            $studentInfo = DB::select('select * from admission where student_id=?', [$request->stdsearch]);

            $paymentscheme = DB::select('select * from paymentscheme where student_id=?', [$request->stdsearch]);

            $resultscheme = DB::select('select * from resultscheme where student_id=?', [$request->stdsearch]);

            $studentresult = DB::select('select * from studentresult where student_id=?', [$request->stdsearch]);

            $completecourse = DB::select('select * from completecourse where student_id=?', [$request->stdsearch]);




            return view ('admin.std.SstudentDashBoard')->with('studentInfo',$studentInfo)->with('paymentscheme',$paymentscheme)->with('resultscheme',$resultscheme)->with('studentresult',$studentresult)->with('completecourse',$completecourse); 

         
        }

//Result Verification End


















    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
